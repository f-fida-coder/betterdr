const {
    User,
    Admin,
    Agent,
    Bet,
    Transaction,
    Message,
    Match,
    ThirdPartyLimit,
    IpLog,
    Collection,
    DeletedWager,
    SportsbookLink,
    BillingInvoice,
    PlatformSetting,
    Rule,
    Feedback,
    Faq,
    ManualSection,
    BetModeRule
} = require('../models');
const bcrypt = require('bcryptjs');
const { buildAuthPayload } = require('./authController');
const { DEFAULT_BET_MODE_RULES, normalizeBetMode, getDefaultBetModeRule } = require('../config/betModeRules');
const { getOwnerModelForRole } = require('../utils/ipUtils');

const MS_PER_DAY = 24 * 60 * 60 * 1000;

const getStartOfWeek = (date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = day === 0 ? -6 : 1 - day; // Monday start
    d.setDate(d.getDate() + diff);
    d.setHours(0, 0, 0, 0);
    return d;
};

const buildDayLabels = (startDate) => {
    const labels = [];
    for (let i = 0; i < 7; i++) {
        const d = new Date(startDate);
        d.setDate(d.getDate() + i);
        const dayLabel = d.toLocaleDateString('en-US', { weekday: 'short' });
        const dateLabel = d.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric' });
        labels.push(`${dayLabel} (${dateLabel})`);
    }
    return labels;
};

const parseAmount = (value) => {
    if (value === null || value === undefined) return 0;
    if (typeof value === 'number') return value;
    const parsed = parseFloat(value.toString());
    return Number.isNaN(parsed) ? 0 : parsed;
};

const getSignedAmount = (transaction) => {
    const amount = parseAmount(transaction.amount);
    switch (transaction.type) {
        case 'deposit':
            return amount;
        case 'withdrawal':
            return -amount;
        case 'bet_placed':
            return -amount;
        case 'bet_won':
            return amount;
        case 'bet_refund':
            return amount;
        default:
            return 0;
    }
};

const getStartOfDay = (date) => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    return d;
};

const getStartDateFromPeriod = (period) => {
    const now = new Date();
    if (!period || period === 'all') return null;
    if (period === 'today') {
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    }
    if (period === 'this-week') {
        const start = new Date(now);
        start.setDate(now.getDate() - 7);
        return start;
    }
    if (period === 'this-month') {
        const start = new Date(now);
        start.setDate(now.getDate() - 30);
        return start;
    }
    if (period === '30d') {
        const start = new Date(now);
        start.setDate(now.getDate() - 30);
        return start;
    }
    if (period === '7d') {
        const start = new Date(now);
        start.setDate(now.getDate() - 7);
        return start;
    }
    return null;
};

const getClientIp = (req) => {
    const forwarded = req.headers['x-forwarded-for'];
    if (forwarded) {
        return forwarded.split(',')[0].trim();
    }
    return req.ip || req.socket?.remoteAddress || 'unknown';
};

const ensureBetModeRulesSeeded = async () => {
    await Promise.all(
        DEFAULT_BET_MODE_RULES.map((rule) =>
            BetModeRule.updateOne(
                { mode: rule.mode },
                { $setOnInsert: rule },
                { upsert: true }
            )
        )
    );
};

const REFERRAL_MIN_QUALIFYING_PAYIN = 200;
const REFERRAL_FREEPLAY_BONUS = 200;

const isPlainObject = (value) => value && typeof value === 'object' && !Array.isArray(value);

const mergeDeep = (base, incoming) => {
    if (!isPlainObject(base)) return incoming;
    if (!isPlainObject(incoming)) return incoming === undefined ? base : incoming;

    const merged = { ...base };
    Object.keys(incoming).forEach((key) => {
        const baseVal = base[key];
        const incomingVal = incoming[key];
        if (isPlainObject(baseVal) && isPlainObject(incomingVal)) {
            merged[key] = mergeDeep(baseVal, incomingVal);
        } else {
            merged[key] = incomingVal;
        }
    });
    return merged;
};

const hasAgentViewPermission = (user, key) => {
    if (!user) return false;
    if (user.role === 'admin') return true;
    const views = user.permissions?.views || {};
    return views[key] !== false;
};

const canManageIpTracker = (user) => {
    if (!user) return false;
    if (user.role === 'admin') return true;
    return user.permissions?.ipTracker?.manage !== false;
};

const getScopedAgentIds = async (user) => {
    if (!user) return [];
    if (user.role === 'admin') return null;
    if (user.role === 'agent') return [String(user._id)];
    if (user.role === 'master_agent' || user.role === 'super_agent') {
        const subAgents = await Agent.find({ createdBy: user._id, createdByModel: 'Agent' }).select('_id');
        return [String(user._id), ...subAgents.map((a) => String(a._id))];
    }
    return [];
};

const getScopedIpUserIds = async (user) => {
    if (!user) return [];
    if (user.role === 'admin') return null;

    if (user.role === 'agent') {
        const players = await User.find({ agentId: user._id }).select('_id');
        return [String(user._id), ...players.map((p) => String(p._id))];
    }

    if (user.role === 'master_agent' || user.role === 'super_agent') {
        const subAgents = await Agent.find({ createdBy: user._id, createdByModel: 'Agent' }).select('_id');
        const agentIds = [String(user._id), ...subAgents.map((a) => String(a._id))];
        const players = await User.find({ agentId: { $in: agentIds } }).select('_id');
        return [...agentIds, ...players.map((p) => String(p._id))];
    }

    return [String(user._id)];
};

const buildOwnerMap = async (logs) => {
    const userIds = [];
    const agentIds = [];
    const adminIds = [];

    logs.forEach((log) => {
        const ownerId = log.userId ? String(log.userId) : '';
        if (!ownerId) return;
        const model = log.userModel || 'User';
        if (model === 'Admin') {
            adminIds.push(log.userId);
        } else if (model === 'Agent') {
            agentIds.push(log.userId);
        } else {
            userIds.push(log.userId);
        }
    });

    const [users, agents, admins] = await Promise.all([
        userIds.length ? User.find({ _id: { $in: userIds } }).select('_id username phoneNumber').lean() : [],
        agentIds.length ? Agent.find({ _id: { $in: agentIds } }).select('_id username phoneNumber').lean() : [],
        adminIds.length ? Admin.find({ _id: { $in: adminIds } }).select('_id username phoneNumber').lean() : []
    ]);

    const map = new Map();
    users.forEach((doc) => map.set(`User:${String(doc._id)}`, doc));
    agents.forEach((doc) => map.set(`Agent:${String(doc._id)}`, doc));
    admins.forEach((doc) => map.set(`Admin:${String(doc._id)}`, doc));
    return map;
};

const canUseReferrer = async ({ creator, referredByUserId }) => {
    if (!referredByUserId) {
        return { ok: true, referrer: null };
    }

    const referrer = await User.findOne({ _id: referredByUserId, role: 'user' }).select('_id agentId');
    if (!referrer) {
        return { ok: false, message: 'Referrer player not found' };
    }

    if (creator.role === 'agent') {
        if (String(referrer.agentId || '') !== String(creator._id)) {
            return { ok: false, message: 'You can only choose a referrer from your own players' };
        }
    } else if (creator.role === 'master_agent' || creator.role === 'super_agent') {
        const subAgents = await Agent.find({ createdBy: creator._id, createdByModel: 'Agent' }).select('_id');
        const allowedAgentIds = new Set([String(creator._id), ...subAgents.map((a) => String(a._id))]);
        if (!allowedAgentIds.has(String(referrer.agentId || ''))) {
            return { ok: false, message: 'You can only choose a referrer from your hierarchy' };
        }
    }

    return { ok: true, referrer };
};

// Get all users
exports.getUsers = async (req, res) => {
    try {
        const query = { role: 'user' };

        if (req.user.role === 'agent') {
            // Regular agents: see only their own players
            query.agentId = req.user._id;
        } else if (req.user.role === 'super_agent' || req.user.role === 'master_agent') {
            // Super agents: see players created by them AND by their sub-agents
            const subAgents = await Agent.find({
                createdBy: req.user._id,
                createdByModel: 'Agent'
            }).select('_id');
            const subAgentIds = subAgents.map(sa => sa._id);
            query.agentId = { $in: [req.user._id, ...subAgentIds] };
        }
        // Admin sees all users (no filter)

        const users = await User.find(query)
            .select('-password')
            .populate('agentId', 'username')
            .populate('createdBy', 'username role') // Populate polymorphic creator
            .populate('referredByUserId', 'username fullName')
            .select('username firstName lastName fullName phoneNumber balance pendingBalance balanceOwed freeplayBalance creditLimit minBet maxBet role status settings createdAt agentId createdBy createdByModel rawPassword referredByUserId referralBonusGranted referralBonusAmount');
        // Calculate active status (>= 2 bets in last 7 days)
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

        const activeUserIds = await Bet.aggregate([
            { $match: { userId: { $in: users.map(u => u._id) }, createdAt: { $gte: oneWeekAgo } } },
            { $group: { _id: '$userId', count: { $sum: 1 } } },
            { $match: { count: { $gte: 2 } } }
        ]);
        const activeSet = new Set(activeUserIds.map(a => String(a._id)));

        const formatted = users.map(user => {
            const balance = parseFloat(user.balance?.toString() || '0');
            const pendingBalance = parseFloat(user.pendingBalance?.toString() || '0');
            const balanceOwed = parseFloat(user.balanceOwed?.toString() || '0');
            const availableBalance = Math.max(0, balance - pendingBalance);
            return {
                id: user._id,
                username: user.username,
                phoneNumber: user.phoneNumber,
                firstName: user.firstName,
                lastName: user.lastName,
                fullName: user.fullName,
                minBet: user.minBet,
                maxBet: user.maxBet,
                creditLimit: parseFloat(user.creditLimit?.toString() || '0'),
                role: user.role,
                status: user.status,
                createdAt: user.createdAt,
                agentId: user.agentId,
                balance,
                pendingBalance,
                balanceOwed,
                freeplayBalance: parseFloat(user.freeplayBalance?.toString() || '0'),
                availableBalance,
                isActive: activeSet.has(String(user._id)),
                createdBy: user.createdBy ? { username: user.createdBy.username, role: user.createdBy.role } : null,
                createdByModel: user.createdByModel,
                referredByUserId: user.referredByUserId?._id || null,
                referredByUsername: user.referredByUserId?.username || null,
                referralBonusGranted: Boolean(user.referralBonusGranted),
                referralBonusAmount: Number(user.referralBonusAmount || 0),
                settings: user.settings,
                rawPassword: user.rawPassword
            };
        });
        res.json(formatted);
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all agents
exports.getAgents = async (req, res) => {
    try {
        let query = {};

        if (req.user.role === 'super_agent' || req.user.role === 'master_agent') {
            // Super agents: see only agents they created
            query = { createdBy: req.user._id, createdByModel: 'Agent' };
        } else if (req.user.role === 'agent') {
            // Regular agents: cannot see any agents
            return res.json([]);
        }
        // Admin sees all agents (no filter)

        const agents = await Agent.find(query)
            .populate('createdBy', 'username role')
            .select('username phoneNumber balance balanceOwed role status createdAt createdBy createdByModel agentBillingRate agentBillingStatus viewOnly rawPassword permissions');

        const activeSince = new Date(Date.now() - 7 * MS_PER_DAY);
        const activeUserIds = await Bet.aggregate([
            { $match: { createdAt: { $gte: activeSince } } },
            { $group: { _id: '$userId', betCount: { $sum: 1 } } },
            { $match: { betCount: { $gte: 2 } } }
        ]);
        const activeUserSet = new Set(activeUserIds.map(row => String(row._id)));

        const agentsWithCount = await Promise.all(
            agents.map(async (agent) => {
                const userCount = await User.countDocuments({ agentId: agent._id });
                const agentUsers = await User.find({ agentId: agent._id, status: 'active' }).select('_id');
                const activeCustomerCount = agentUsers.filter(u => activeUserSet.has(String(u._id))).length;

                let subAgentCount = 0;
                let totalUsersInHierarchy = 0;

                if (agent.role === 'master_agent') {
                    const subAgents = await Agent.find({ createdBy: agent._id, createdByModel: 'Agent' }).select('_id');
                    subAgentCount = subAgents.length;
                    const subAgentIds = subAgents.map(sa => sa._id);
                    totalUsersInHierarchy = await User.countDocuments({ agentId: { $in: subAgentIds } });
                }

                const obj = agent.toObject();
                if (obj.balance != null) {
                    try {
                        obj.balance = parseFloat(agent.balance.toString());
                    } catch (e) {
                        obj.balance = Number(obj.balance) || 0;
                    }
                } else {
                    obj.balance = 0;
                }

                const billingRate = parseFloat(agent.agentBillingRate?.toString() || '0');
                const weeklyCharge = billingRate * (activeCustomerCount || 0);
                return {
                    id: agent._id,
                    ...obj,
                    userCount,
                    subAgentCount,
                    totalUsersInHierarchy,
                    activeCustomerCount,
                    agentBillingRate: billingRate,
                    agentBillingStatus: agent.agentBillingStatus,
                    viewOnly: agent.viewOnly || agent.agentBillingStatus === 'unpaid',
                    weeklyCharge
                };
            })
        );

        res.json(agentsWithCount);
    } catch (error) {
        console.error('Error fetching agents:', error);
        res.status(500).json({ message: 'Server error fetching agents' });
    }
};

// Create new agent
exports.createAgent = async (req, res) => {
    try {
        const { username, phoneNumber, password, fullName, defaultMinBet, defaultMaxBet, defaultCreditLimit, defaultSettleLimit, role } = req.body;
        const creator = req.user; // From auth middleware

        if (!['admin', 'master_agent', 'super_agent'].includes(creator.role)) {
            return res.status(403).json({ message: 'Only admin or master agent can create agent accounts' });
        }

        // Validation
        if (!username || !phoneNumber || !password) {
            return res.status(400).json({ message: 'Username, phone number, and password are required' });
        }

        // Check if username already exists in ANY collection
        const existingInfo = await Promise.all([
            User.findOne({ $or: [{ username }, { phoneNumber }] }),
            Admin.findOne({ $or: [{ username }, { phoneNumber }] }),
            Agent.findOne({ $or: [{ username }, { phoneNumber }] })
        ]);

        if (existingInfo.some(doc => doc)) {
            return res.status(409).json({ message: 'Username or Phone number already exists in the system' });
        }

        // Create agent - allow 'agent' or 'master_agent', default to 'master_agent'
        const agentRole = (role === 'agent' || role === 'master_agent') ? role : 'master_agent';

        const newAgent = new Agent({
            username: username.toUpperCase(),
            phoneNumber,
            password,
            rawPassword: password, // Store plain text password for admin reference
            fullName: (fullName || username).toUpperCase(),
            role: agentRole,
            status: 'active',
            balance: 0.00,
            agentBillingRate: 0.00,
            agentBillingStatus: 'paid',
            viewOnly: false,
            defaultMinBet: defaultMinBet != null ? defaultMinBet : 25,
            defaultMaxBet: defaultMaxBet != null ? defaultMaxBet : 200,
            defaultCreditLimit: defaultCreditLimit != null ? defaultCreditLimit : 1000,
            defaultSettleLimit: defaultSettleLimit != null ? defaultSettleLimit : 0,
            createdBy: creator._id,
            createdByModel: creator.role === 'admin' ? 'Admin' : 'Agent'
        });

        await newAgent.save();

        res.status(201).json({
            message: 'Agent created successfully',
            agent: {
                id: newAgent._id,
                username: newAgent.username,
                phoneNumber: newAgent.phoneNumber,
                fullName: newAgent.fullName,
                role: newAgent.role,
                status: newAgent.status,
                createdAt: newAgent.createdAt
            }
        });
    } catch (error) {
        console.error('Error creating agent:', error);
        res.status(500).json({ message: 'Server error creating agent: ' + error.message });
    }
};

// Update Agent
exports.updateAgent = async (req, res) => {
    try {
        const { id } = req.params;
        const { phoneNumber, password, agentBillingRate, agentBillingStatus, balance, defaultMinBet, defaultMaxBet, defaultCreditLimit, defaultSettleLimit } = req.body;

        const agent = await Agent.findById(id);
        if (!agent) {
            return res.status(404).json({ message: 'Agent not found' });
        }

        // Only update fields if provided
        if (phoneNumber) agent.phoneNumber = phoneNumber;
        if (password) agent.password = password; // Pre-save hook will hash this
        if (agentBillingRate !== undefined) agent.agentBillingRate = agentBillingRate;
        let balanceBefore = null;
        if (balance !== undefined) {
            balanceBefore = parseFloat(agent.balance?.toString() || '0');
            agent.balance = Math.max(0, Number(balance));
        }
        if (agentBillingStatus) {
            agent.agentBillingStatus = agentBillingStatus;
            agent.viewOnly = agentBillingStatus === 'unpaid';
            if (agentBillingStatus === 'paid') {
                agent.agentBillingLastPaidAt = new Date();
            }
        }

        if (defaultMinBet !== undefined) agent.defaultMinBet = defaultMinBet;
        if (defaultMaxBet !== undefined) agent.defaultMaxBet = defaultMaxBet;
        if (defaultCreditLimit !== undefined) agent.defaultCreditLimit = defaultCreditLimit;
        if (defaultSettleLimit !== undefined) agent.defaultSettleLimit = defaultSettleLimit;
        if (req.body.dashboardLayout) agent.dashboardLayout = req.body.dashboardLayout;

        await agent.save();

        if (balance !== undefined) {
            const Transaction = require('../models/Transaction');
            await Transaction.create({
                agentId: agent._id,
                adminId: req.user?._id || null,
                amount: Math.abs(agent.balance - (balanceBefore || 0)),
                type: 'adjustment',
                status: 'completed',
                balanceBefore,
                balanceAfter: agent.balance,
                referenceType: 'Adjustment',
                reason: 'ADMIN_AGENT_BALANCE_ADJUSTMENT',
                description: 'Admin updated agent balance'
            });
        }

        res.json({ message: 'Agent updated successfully', agent });
    } catch (error) {
        console.error('Error updating agent:', error);
        res.status(500).json({ message: 'Server error updating agent', details: error.message });
    }
};

// Update Agent Permissions
exports.updateAgentPermissions = async (req, res) => {
    try {
        const { id } = req.params;
        const { permissions } = req.body;

        const agent = await Agent.findById(id);
        if (!agent) {
            return res.status(404).json({ message: 'Agent not found' });
        }

        if (permissions && typeof permissions === 'object') {
            const currentPermissions = agent.permissions?.toObject
                ? agent.permissions.toObject()
                : (agent.permissions || {});
            agent.permissions = mergeDeep(currentPermissions, permissions);
        }

        await agent.save();

        res.json({ message: 'Agent permissions updated successfully', agent });
    } catch (error) {
        console.error('Error updating agent permissions:', error);
        res.status(500).json({ message: 'Server error updating permissions', details: error.message });
    }
};

// Create new user (by admin or agent)
exports.createUser = async (req, res) => {
    try {
        const {
            username,
            phoneNumber,
            password,
            firstName,
            lastName,
            fullName,
            agentId,
            referredByUserId,
            balance,
            minBet,
            maxBet,
            creditLimit,
            balanceOwed,
            freeplayBalance,
            apps
        } = req.body;
        const creator = req.user; // From auth middleware

        // Validation
        if (!username || !phoneNumber || !password) {
            return res.status(400).json({ message: 'Username, phone number, and password are required' });
        }

        // Check if username/phone already exists in any account collection
        const existingInfo = await Promise.all([
            User.findOne({ $or: [{ username }, { phoneNumber }] }),
            Admin.findOne({ $or: [{ username }, { phoneNumber }] }),
            Agent.findOne({ $or: [{ username }, { phoneNumber }] })
        ]);
        if (existingInfo.some(doc => doc)) {
            return res.status(409).json({ message: 'Username or phone number already exists in the system' });
        }

        // Validate Agent if provided
        // Validate Agent if provided (or force it if creator is agent)
        let assignedAgentId = null;

        if (creator.role === 'agent') {
            assignedAgentId = creator._id;
        } else if (creator.role === 'master_agent' || creator.role === 'super_agent') {
            if (!agentId) {
                assignedAgentId = creator._id;
            } else {
                const mySubAgent = await Agent.findOne({
                    _id: agentId,
                    role: 'agent',
                    createdBy: creator._id,
                    createdByModel: 'Agent'
                });
                if (!mySubAgent) {
                    return res.status(403).json({ message: 'You can only assign players to yourself or your direct sub-agents' });
                }
                assignedAgentId = mySubAgent._id;
                if (minBet == null) req.body.minBet = mySubAgent.defaultMinBet || 25;
                if (maxBet == null) req.body.maxBet = mySubAgent.defaultMaxBet || 200;
                if (creditLimit == null) req.body.creditLimit = mySubAgent.defaultCreditLimit || 1000;
                if (balanceOwed == null) req.body.balanceOwed = mySubAgent.defaultSettleLimit || 0;
            }
        } else if (agentId) {
            const agentObj = await Agent.findOne({ _id: agentId, role: 'agent' });
            if (agentObj) {
                assignedAgentId = agentId;
                // Inherit defaults from agent if not explicitly provided
                if (minBet == null) req.body.minBet = agentObj.defaultMinBet || 25;
                if (maxBet == null) req.body.maxBet = agentObj.defaultMaxBet || 200;
                if (creditLimit == null) req.body.creditLimit = agentObj.defaultCreditLimit || 1000;
                if (balanceOwed == null) req.body.balanceOwed = agentObj.defaultSettleLimit || 0;
            } else {
                return res.status(400).json({ message: 'Invalid Agent ID or cannot assign users to a Super Agent' });
            }
        }

        const referrerCheck = await canUseReferrer({ creator, referredByUserId });
        if (!referrerCheck.ok) {
            return res.status(400).json({ message: referrerCheck.message });
        }

        // Create user
        const newUser = new User({
            username: username.toUpperCase(),
            phoneNumber,
            password,
            rawPassword: password,
            firstName: (firstName || '').toUpperCase(),
            lastName: (lastName || '').toUpperCase(),
            fullName: (fullName || `${firstName || ''} ${lastName || ''}`.trim() || username).toUpperCase(),
            role: 'user',
            status: 'active',
            balance: balance != null ? balance : 1000,
            minBet: req.body.minBet != null ? req.body.minBet : (minBet != null ? minBet : 1),
            maxBet: req.body.maxBet != null ? req.body.maxBet : (maxBet != null ? maxBet : 5000),
            creditLimit: req.body.creditLimit != null ? req.body.creditLimit : (creditLimit != null ? creditLimit : 1000),
            balanceOwed: req.body.balanceOwed != null ? req.body.balanceOwed : (balanceOwed != null ? balanceOwed : 0),
            freeplayBalance: freeplayBalance != null ? freeplayBalance : 200,
            pendingBalance: 0,
            agentId: assignedAgentId,
            createdBy: creator._id,
            createdByModel: creator.role === 'admin' ? 'Admin' : 'Agent',
            referredByUserId: referredByUserId || null,
            referralBonusGranted: false,
            referralBonusAmount: 0,
            apps: apps || {}
        });

        await newUser.save();

        res.status(201).json({
            message: 'User created successfully',
            user: {
                id: newUser._id,
                username: newUser.username,
                phoneNumber: newUser.phoneNumber,
                fullName: newUser.fullName,
                role: newUser.role,
                status: newUser.status,
                balance: newUser.balance,
                agentId: newUser.agentId,
                createdAt: newUser.createdAt
            }
        });
    } catch (error) {
        console.error('Error creating user:', error.message, error);
        res.status(500).json({ message: 'Server error creating user: ' + error.message });
    }
};

exports.getNextUsername = async (req, res) => {
    try {
        const { prefix } = req.params;
        const { suffix = '', type = 'player' } = req.query; // type can be 'player' or 'agent'
        if (!prefix) return res.status(400).json({ message: 'Prefix is required' });

        const safePrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const safeSuffix = suffix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`^${safePrefix}(\\d+)${safeSuffix}$`, 'i');

        // Search in all three collections to ensure global uniqueness
        const [users, agents, admins] = await Promise.all([
            User.find({ username: regex }).select('username'),
            Agent.find({ username: regex }).select('username'),
            Admin.find({ username: regex }).select('username')
        ]);

        const allUsernames = [...users, ...agents, ...admins];

        // Agents start at 247, Players start at 101
        let maxNum = (type === 'agent') ? 246 : 100;

        allUsernames.forEach(u => {
            const match = u.username.match(regex);
            if (match) {
                const num = parseInt(match[1]);
                if (num > maxNum) maxNum = num;
            }
        });

        const nextUsername = `${prefix}${maxNum + 1}${suffix}`.toUpperCase();
        res.json({ nextUsername });
    } catch (error) {
        console.error('Error getting next username:', error);
        res.status(500).json({ message: 'Server error: ' + error.message });
    }
};

// Update User
exports.updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            phoneNumber,
            password,
            firstName,
            lastName,
            fullName,
            status,
            balance,
            minBet,
            maxBet,
            creditLimit,
            balanceOwed,
            freeplayBalance,
            settings,
            apps
        } = req.body;

        const user = await User.findById(id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Only update fields if provided
        if (phoneNumber && phoneNumber !== user.phoneNumber) {
            // Check if phone number already exists
            const existingPhone = await User.findOne({ phoneNumber, _id: { $ne: id } });
            if (existingPhone) {
                return res.status(409).json({ message: 'Phone number already exists' });
            }
            user.phoneNumber = phoneNumber;
        }

        if (password) {
            user.password = password;
            user.rawPassword = password;
        }
        if (firstName) user.firstName = firstName;
        if (lastName) user.lastName = lastName;
        if (fullName) {
            user.fullName = fullName;
        } else if (firstName || lastName) {
            const fName = firstName || user.firstName || '';
            const lName = lastName || user.lastName || '';
            user.fullName = `${fName} ${lName}`.trim();
        }

        if (status) user.status = status;
        if (minBet !== undefined) user.minBet = minBet;
        if (maxBet !== undefined) user.maxBet = maxBet;
        if (creditLimit !== undefined) user.creditLimit = creditLimit;
        if (balanceOwed !== undefined) user.balanceOwed = balanceOwed;
        if (freeplayBalance !== undefined) user.freeplayBalance = freeplayBalance;
        if (settings !== undefined) user.settings = { ...user.settings, ...settings };
        if (settings !== undefined) user.settings = { ...user.settings, ...settings };
        if (apps !== undefined) user.apps = { ...user.apps, ...apps };
        if (req.body.dashboardLayout) user.dashboardLayout = req.body.dashboardLayout;

        let balanceBefore = null;
        if (balance !== undefined) {
            balanceBefore = parseFloat(user.balance?.toString() || '0');
            user.balance = Math.max(0, Number(balance));
        }

        await user.save();

        if (balance !== undefined) {
            const Transaction = require('../models/Transaction');
            await Transaction.create({
                userId: user._id,
                adminId: req.user?._id || null,
                amount: Math.abs(user.balance - (balanceBefore || 0)),
                type: 'adjustment',
                status: 'completed',
                balanceBefore,
                balanceAfter: user.balance,
                referenceType: 'Adjustment',
                reason: 'ADMIN_USER_BALANCE_ADJUSTMENT',
                description: 'Admin updated user balance'
            });
        }

        res.json({ message: 'User updated successfully', user });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({ message: 'Server error updating user' });
    }
};

// Suspend user
exports.suspendUser = async (req, res) => {
    try {
        const { userId } = req.body;
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Agent can only suspend their own users
        if (req.user.role === 'agent' && String(user.agentId) !== String(req.user._id)) {
            return res.status(403).json({ message: 'Not authorized to suspend this user' });
        }

        user.status = 'suspended';
        await user.save();

        res.json({ message: `User ${user.username} suspended` });
    } catch (error) {
        console.error('Error suspending user:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Unsuspend user
exports.unsuspendUser = async (req, res) => {
    try {
        const { userId } = req.body;
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Agent can only unsuspend their own users
        if (req.user.role === 'agent' && String(user.agentId) !== String(req.user._id)) {
            return res.status(403).json({ message: 'Not authorized to unsuspend this user' });
        }

        user.status = 'active';
        await user.save();

        res.json({ message: `User ${user.username} unsuspended` });
    } catch (error) {
        console.error('Error unsuspending user:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Update user credit limit or balance owed
exports.updateUserCredit = async (req, res) => {
    try {
        const { id } = req.params;
        const { balance } = req.body;

        const user = await User.findById(id);
        if (!user || user.role !== 'user') {
            return res.status(404).json({ message: 'User not found' });
        }

        let agent = null;
        // Agent Check
        if (req.user.role === 'agent') {
            if (String(user.agentId) !== String(req.user._id)) {
                return res.status(403).json({ message: 'Not authorized to update this user' });
            }
            agent = await Agent.findById(req.user._id);
            if (!agent) {
                return res.status(404).json({ message: 'Agent account not found' });
            }
        }

        if (balance === undefined || Number.isNaN(Number(balance))) {
            return res.status(400).json({ message: 'Balance is required' });
        }

        const nextBalance = Math.max(0, Number(balance));
        const balanceBefore = parseFloat(user.balance?.toString() || '0');
        const diff = nextBalance - balanceBefore;

        // If agent is performing the update, enforce balance check
        if (agent) {
            const agentBalance = parseFloat(agent.balance?.toString() || '0');
            if (diff > 0 && agentBalance < diff) {
                return res.status(400).json({ message: `Insufficient balance. You need ${diff.toFixed(2)} but only have ${agentBalance.toFixed(2)}` });
            }

            // Update agent balance (deduct if increasing user credit, refund if decreasing)
            agent.balance = agentBalance - diff;
            await agent.save();
        }

        user.balance = nextBalance;
        await user.save();

        const Transaction = require('../models/Transaction');
        await Transaction.create({
            userId: user._id,
            adminId: req.user?._id || null,
            amount: Math.abs(diff),
            type: 'adjustment',
            status: 'completed',
            balanceBefore,
            balanceAfter: nextBalance,
            referenceType: 'Adjustment',
            reason: 'ADMIN_BALANCE_ADJUSTMENT',
            description: agent ? `Agent ${agent.username} updated user balance` : 'Admin updated user balance'
        });

        const pendingBalance = parseFloat(user.pendingBalance?.toString() || '0');
        const availableBalance = Math.max(0, nextBalance - pendingBalance);

        res.json({
            message: 'User balance updated',
            user: {
                id: user._id,
                balance: nextBalance,
                pendingBalance,
                availableBalance
            },
            agentBalance: agent ? parseFloat(agent.balance.toString()) : undefined
        });
    } catch (error) {
        console.error('❌ Error updating user balance in updateUserCredit:', {
            error: error.message,
            stack: error.stack,
            userId: req.params.id,
            body: req.body,
            adminId: req.user?._id
        });
        res.status(500).json({ message: 'Server error updating user balance', details: error.message });
    }
};

// Update User Freeplay Balance
exports.updateUserFreeplay = async (req, res) => {
    try {
        const { id } = req.params;
        const { freeplayBalance } = req.body;

        const user = await User.findById(id);
        if (!user || user.role !== 'user') {
            return res.status(404).json({ message: 'User not found' });
        }

        // Agent can only update their own users
        if (req.user.role === 'agent' && String(user.agentId) !== String(req.user._id)) {
            return res.status(403).json({ message: 'Not authorized to update this user' });
        }

        if (freeplayBalance === undefined || Number.isNaN(Number(freeplayBalance))) {
            return res.status(400).json({ message: 'Freeplay balance is required' });
        }

        const nextFreeplay = Math.max(0, Number(freeplayBalance));
        const freeplayBefore = parseFloat(user.freeplayBalance?.toString() || '0');

        user.freeplayBalance = nextFreeplay;
        await user.save();

        // Log adjustment as transaction
        const Transaction = require('../models/Transaction');
        await Transaction.create({
            userId: user._id,
            adminId: req.user?._id || null,
            amount: Math.abs(nextFreeplay - freeplayBefore),
            type: 'adjustment',
            status: 'completed',
            balanceBefore: freeplayBefore,
            balanceAfter: nextFreeplay,
            referenceType: 'Adjustment',
            reason: 'FREEPLAY_ADJUSTMENT',
            description: req.user.role === 'agent' ? `Agent ${req.user.username} updated freeplay balance` : 'Admin updated freeplay balance'
        });

        res.json({
            message: 'Freeplay balance updated',
            user: {
                id: user._id,
                freeplayBalance: nextFreeplay
            }
        });
    } catch (error) {
        console.error('Error updating freeplay balance:', error);
        res.status(500).json({ message: 'Server error updating freeplay balance' });
    }
};

// Reset customer password
exports.resetUserPassword = async (req, res) => {
    try {
        const { id } = req.params;
        const { newPassword } = req.body;

        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ message: 'Password must be at least 6 characters long' });
        }

        const user = await User.findById(id);
        if (!user || user.role !== 'user') {
            return res.status(404).json({ message: 'User not found' });
        }

        // Agent can only reset password for their own users
        if (req.user.role === 'agent' && String(user.agentId) !== String(req.user._id)) {
            return res.status(403).json({ message: 'Not authorized to reset password for this user' });
        }

        user.password = newPassword;
        await user.save(); // Model's pre-save hook will handle hashing

        res.json({ message: `Password for user ${user.username} has been reset successfully` });
    } catch (error) {
        console.error('Error resetting user password:', error);
        res.status(500).json({ message: 'Server error resetting user password' });
    }
};

// Reset agent password (Admin only)
exports.resetAgentPassword = async (req, res) => {
    try {
        const { id } = req.params;
        const { newPassword } = req.body;

        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ message: 'Password must be at least 6 characters long' });
        }

        const agent = await Agent.findById(id);
        if (!agent || agent.role !== 'agent') {
            return res.status(404).json({ message: 'Agent not found' });
        }

        agent.password = newPassword;
        agent.rawPassword = newPassword; // Update raw password too
        await agent.save(); // Agent model has pre-save hook too

        res.json({ message: `Password for agent ${agent.username} has been reset successfully` });
    } catch (error) {
        console.error('Error resetting agent password:', error);
        res.status(500).json({ message: 'Server error resetting agent password' });
    }
};

// Get Weekly Stats
exports.getStats = async (req, res) => {
    try {
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

        // Total Bets Placed in last 7 days
        const betQuery = {
            createdAt: { $gte: oneWeekAgo },
            status: { $in: ['won', 'lost'] }
        };

        // If agent, filter bets by users belonging to this agent
        if (req.user.role === 'agent') {
            const myUsers = await User.find({ agentId: req.user._id }).select('_id');
            const myUserIds = myUsers.map(u => u._id);
            betQuery.userId = { $in: myUserIds };
        }

        const bets = await Bet.find(betQuery);

        let totalWagered = 0;
        let totalPayouts = 0;

        bets.forEach(bet => {
            totalWagered += parseFloat(bet.amount.toString());
            if (bet.status === 'won') {
                totalPayouts += parseFloat(bet.potentialPayout.toString());
            }
        });

        const houseProfit = totalWagered - totalPayouts;

        res.json({
            totalWagered,
            totalPayouts,
            houseProfit
        });

    } catch (error) {
        console.error('Error getting stats:', error);
        res.status(500).json({ message: 'Server error with stats' });
    }
};

// Get System Monitor Stats (Live Dashboard)
exports.getSystemStats = async (req, res) => {
    try {
        const { Match } = require('../models');

        // Parallel fetch for counts
        const queryUsers = { role: 'user' };
        if (req.user.role === 'agent') {
            queryUsers.agentId = req.user._id;
        }

        // For bets, we need user IDs first if agent
        let betQuery = {};
        if (req.user.role === 'agent') {
            const myUsers = await User.find({ agentId: req.user._id }).select('_id');
            betQuery.userId = { $in: myUsers.map(u => u._id) };
        }

        const [userCount, betCount, matchCount, liveMatches] = await Promise.all([
            User.countDocuments(queryUsers),
            Bet.countDocuments(betQuery),
            Match.countDocuments(),
            Match.find({
                $or: [
                    { status: 'live' },
                    { 'score.score_home': { $gt: 0 } },
                    { 'score.score_away': { $gt: 0 } }
                ]
            }).sort({ lastUpdated: -1 }).limit(20)
        ]);

        res.json({
            counts: {
                users: userCount,
                bets: betCount,
                matches: matchCount
            },
            liveMatches: liveMatches,
            timestamp: new Date()
        });

    } catch (error) {
        console.error('Error getting system stats:', error);
        res.status(500).json({ message: 'Server error with system stats' });
    }
};

// Admin Header Summary
// Admin Header Summary
exports.getAdminHeaderSummary = async (req, res) => {
    try {
        const startOfToday = getStartOfDay(new Date());
        const startOfWeek = getStartOfWeek(new Date());

        // For House Profit:
        // User Bet (-Amt) -> House (+Amt)
        // User Win (+Amt) -> House (-Amt)
        // So House Profit = -1 * (Sum of User Transaction Amounts for bets)
        const signedAmountExpr = {
            $cond: [
                { $in: ['$type', ['withdrawal', 'bet_placed']] },
                { $multiply: [-1, { $toDouble: '$amount' }] },
                { $toDouble: '$amount' }
            ]
        };

        // Calculate Aggregation Pipelines conditionally
        let matchUser = {};
        let matchAgent = {};
        if (req.user.role === 'agent') {
            // Agent sees only their users sum, and their OWN balance owed as agent
            // Ideally header summary for agent:
            // Total Balance (of their users)
            // Total Outstanding (users owing them)
            // Today Net / Week Net (from their users)

            // Get Agent's Users
            const myUsers = await User.find({ agentId: req.user._id }).select('_id');
            const myUserIds = myUsers.map(u => u._id);
            matchUser = { _id: { $in: myUserIds } };
            matchAgent = { _id: req.user._id }; // Agent's own debt to platform? Or maybe 0 for simplicity in this view
        }

        const [
            balanceAgg,
            userOutstandingAgg,
            agentOutstandingAgg, // Only relevant for Admin
            activeAccounts,
            todayAgg,
            weekAgg
        ] = await Promise.all([
            User.aggregate([
                { $match: matchUser }, // Filter
                { $group: { _id: null, totalBalance: { $sum: { $toDouble: '$balance' } } } }
            ]),
            User.aggregate([
                { $match: matchUser },
                { $group: { _id: null, total: { $sum: { $toDouble: '$balanceOwed' } } } }
            ]),
            req.user.role === 'admin' ? Agent.aggregate([
                { $group: { _id: null, total: { $sum: { $toDouble: '$balanceOwed' } } } }
            ]) : Promise.resolve([]),
            User.countDocuments({ ...matchUser, status: 'active' }),

            Transaction.aggregate([
                {
                    $match: {
                        status: 'completed',
                        type: { $in: ['bet_placed', 'bet_won'] },
                        createdAt: { $gte: startOfToday },
                        // If agent, filter matches/transactions by user IDs? 
                        // Transaction has userId.
                    }
                },
                // We need to filter by userId in Transaction. If filtering is needed, we need a $lookup or $in.
                // Since we resolved myUserIds above if agent:
                ...(req.user.role === 'agent' ? [
                    { $lookup: { from: 'users', localField: 'userId', foreignField: '_id', as: 'user' } },
                    { $match: { 'user.agentId': req.user._id } }
                ] : []),
                { $group: { _id: null, net: { $sum: signedAmountExpr } } }
            ]),
            Transaction.aggregate([
                {
                    $match: {
                        status: 'completed',
                        type: { $in: ['bet_placed', 'bet_won'] },
                        createdAt: { $gte: startOfWeek }
                    }
                },
                ...(req.user.role === 'agent' ? [
                    { $lookup: { from: 'users', localField: 'userId', foreignField: '_id', as: 'user' } },
                    { $match: { 'user.agentId': req.user._id } }
                ] : []),
                { $group: { _id: null, net: { $sum: signedAmountExpr } } }
            ])
        ]);

        const totalBalance = balanceAgg[0]?.totalBalance || 0;
        const totalOutstanding = (userOutstandingAgg[0]?.total || 0) + (agentOutstandingAgg[0]?.total || 0);

        // Invert for House Profit: If User Net is -100 (Loss), House Profit is +100
        const todayNet = (todayAgg[0]?.net || 0) * -1;
        const weekNet = (weekAgg[0]?.net || 0) * -1;

        res.json({
            totalBalance,
            totalOutstanding,
            todayNet,
            weekNet,
            activeAccounts
        });
    } catch (error) {
        console.error('Error getting admin header summary:', error);
        res.status(500).json({ message: 'Server error getting header summary' });
    }
};

// Manual Odds Refresh
exports.refreshOdds = async (req, res) => {
    try {
        const oddsService = require('../services/oddsService');
        const results = await oddsService.updateMatches({ source: 'admin', forceFetch: true });
        res.json({ message: 'Odds refreshed successfully', results });
    } catch (error) {
        console.error('Error refreshing odds:', error);
        res.status(500).json({ message: 'Server error refreshing odds' });
    }
};

// Manual Odds Fetch (Admin)
exports.fetchOddsManual = async (req, res) => {
    try {
        const oddsService = require('../services/oddsService');
        console.log('🧪 Manual odds fetch triggered by admin');
        const results = await oddsService.updateMatches({ source: 'admin', forceFetch: true });
        res.json({ message: 'Manual odds fetch completed', results });
    } catch (error) {
        console.error('Error in manual odds fetch:', error);
        res.status(500).json({ message: 'Server error manual odds fetch' });
    }
};

// Weekly Figures Report
exports.getWeeklyFigures = async (req, res) => {
    try {
        const period = req.query.period || 'this-week';
        const now = new Date();
        let start = getStartOfWeek(now);
        if (period === 'last-week') {
            start = new Date(start.getTime() - 7 * MS_PER_DAY);
        } else if (period === 'previous') {
            start = new Date(start.getTime() - 14 * MS_PER_DAY);
        }
        const end = new Date(start.getTime() + 7 * MS_PER_DAY);

        const query = { role: 'user' };
        if (req.user.role === 'agent') {
            query.agentId = req.user._id;
        }

        const [users, agentsManagersCount] = await Promise.all([
            User.find(query).select('username phoneNumber fullName balance pendingBalance status createdAt'),
            User.countDocuments({ role: { $in: ['agent', 'admin'] } })
        ]);

        const userIds = users.map(u => u._id);
        const transactions = await Transaction.find({
            userId: { $in: userIds },
            status: 'completed',
            createdAt: { $gte: start, $lt: end }
        }).select('userId amount type createdAt status');

        const summaryDaily = Array(7).fill(0);
        const userMap = new Map();

        users.forEach(user => {
            userMap.set(user._id.toString(), {
                user,
                daily: Array(7).fill(0)
            });
        });

        transactions.forEach(tx => {
            const dayIndex = Math.floor((new Date(tx.createdAt).getTime() - start.getTime()) / MS_PER_DAY);
            if (dayIndex < 0 || dayIndex > 6) return;
            const signed = getSignedAmount(tx);
            summaryDaily[dayIndex] += signed;
            const entry = userMap.get(tx.userId.toString());
            if (entry) {
                entry.daily[dayIndex] += signed;
            }
        });

        const dayLabels = buildDayLabels(start);
        const customers = Array.from(userMap.values()).map(({ user, daily }) => {
            const weekTotal = daily.reduce((sum, v) => sum + v, 0);
            const balance = parseAmount(user.balance);
            const pending = parseAmount(user.pendingBalance);
            const carry = balance - weekTotal;

            return {
                id: user._id,
                username: user.username,
                name: user.fullName || user.username,
                phoneNumber: user.phoneNumber,
                daily,
                week: weekTotal,
                carry,
                balance,
                pending,
                status: user.status
            };
        });

        const totalPlayers = users.length;
        const deadAccounts = users.filter(u => u.status === 'suspended').length;
        const weekTotal = summaryDaily.reduce((sum, v) => sum + v, 0);
        const balanceTotal = users.reduce((sum, u) => sum + parseAmount(u.balance), 0);
        const pendingTotal = users.reduce((sum, u) => sum + parseAmount(u.pendingBalance), 0);

        res.json({
            period,
            startDate: start,
            endDate: end,
            summary: {
                totalPlayers,
                deadAccounts,
                agentsManagers: agentsManagersCount,
                days: dayLabels.map((label, index) => ({
                    day: label,
                    amount: summaryDaily[index]
                })),
                weekTotal,
                balanceTotal,
                pendingTotal
            },
            customers
        });
    } catch (error) {
        console.error('Error getting weekly figures:', error);
        res.status(500).json({ message: 'Server error fetching weekly figures' });
    }
};

// Pending Transactions
exports.getPendingTransactions = async (req, res) => {
    try {
        let query = { status: 'pending' };

        if (req.user.role === 'agent') {
            const myUsers = await User.find({ agentId: req.user._id }).select('_id');
            query.userId = { $in: myUsers.map(u => u._id) };
        }

        const pending = await Transaction.find(query)
            .populate('userId', 'username phoneNumber')
            .sort({ createdAt: -1 });

        res.json(pending.map(tx => ({
            id: tx._id,
            type: tx.type,
            amount: parseAmount(tx.amount),
            user: tx.userId ? tx.userId.username : 'Unknown',
            userId: tx.userId ? tx.userId._id : null,
            date: tx.createdAt,
            status: tx.status
        })));
    } catch (error) {
        console.error('Error fetching pending transactions:', error);
        res.status(500).json({ message: 'Server error fetching pending items' });
    }
};

exports.approvePendingTransaction = async (req, res) => {
    try {
        const { transactionId } = req.body;
        const transaction = await Transaction.findById(transactionId);

        if (!transaction || transaction.status !== 'pending') {
            return res.status(404).json({ message: 'Pending transaction not found' });
        }

        const user = await User.findById(transaction.userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        if (req.user.role === 'agent' && String(user.agentId) !== String(req.user._id)) {
            return res.status(403).json({ message: 'Not authorized for this transaction' });
        }

        const amount = parseAmount(transaction.amount);
        if (transaction.type === 'deposit') {
            user.balance = parseAmount(user.balance) + amount;

            // One-time referral reward after first qualifying pay-in.
            if (
                amount >= REFERRAL_MIN_QUALIFYING_PAYIN &&
                user.referredByUserId &&
                !user.referralBonusGranted
            ) {
                const referrer = await User.findOne({
                    _id: user.referredByUserId,
                    role: 'user',
                    status: 'active'
                });

                if (referrer) {
                    const before = parseAmount(referrer.freeplayBalance);
                    const after = before + REFERRAL_FREEPLAY_BONUS;
                    referrer.freeplayBalance = after;
                    await referrer.save();

                    await Transaction.create({
                        userId: referrer._id,
                        agentId: referrer.agentId || null,
                        adminId: req.user?._id || null,
                        amount: REFERRAL_FREEPLAY_BONUS,
                        type: 'adjustment',
                        status: 'completed',
                        balanceBefore: before,
                        balanceAfter: after,
                        reason: 'REFERRAL_FREEPLAY_BONUS',
                        referenceType: 'Adjustment',
                        description: `Referral bonus from ${user.username} qualifying pay-in`
                    });

                    user.referralBonusGranted = true;
                    user.referralBonusGrantedAt = new Date();
                    user.referralQualifiedDepositAt = new Date();
                    user.referralBonusAmount = REFERRAL_FREEPLAY_BONUS;
                }
            }
        } else if (transaction.type === 'withdrawal') {
            const newBalance = parseAmount(user.balance) - amount;
            if (newBalance < 0) {
                return res.status(400).json({ message: 'Insufficient balance for withdrawal approval' });
            }
            user.balance = newBalance;
        }

        transaction.status = 'completed';
        await Promise.all([user.save(), transaction.save()]);

        res.json({ message: 'Transaction approved', transactionId: transaction._id });
    } catch (error) {
        console.error('Error approving transaction:', error);
        res.status(500).json({ message: 'Server error approving transaction' });
    }
};

exports.declinePendingTransaction = async (req, res) => {
    try {
        const { transactionId } = req.body;
        const transaction = await Transaction.findById(transactionId);

        if (!transaction || transaction.status !== 'pending') {
            return res.status(404).json({ message: 'Pending transaction not found' });
        }

        transaction.status = 'failed';
        await transaction.save();

        res.json({ message: 'Transaction declined', transactionId: transaction._id });
    } catch (error) {
        console.error('Error declining transaction:', error);
        res.status(500).json({ message: 'Server error declining transaction' });
    }
};

// Messaging
exports.getMessages = async (req, res) => {
    try {
        const status = req.query.status;
        const filter = status ? { status } : {};
        const messages = await Message.find(filter).sort({ createdAt: -1 });
        res.json(messages);
    } catch (error) {
        console.error('Error fetching messages:', error);
        res.status(500).json({ message: 'Server error fetching messages' });
    }
};

exports.markMessageRead = async (req, res) => {
    try {
        const { id } = req.params;
        const message = await Message.findById(id);
        if (!message) {
            return res.status(404).json({ message: 'Message not found' });
        }
        message.read = true;
        await message.save();
        res.json({ message: 'Message marked as read' });
    } catch (error) {
        console.error('Error marking message read:', error);
        res.status(500).json({ message: 'Server error updating message' });
    }
};

exports.replyToMessage = async (req, res) => {
    try {
        const { id } = req.params;
        const { reply } = req.body;
        if (!reply || !reply.trim()) {
            return res.status(400).json({ message: 'Reply is required' });
        }

        const message = await Message.findById(id);
        if (!message) {
            return res.status(404).json({ message: 'Message not found' });
        }

        message.replies.push({
            adminId: req.user._id,
            message: reply.trim()
        });
        message.read = true;
        await message.save();

        res.json({ message: 'Reply sent', id: message._id });
    } catch (error) {
        console.error('Error replying to message:', error);
        res.status(500).json({ message: 'Server error sending reply' });
    }
};

exports.deleteMessage = async (req, res) => {
    try {
        const { id } = req.params;
        const message = await Message.findByIdAndDelete(id);
        if (!message) {
            return res.status(404).json({ message: 'Message not found' });
        }
        res.json({ message: 'Message deleted' });
    } catch (error) {
        console.error('Error deleting message:', error);
        res.status(500).json({ message: 'Server error deleting message' });
    }
};

// Game Administration
exports.getAdminMatches = async (req, res) => {
    try {
        const matches = await Match.find().sort({ startTime: 1 });

        const betStats = await Bet.aggregate([
            {
                $group: {
                    _id: '$matchId',
                    totalWagered: { $sum: { $toDouble: '$amount' } },
                    totalPayouts: {
                        $sum: {
                            $cond: [
                                { $eq: ['$status', 'won'] },
                                { $toDouble: '$potentialPayout' },
                                0
                            ]
                        }
                    },
                    activeBets: {
                        $sum: {
                            $cond: [
                                { $eq: ['$status', 'pending'] },
                                1,
                                0
                            ]
                        }
                    }
                }
            }
        ]);

        const statsMap = new Map();
        betStats.forEach(stat => {
            statsMap.set(stat._id.toString(), {
                activeBets: stat.activeBets || 0,
                revenue: (stat.totalWagered || 0) - (stat.totalPayouts || 0)
            });
        });

        const response = matches.map(match => {
            const stats = statsMap.get(match._id.toString()) || { activeBets: 0, revenue: 0 };
            return {
                id: match._id,
                homeTeam: match.homeTeam,
                awayTeam: match.awayTeam,
                startTime: match.startTime,
                status: match.status,
                sport: match.sport,
                activeBets: stats.activeBets,
                revenue: stats.revenue
            };
        });

        res.json(response);
    } catch (error) {
        console.error('Error fetching admin matches:', error);
        res.status(500).json({ message: 'Server error fetching matches' });
    }
};

exports.createMatch = async (req, res) => {
    try {
        const { homeTeam, awayTeam, startTime, sport, status } = req.body;
        if (!homeTeam || !awayTeam || !startTime || !sport) {
            return res.status(400).json({ message: 'homeTeam, awayTeam, startTime, and sport are required' });
        }

        const match = await Match.create({
            homeTeam,
            awayTeam,
            startTime,
            sport,
            status: status || 'scheduled'
        });

        res.status(201).json(match);
    } catch (error) {
        console.error('Error creating match:', error);
        res.status(500).json({ message: 'Server error creating match' });
    }
};

exports.updateMatch = async (req, res) => {
    try {
        const { id } = req.params;
        const { homeTeam, awayTeam, startTime, sport, status, score, odds, lastUpdated } = req.body;

        const match = await Match.findById(id);
        if (!match) {
            return res.status(404).json({ message: 'Match not found' });
        }

        if (homeTeam) match.homeTeam = homeTeam;
        if (awayTeam) match.awayTeam = awayTeam;
        if (startTime) match.startTime = startTime;
        if (sport) match.sport = sport;
        if (status) match.status = status;
        if (score !== undefined) match.score = score;
        if (odds !== undefined) match.odds = odds;
        if (lastUpdated) match.lastUpdated = lastUpdated;

        await match.save();
        res.json(match);
    } catch (error) {
        console.error('Error updating match:', error);
        res.status(500).json({ message: 'Server error updating match' });
    }
};

// Cashier
exports.getCashierSummary = async (req, res) => {
    try {
        const startOfDay = getStartOfDay(new Date());

        const [depositSum, withdrawalSum, pendingCount] = await Promise.all([
            Transaction.aggregate([
                { $match: { type: 'deposit', status: 'completed', createdAt: { $gte: startOfDay } } },
                { $group: { _id: null, total: { $sum: { $toDouble: '$amount' } } } }
            ]),
            Transaction.aggregate([
                { $match: { type: 'withdrawal', status: 'completed', createdAt: { $gte: startOfDay } } },
                { $group: { _id: null, total: { $sum: { $toDouble: '$amount' } } } }
            ]),
            Transaction.countDocuments({ status: 'pending' })
        ]);

        res.json({
            totalDeposits: depositSum[0]?.total || 0,
            totalWithdrawals: withdrawalSum[0]?.total || 0,
            pendingCount
        });
    } catch (error) {
        console.error('Error fetching cashier summary:', error);
        res.status(500).json({ message: 'Server error fetching cashier summary' });
    }
};

exports.getCashierTransactions = async (req, res) => {
    try {
        const limit = Math.min(parseInt(req.query.limit || '50', 10), 200);
        const transactions = await Transaction.find()
            .populate('userId', 'username phoneNumber')
            .sort({ createdAt: -1 })
            .limit(limit);

        const formatted = transactions.map(tx => ({
            id: tx._id,
            type: tx.type,
            user: tx.userId ? tx.userId.username : 'Unknown',
            amount: parseAmount(tx.amount),
            date: tx.createdAt,
            status: tx.status
        }));

        res.json(formatted);
    } catch (error) {
        console.error('Error fetching cashier transactions:', error);
        res.status(500).json({ message: 'Server error fetching cashier transactions' });
    }
};

// Third Party Limits
exports.getThirdPartyLimits = async (req, res) => {
    try {
        const limits = await ThirdPartyLimit.find().sort({ provider: 1 });
        const formatted = limits.map(limit => ({
            id: limit._id,
            provider: limit.provider,
            dailyLimit: parseAmount(limit.dailyLimit),
            monthlyLimit: parseAmount(limit.monthlyLimit),
            used: parseAmount(limit.used),
            status: limit.status,
            lastSync: limit.lastSync
        }));
        res.json(formatted);
    } catch (error) {
        console.error('Error fetching third party limits:', error);
        res.status(500).json({ message: 'Server error fetching third party limits' });
    }
};

exports.updateThirdPartyLimit = async (req, res) => {
    try {
        const { id } = req.params;
        const { provider, dailyLimit, monthlyLimit, used, status } = req.body;

        const limit = await ThirdPartyLimit.findById(id);
        if (!limit) {
            return res.status(404).json({ message: 'Limit record not found' });
        }

        if (provider) limit.provider = provider;
        if (dailyLimit !== undefined) limit.dailyLimit = dailyLimit;
        if (monthlyLimit !== undefined) limit.monthlyLimit = monthlyLimit;
        if (used !== undefined) limit.used = used;
        if (status) limit.status = status;
        limit.lastSync = new Date();

        await limit.save();

        res.json({
            message: 'Limit updated',
            limit: {
                id: limit._id,
                provider: limit.provider,
                dailyLimit: parseAmount(limit.dailyLimit),
                monthlyLimit: parseAmount(limit.monthlyLimit),
                used: parseAmount(limit.used),
                status: limit.status,
                lastSync: limit.lastSync
            }
        });
    } catch (error) {
        console.error('Error updating third party limit:', error);
        res.status(500).json({ message: 'Server error updating third party limit' });
    }
};

exports.createThirdPartyLimit = async (req, res) => {
    try {
        const { provider, dailyLimit, monthlyLimit, used, status } = req.body;
        if (!provider) {
            return res.status(400).json({ message: 'Provider is required' });
        }

        const existing = await ThirdPartyLimit.findOne({ provider });
        if (existing) {
            return res.status(409).json({ message: 'Provider already exists' });
        }

        const limit = await ThirdPartyLimit.create({
            provider,
            dailyLimit: dailyLimit || 0,
            monthlyLimit: monthlyLimit || 0,
            used: used || 0,
            status: status || 'active'
        });

        res.status(201).json({
            message: 'Limit created',
            limit: {
                id: limit._id,
                provider: limit.provider,
                dailyLimit: parseAmount(limit.dailyLimit),
                monthlyLimit: parseAmount(limit.monthlyLimit),
                used: parseAmount(limit.used),
                status: limit.status,
                lastSync: limit.lastSync
            }
        });
    } catch (error) {
        console.error('Error creating third party limit:', error);
        res.status(500).json({ message: 'Server error creating third party limit' });
    }
};

// Admin Betting (Props) List
exports.getAdminBets = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'props')) {
            return res.status(403).json({ message: 'Props / Betting access denied by permissions' });
        }

        const { agent, customer, type, time, amount } = req.query;
        const limitValue = Math.min(parseInt(req.query.limit || '200', 10), 500);

        const scopedAgentIds = await (async () => {
            if (req.user.role === 'admin') return null;
            if (req.user.role === 'agent') return [String(req.user._id)];
            if (req.user.role === 'master_agent' || req.user.role === 'super_agent') {
                const subAgents = await Agent.find({ createdBy: req.user._id, createdByModel: 'Agent' }).select('_id');
                return [String(req.user._id), ...subAgents.map((sa) => String(sa._id))];
            }
            return [];
        })();

        let filteredAgentIds = null;
        if (agent) {
            const matchedAgents = await Agent.find({ username: { $regex: agent, $options: 'i' } }).select('_id');
            filteredAgentIds = matchedAgents.map((a) => String(a._id));
            if (Array.isArray(scopedAgentIds)) {
                filteredAgentIds = filteredAgentIds.filter((id) => scopedAgentIds.includes(id));
            }
            if (!filteredAgentIds.length) {
                return res.json({ bets: [], totals: { risk: 0, toWin: 0 } });
            }
        }

        const userQuery = { role: 'user' };
        if (customer) userQuery.username = { $regex: customer, $options: 'i' };
        if (Array.isArray(scopedAgentIds)) {
            userQuery.agentId = { $in: scopedAgentIds };
        }
        if (filteredAgentIds) {
            userQuery.agentId = { $in: filteredAgentIds };
        }

        const users = await User.find(userQuery).select('_id username agentId');
        const userIds = users.map(u => u._id);
        if (!userIds.length) {
            return res.json({ bets: [], totals: { risk: 0, toWin: 0 } });
        }

        const betQuery = { userId: { $in: userIds } };
        if (type && type !== 'all-types') betQuery.type = type;
        const startDate = getStartDateFromPeriod(time);
        if (startDate) betQuery.createdAt = { $gte: startDate };

        let bets = await Bet.find(betQuery)
            .populate('userId', 'username agentId')
            .populate('matchId', 'homeTeam awayTeam sport')
            .sort({ createdAt: -1 })
            .limit(limitValue);

        if (amount && amount !== 'any') {
            bets = bets.filter(bet => {
                const wager = parseAmount(bet.amount);
                if (amount === 'under-100') return wager < 100;
                if (amount === '100-500') return wager >= 100 && wager <= 500;
                if (amount === '500-1000') return wager > 500 && wager <= 1000;
                if (amount === 'over-1000') return wager > 1000;
                return true;
            });
        }

        const agentIds = Array.from(
            new Set(
                bets
                    .map(bet => bet.userId?.agentId)
                    .filter(Boolean)
                    .map(id => id.toString())
            )
        );
        const agentMap = new Map();
        if (agentIds.length) {
            const agentUsers = await Agent.find({ _id: { $in: agentIds } }).select('username');
            agentUsers.forEach(agentUser => {
                agentMap.set(agentUser._id.toString(), agentUser.username);
            });
        }

        let totalRisk = 0;
        let totalToWin = 0;

        const formatted = bets.map(bet => {
            const risk = parseAmount(bet.amount);
            const toWin = parseAmount(bet.potentialPayout);
            totalRisk += risk;
            totalToWin += toWin;

            const match = bet.matchId;
            const matchLabel = match ? `${match.homeTeam} vs ${match.awayTeam}` : 'Match';
            const oddsLabel = bet.odds ? `@ ${bet.odds}` : '';

            return {
                id: bet._id,
                agent: bet.userId?.agentId ? agentMap.get(bet.userId.agentId.toString()) || '—' : '—',
                customer: bet.userId?.username || 'Unknown',
                customerId: bet.userId?._id || null,
                accepted: bet.createdAt,
                description: `${matchLabel} | ${bet.selection} ${oddsLabel}`.trim(),
                risk,
                toWin,
                type: bet.type,
                status: bet.status
            };
        });

        res.json({
            bets: formatted,
            totals: {
                risk: totalRisk,
                toWin: totalToWin
            }
        });
    } catch (error) {
        console.error('Error fetching admin bets:', error);
        res.status(500).json({ message: 'Server error fetching bets' });
    }
};

exports.createAdminBet = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'props')) {
            return res.status(403).json({ message: 'Props / Betting access denied by permissions' });
        }
        if (req.user.role !== 'admin' && req.user.permissions?.enterBettingAdjustments === false) {
            return res.status(403).json({ message: 'Bet creation denied by permissions' });
        }

        const { userId, matchId, amount, odds, type, selection, status } = req.body;
        if (!userId || !matchId || !amount || !odds || !type || !selection) {
            return res.status(400).json({ message: 'userId, matchId, amount, odds, type, and selection are required' });
        }

        const user = await User.findOne({ _id: userId, role: 'user' }).select('_id username agentId minBet maxBet');
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        if (req.user.role === 'agent' && String(user.agentId || '') !== String(req.user._id)) {
            return res.status(403).json({ message: 'You can only create bets for your own players' });
        }
        if (req.user.role === 'master_agent' || req.user.role === 'super_agent') {
            const subAgents = await Agent.find({ createdBy: req.user._id, createdByModel: 'Agent' }).select('_id');
            const allowedAgentIds = new Set([String(req.user._id), ...subAgents.map((sa) => String(sa._id))]);
            if (!allowedAgentIds.has(String(user.agentId || ''))) {
                return res.status(403).json({ message: 'You can only create bets within your hierarchy' });
            }
        }

        const match = await Match.findById(matchId);
        if (!match) {
            return res.status(404).json({ message: 'Match not found' });
        }

        const betAmount = parseAmount(amount);
        const betOdds = parseAmount(odds);
        if (betAmount <= 0 || betOdds <= 0) {
            return res.status(400).json({ message: 'Amount and odds must be greater than 0' });
        }
        if (user.minBet != null && betAmount < Number(user.minBet)) {
            return res.status(400).json({ message: `Minimum bet for this customer is ${Number(user.minBet)}` });
        }
        if (user.maxBet != null && betAmount > Number(user.maxBet)) {
            return res.status(400).json({ message: `Maximum bet for this customer is ${Number(user.maxBet)}` });
        }

        const potentialPayout = betAmount * betOdds;

        const bet = await Bet.create({
            userId,
            matchId,
            amount: betAmount,
            odds: betOdds,
            type,
            selection,
            potentialPayout,
            status: status || 'pending'
        });

        res.status(201).json({
            message: 'Bet created',
            bet: {
                id: bet._id,
                userId: bet.userId,
                matchId: bet.matchId,
                amount: parseAmount(bet.amount),
                odds: parseAmount(bet.odds),
                potentialPayout: parseAmount(bet.potentialPayout),
                type: bet.type,
                selection: bet.selection,
                status: bet.status,
                createdAt: bet.createdAt
            }
        });
    } catch (error) {
        console.error('Error creating admin bet:', error);
        res.status(500).json({ message: 'Server error creating bet' });
    }
};

exports.deleteAdminBet = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'props')) {
            return res.status(403).json({ message: 'Props / Betting access denied by permissions' });
        }
        if (req.user.role !== 'admin' && req.user.permissions?.deleteTransactions === false) {
            return res.status(403).json({ message: 'Bet deletion denied by permissions' });
        }

        const { id } = req.params;
        const bet = await Bet.findById(id).populate('userId', 'agentId username').populate('matchId', 'sport');
        if (!bet) return res.status(404).json({ message: 'Bet not found' });

        if (bet.status !== 'pending') {
            return res.status(400).json({ message: 'Only pending bets can be deleted' });
        }

        if (req.user.role === 'agent' && String(bet.userId?.agentId || '') !== String(req.user._id)) {
            return res.status(403).json({ message: 'You can only delete bets for your own players' });
        }
        if (req.user.role === 'master_agent' || req.user.role === 'super_agent') {
            const subAgents = await Agent.find({ createdBy: req.user._id, createdByModel: 'Agent' }).select('_id');
            const allowedAgentIds = new Set([String(req.user._id), ...subAgents.map((sa) => String(sa._id))]);
            if (!allowedAgentIds.has(String(bet.userId?.agentId || ''))) {
                return res.status(403).json({ message: 'You can only delete bets within your hierarchy' });
            }
        }

        await DeletedWager.create({
            userId: bet.userId?._id,
            betId: bet._id,
            amount: parseAmount(bet.amount),
            sport: bet.matchId?.sport || 'Unknown',
            reason: `Deleted by ${req.user.role} ${req.user.username || ''}`.trim(),
            status: 'deleted'
        });

        await bet.deleteOne();

        res.json({ message: 'Bet deleted successfully', id: String(id) });
    } catch (error) {
        console.error('Error deleting admin bet:', error);
        res.status(500).json({ message: 'Server error deleting bet' });
    }
};

// IP Tracker
exports.getIpTracker = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'ipTracker')) {
            return res.status(403).json({ message: 'IP Tracker access denied by permissions' });
        }

        const { search, status } = req.query;
        const limit = Math.min(parseInt(req.query.limit || '200', 10), 500);

        const query = {};
        if (status && status !== 'all') query.status = status;

        const scopedUserIds = await getScopedIpUserIds(req.user);
        if (Array.isArray(scopedUserIds)) {
            query.userId = { $in: scopedUserIds };
        }

        if (search) {
            const [users, agents, admins] = await Promise.all([
                User.find({ username: { $regex: search, $options: 'i' } }).select('_id'),
                Agent.find({ username: { $regex: search, $options: 'i' } }).select('_id'),
                Admin.find({ username: { $regex: search, $options: 'i' } }).select('_id')
            ]);
            const userIds = [
                ...users.map(u => String(u._id)),
                ...agents.map(a => String(a._id)),
                ...admins.map(a => String(a._id))
            ];
            const searchUserIds = Array.isArray(scopedUserIds)
                ? userIds.filter((id) => scopedUserIds.includes(id))
                : userIds;
            query.$or = [
                { ip: { $regex: search, $options: 'i' } },
                { userId: { $in: searchUserIds } }
            ];
        }

        const logs = await IpLog.find(query)
            .sort({ lastActive: -1 })
            .limit(limit)
            .lean();

        const ownerMap = await buildOwnerMap(logs);

        const formatted = logs.map(log => ({
            id: log._id,
            ip: log.ip,
            user: ownerMap.get(`${log.userModel || 'User'}:${String(log.userId || '')}`)?.username || 'Unknown',
            userId: log.userId || null,
            country: log.country || 'Unknown',
            city: log.city || 'Unknown',
            lastActive: log.lastActive,
            status: log.status,
            userAgent: log.userAgent,
            userModel: log.userModel || 'User',
            phoneNumber: ownerMap.get(`${log.userModel || 'User'}:${String(log.userId || '')}`)?.phoneNumber || null
        }));

        res.json({ logs: formatted });
    } catch (error) {
        console.error('Error fetching IP tracker:', error);
        res.status(500).json({ message: 'Server error fetching IP tracker' });
    }
};

exports.blockIp = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'ipTracker')) {
            return res.status(403).json({ message: 'IP Tracker access denied by permissions' });
        }
        if (!canManageIpTracker(req.user)) {
            return res.status(403).json({ message: 'IP action denied by permissions' });
        }

        const { id } = req.params;
        const log = await IpLog.findById(id);
        if (!log) return res.status(404).json({ message: 'IP record not found' });

        const scopedUserIds = await getScopedIpUserIds(req.user);
        if (Array.isArray(scopedUserIds) && !scopedUserIds.includes(String(log.userId))) {
            return res.status(403).json({ message: 'Not authorized to manage this IP record' });
        }

        log.status = 'blocked';
        log.blockedAt = new Date();
        log.blockedBy = req.user?._id || null;
        log.blockedByModel = req.user ? getOwnerModelForRole(req.user.role) : null;
        await log.save();

        res.json({ message: 'IP blocked', id: log._id });
    } catch (error) {
        console.error('Error blocking IP:', error);
        res.status(500).json({ message: 'Server error blocking IP' });
    }
};

exports.unblockIp = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'ipTracker')) {
            return res.status(403).json({ message: 'IP Tracker access denied by permissions' });
        }
        if (!canManageIpTracker(req.user)) {
            return res.status(403).json({ message: 'IP action denied by permissions' });
        }

        const { id } = req.params;
        const log = await IpLog.findById(id);
        if (!log) return res.status(404).json({ message: 'IP record not found' });

        const scopedUserIds = await getScopedIpUserIds(req.user);
        if (Array.isArray(scopedUserIds) && !scopedUserIds.includes(String(log.userId))) {
            return res.status(403).json({ message: 'Not authorized to manage this IP record' });
        }

        log.status = 'active';
        log.blockedAt = null;
        log.blockedBy = null;
        log.blockedByModel = null;
        log.blockReason = null;
        await log.save();

        res.json({ message: 'IP unblocked', id: log._id });
    } catch (error) {
        console.error('Error unblocking IP:', error);
        res.status(500).json({ message: 'Server error unblocking IP' });
    }
};

exports.whitelistIp = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'ipTracker')) {
            return res.status(403).json({ message: 'IP Tracker access denied by permissions' });
        }
        if (!canManageIpTracker(req.user)) {
            return res.status(403).json({ message: 'IP action denied by permissions' });
        }

        const { id } = req.params;
        const log = await IpLog.findById(id);
        if (!log) return res.status(404).json({ message: 'IP record not found' });

        const scopedUserIds = await getScopedIpUserIds(req.user);
        if (Array.isArray(scopedUserIds) && !scopedUserIds.includes(String(log.userId))) {
            return res.status(403).json({ message: 'Not authorized to manage this IP record' });
        }

        log.status = 'whitelisted';
        log.blockedAt = null;
        log.blockedBy = null;
        log.blockedByModel = null;
        log.blockReason = null;
        await log.save();

        res.json({ message: 'IP whitelisted successfully', id: log._id });
    } catch (error) {
        console.error('Error whitelisting IP:', error);
        res.status(500).json({ message: 'Server error whitelisting IP' });
    }
};

// Transactions History
exports.getTransactionsHistory = async (req, res) => {
    try {
        const { user, type, status, time } = req.query;
        const limit = Math.min(parseInt(req.query.limit || '200', 10), 500);

        const query = {};
        if (type && type !== 'all') query.type = type;
        if (status && status !== 'all') query.status = status;

        const startDate = getStartDateFromPeriod(time);
        if (startDate) query.createdAt = { $gte: startDate };

        if (user) {
            const users = await User.find({ username: { $regex: user, $options: 'i' } }).select('_id');
            const userIds = users.map(u => u._id);
            query.userId = { $in: userIds };
        }

        const transactions = await Transaction.find(query)
            .populate('userId', 'username phoneNumber')
            .sort({ createdAt: -1 })
            .limit(limit);

        const formatted = transactions.map(tx => ({
            id: tx._id,
            type: tx.type,
            user: tx.userId?.username || 'Unknown',
            userId: tx.userId?._id || null,
            amount: parseAmount(tx.amount),
            date: tx.createdAt,
            status: tx.status,
            description: tx.description || null
        }));

        res.json({ transactions: formatted });
    } catch (error) {
        console.error('Error fetching transaction history:', error);
        res.status(500).json({ message: 'Server error fetching transaction history' });
    }
};

// Collections
exports.getCollections = async (req, res) => {
    try {
        const { status, user, overdue } = req.query;
        const limit = Math.min(parseInt(req.query.limit || '200', 10), 500);

        const query = {};
        if (status && status !== 'all') query.status = status;

        if (user) {
            const users = await User.find({ username: { $regex: user, $options: 'i' } }).select('_id');
            const userIds = users.map(u => u._id);
            query.userId = { $in: userIds };
        }

        if (overdue === '1') {
            query.dueDate = { $lt: new Date() };
            query.status = { $ne: 'collected' };
        }

        const collections = await Collection.find(query)
            .populate('userId', 'username phoneNumber')
            .sort({ createdAt: -1 })
            .limit(limit);

        const formatted = collections.map(col => ({
            id: col._id,
            user: col.userId?.username || 'Unknown',
            userId: col.userId?._id || null,
            amount: parseAmount(col.amount),
            dueDate: col.dueDate,
            status: col.status,
            attempts: col.attempts || 0,
            lastAttemptAt: col.lastAttemptAt,
            notes: col.notes || null,
            createdAt: col.createdAt
        }));

        const totalOutstanding = formatted
            .filter(col => col.status !== 'collected' && col.status !== 'cancelled')
            .reduce((sum, col) => sum + parseAmount(col.amount), 0);

        res.json({ collections: formatted, summary: { totalOutstanding } });
    } catch (error) {
        console.error('Error fetching collections:', error);
        res.status(500).json({ message: 'Server error fetching collections' });
    }
};

exports.createCollection = async (req, res) => {
    try {
        const { userId, amount, dueDate, notes } = req.body;
        if (!userId || !amount) {
            return res.status(400).json({ message: 'userId and amount are required' });
        }

        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ message: 'User not found' });

        const parsedAmount = parseAmount(amount);
        const due = dueDate ? new Date(dueDate) : null;
        const status = due && due < new Date() ? 'overdue' : 'pending';

        const collection = await Collection.create({
            userId,
            amount: parsedAmount,
            dueDate: due,
            status,
            notes: notes || null,
            createdBy: req.user?._id || null
        });

        res.status(201).json({
            message: 'Collection created',
            collection: {
                id: collection._id,
                userId: collection.userId,
                amount: parseAmount(collection.amount),
                dueDate: collection.dueDate,
                status: collection.status,
                attempts: collection.attempts,
                notes: collection.notes,
                createdAt: collection.createdAt
            }
        });
    } catch (error) {
        console.error('Error creating collection:', error);
        res.status(500).json({ message: 'Server error creating collection' });
    }
};

exports.collectCollection = async (req, res) => {
    try {
        const { id } = req.params;
        const collection = await Collection.findById(id);
        if (!collection) return res.status(404).json({ message: 'Collection not found' });

        collection.status = 'collected';
        collection.attempts = (collection.attempts || 0) + 1;
        collection.lastAttemptAt = new Date();
        await collection.save();

        res.json({ message: 'Collection marked as collected', id: collection._id });
    } catch (error) {
        console.error('Error collecting:', error);
        res.status(500).json({ message: 'Server error collecting' });
    }
};

exports.getCollectionById = async (req, res) => {
    try {
        const { id } = req.params;
        const collection = await Collection.findById(id).populate('userId', 'username phoneNumber');
        if (!collection) return res.status(404).json({ message: 'Collection not found' });

        res.json({
            id: collection._id,
            user: collection.userId?.username || 'Unknown',
            userId: collection.userId?._id || null,
            amount: parseAmount(collection.amount),
            dueDate: collection.dueDate,
            status: collection.status,
            attempts: collection.attempts || 0,
            lastAttemptAt: collection.lastAttemptAt,
            notes: collection.notes || null,
            createdAt: collection.createdAt
        });
    } catch (error) {
        console.error('Error fetching collection:', error);
        res.status(500).json({ message: 'Server error fetching collection' });
    }
};

// Deleted Wagers
exports.getDeletedWagers = async (req, res) => {
    try {
        const { user, sport, status, time } = req.query;
        const limit = Math.min(parseInt(req.query.limit || '200', 10), 500);

        const query = {};
        if (status && status !== 'all') query.status = status;
        if (sport && sport !== 'all') query.sport = sport;

        const startDate = getStartDateFromPeriod(time);
        if (startDate) query.deletedAt = { $gte: startDate };

        if (user) {
            const users = await User.find({ username: { $regex: user, $options: 'i' } }).select('_id');
            const userIds = users.map(u => u._id);
            query.userId = { $in: userIds };
        }

        const wagers = await DeletedWager.find(query)
            .populate('userId', 'username phoneNumber')
            .sort({ deletedAt: -1 })
            .limit(limit);

        const formatted = wagers.map(wager => ({
            id: wager._id,
            user: wager.userId?.username || 'Unknown',
            userId: wager.userId?._id || null,
            amount: parseAmount(wager.amount),
            sport: wager.sport,
            reason: wager.reason,
            status: wager.status,
            deletedAt: wager.deletedAt,
            restoredAt: wager.restoredAt
        }));

        res.json({ wagers: formatted });
    } catch (error) {
        console.error('Error fetching deleted wagers:', error);
        res.status(500).json({ message: 'Server error fetching deleted wagers' });
    }
};

exports.restoreDeletedWager = async (req, res) => {
    try {
        const { id } = req.params;
        const wager = await DeletedWager.findById(id);
        if (!wager) return res.status(404).json({ message: 'Deleted wager not found' });

        wager.status = 'restored';
        wager.restoredAt = new Date();
        wager.restoredBy = req.user?._id || null;
        await wager.save();

        res.json({ message: 'Wager restored', id: wager._id });
    } catch (error) {
        console.error('Error restoring wager:', error);
        res.status(500).json({ message: 'Server error restoring wager' });
    }
};

// Sportsbook Links
exports.getSportsbookLinks = async (req, res) => {
    try {
        const links = await SportsbookLink.find().sort({ name: 1 });
        const formatted = links.map(link => ({
            id: link._id,
            name: link.name,
            url: link.url,
            status: link.status,
            lastSync: link.lastSync,
            notes: link.notes
        }));
        res.json({ links: formatted });
    } catch (error) {
        console.error('Error fetching sportsbook links:', error);
        res.status(500).json({ message: 'Server error fetching sportsbook links' });
    }
};

exports.createSportsbookLink = async (req, res) => {
    try {
        const { name, url, status, notes } = req.body;
        if (!name || !url) {
            return res.status(400).json({ message: 'name and url are required' });
        }

        const existing = await SportsbookLink.findOne({ name });
        if (existing) return res.status(409).json({ message: 'Provider already exists' });

        const link = await SportsbookLink.create({
            name,
            url,
            status: status || 'active',
            notes: notes || null,
            createdBy: req.user?._id || null
        });

        res.status(201).json({
            message: 'Link created',
            link: {
                id: link._id,
                name: link.name,
                url: link.url,
                status: link.status,
                lastSync: link.lastSync,
                notes: link.notes
            }
        });
    } catch (error) {
        console.error('Error creating sportsbook link:', error);
        res.status(500).json({ message: 'Server error creating sportsbook link' });
    }
};

exports.updateSportsbookLink = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, url, status, notes } = req.body;

        const link = await SportsbookLink.findById(id);
        if (!link) return res.status(404).json({ message: 'Link not found' });

        if (name) link.name = name;
        if (url) link.url = url;
        if (status) link.status = status;
        if (notes !== undefined) link.notes = notes;
        await link.save();

        res.json({ message: 'Link updated', id: link._id });
    } catch (error) {
        console.error('Error updating sportsbook link:', error);
        res.status(500).json({ message: 'Server error updating sportsbook link' });
    }
};

exports.testSportsbookLink = async (req, res) => {
    try {
        const { id } = req.params;
        const link = await SportsbookLink.findById(id);
        if (!link) return res.status(404).json({ message: 'Link not found' });

        link.lastSync = new Date();
        await link.save();

        res.json({ message: 'Link tested', id: link._id, lastSync: link.lastSync });
    } catch (error) {
        console.error('Error testing sportsbook link:', error);
        res.status(500).json({ message: 'Server error testing link' });
    }
};

// Clear Cache
exports.clearCache = async (_req, res) => {
    try {
        const oddsService = require('../services/oddsService');
        oddsService.clearCache();
        res.json({ message: 'Cache cleared' });
    } catch (error) {
        console.error('Error clearing cache:', error);
        res.status(500).json({ message: 'Server error clearing cache' });
    }
};

// Billing
exports.getBillingSummary = async (_req, res) => {
    try {
        const invoices = await BillingInvoice.find();
        const totals = invoices.reduce(
            (acc, invoice) => {
                const amount = parseAmount(invoice.amount);
                if (invoice.status === 'paid') acc.paid += amount;
                if (invoice.status === 'pending' || invoice.status === 'overdue') acc.outstanding += amount;
                acc.total += amount;
                return acc;
            },
            { paid: 0, outstanding: 0, total: 0 }
        );

        res.json(totals);
    } catch (error) {
        console.error('Error fetching billing summary:', error);
        res.status(500).json({ message: 'Server error fetching billing summary' });
    }
};

exports.getBillingInvoices = async (req, res) => {
    try {
        const { status } = req.query;
        const limit = Math.min(parseInt(req.query.limit || '200', 10), 500);

        const query = {};
        if (status && status !== 'all') query.status = status;

        const invoices = await BillingInvoice.find(query)
            .sort({ createdAt: -1 })
            .limit(limit);

        const formatted = invoices.map(inv => ({
            id: inv._id,
            invoice: inv.invoiceNumber,
            amount: parseAmount(inv.amount),
            status: inv.status,
            date: inv.createdAt,
            dueDate: inv.dueDate,
            paidAt: inv.paidAt,
            notes: inv.notes
        }));

        res.json({ invoices: formatted });
    } catch (error) {
        console.error('Error fetching billing invoices:', error);
        res.status(500).json({ message: 'Server error fetching billing invoices' });
    }
};

exports.createBillingInvoice = async (req, res) => {
    try {
        const { invoiceNumber, amount, status, dueDate, notes } = req.body;
        if (!invoiceNumber || !amount) {
            return res.status(400).json({ message: 'invoiceNumber and amount are required' });
        }

        const existing = await BillingInvoice.findOne({ invoiceNumber });
        if (existing) return res.status(409).json({ message: 'Invoice already exists' });

        const invoice = await BillingInvoice.create({
            invoiceNumber,
            amount: parseAmount(amount),
            status: status || 'pending',
            dueDate: dueDate ? new Date(dueDate) : null,
            notes: notes || null,
            createdBy: req.user?._id || null,
            paidAt: status === 'paid' ? new Date() : null
        });

        res.status(201).json({
            message: 'Invoice created',
            invoice: {
                id: invoice._id,
                invoice: invoice.invoiceNumber,
                amount: parseAmount(invoice.amount),
                status: invoice.status,
                date: invoice.createdAt,
                dueDate: invoice.dueDate,
                paidAt: invoice.paidAt,
                notes: invoice.notes
            }
        });
    } catch (error) {
        console.error('Error creating invoice:', error);
        res.status(500).json({ message: 'Server error creating invoice' });
    }
};

exports.updateBillingInvoice = async (req, res) => {
    try {
        const { id } = req.params;
        const { amount, status, dueDate, notes } = req.body;

        const invoice = await BillingInvoice.findById(id);
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });

        if (amount !== undefined) invoice.amount = parseAmount(amount);
        if (status) {
            invoice.status = status;
            if (status === 'paid') invoice.paidAt = new Date();
        }
        if (dueDate !== undefined) invoice.dueDate = dueDate ? new Date(dueDate) : null;
        if (notes !== undefined) invoice.notes = notes;

        await invoice.save();
        res.json({ message: 'Invoice updated', id: invoice._id });
    } catch (error) {
        console.error('Error updating invoice:', error);
        res.status(500).json({ message: 'Server error updating invoice' });
    }
};

exports.getBillingInvoiceById = async (req, res) => {
    try {
        const { id } = req.params;
        const invoice = await BillingInvoice.findById(id);
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });

        res.json({
            id: invoice._id,
            invoice: invoice.invoiceNumber,
            amount: parseAmount(invoice.amount),
            status: invoice.status,
            date: invoice.createdAt,
            dueDate: invoice.dueDate,
            paidAt: invoice.paidAt,
            notes: invoice.notes
        });
    } catch (error) {
        console.error('Error fetching invoice:', error);
        res.status(500).json({ message: 'Server error fetching invoice' });
    }
};

// Settings
exports.getSettings = async (_req, res) => {
    try {
        let settings = await PlatformSetting.findOne();
        if (!settings) {
            settings = await PlatformSetting.create({});
        }
        res.json(settings);
    } catch (error) {
        console.error('Error fetching settings:', error);
        res.status(500).json({ message: 'Server error fetching settings' });
    }
};

exports.updateSettings = async (req, res) => {
    try {
        let settings = await PlatformSetting.findOne();
        if (!settings) {
            settings = await PlatformSetting.create({});
        }

        const fields = [
            'platformName',
            'dailyBetLimit',
            'weeklyBetLimit',
            'maxOdds',
            'minBet',
            'maxBet',
            'maintenanceMode',
            'smsNotifications',
            'twoFactor'
        ];

        fields.forEach(field => {
            if (req.body[field] !== undefined) settings[field] = req.body[field];
        });

        await settings.save();
        res.json({ message: 'Settings updated', settings });
    } catch (error) {
        console.error('Error updating settings:', error);
        res.status(500).json({ message: 'Server error updating settings' });
    }
};

// Rules
exports.getRules = async (_req, res) => {
    try {
        const rules = await Rule.find().sort({ createdAt: -1 });
        res.json({ rules });
    } catch (error) {
        console.error('Error fetching rules:', error);
        res.status(500).json({ message: 'Server error fetching rules' });
    }
};

exports.createRule = async (req, res) => {
    try {
        const { title, items, status } = req.body;
        if (!title) return res.status(400).json({ message: 'title is required' });
        const rule = await Rule.create({
            title,
            items: Array.isArray(items) ? items : [],
            status: status || 'active'
        });
        res.status(201).json({ message: 'Rule created', rule });
    } catch (error) {
        console.error('Error creating rule:', error);
        res.status(500).json({ message: 'Server error creating rule' });
    }
};

exports.updateRule = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, items, status } = req.body;
        const rule = await Rule.findById(id);
        if (!rule) return res.status(404).json({ message: 'Rule not found' });

        if (title) rule.title = title;
        if (items !== undefined) rule.items = Array.isArray(items) ? items : rule.items;
        if (status) rule.status = status;

        await rule.save();
        res.json({ message: 'Rule updated', id: rule._id });
    } catch (error) {
        console.error('Error updating rule:', error);
        res.status(500).json({ message: 'Server error updating rule' });
    }
};

exports.deleteRule = async (req, res) => {
    try {
        const { id } = req.params;
        const rule = await Rule.findById(id);
        if (!rule) return res.status(404).json({ message: 'Rule not found' });
        await rule.deleteOne();
        res.json({ message: 'Rule deleted', id });
    } catch (error) {
        console.error('Error deleting rule:', error);
        res.status(500).json({ message: 'Server error deleting rule' });
    }
};

exports.getBetModeRules = async (_req, res) => {
    try {
        await ensureBetModeRulesSeeded();
        const rules = await BetModeRule.find().sort({ mode: 1 });
        res.json({ rules });
    } catch (error) {
        console.error('Error fetching bet mode rules:', error);
        res.status(500).json({ message: 'Server error fetching bet mode rules' });
    }
};

exports.updateBetModeRule = async (req, res) => {
    try {
        const mode = normalizeBetMode(req.params.mode);
        const defaultRule = getDefaultBetModeRule(mode);
        if (!defaultRule) {
            return res.status(400).json({ message: 'Invalid bet mode' });
        }

        await ensureBetModeRulesSeeded();
        const rule = await BetModeRule.findOne({ mode });
        if (!rule) {
            return res.status(404).json({ message: 'Bet mode rule not found' });
        }

        const {
            minLegs,
            maxLegs,
            teaserPointOptions,
            payoutProfile,
            isActive
        } = req.body;

        if (minLegs !== undefined) rule.minLegs = Number(minLegs);
        if (maxLegs !== undefined) rule.maxLegs = Number(maxLegs);
        if (teaserPointOptions !== undefined) {
            rule.teaserPointOptions = Array.isArray(teaserPointOptions)
                ? teaserPointOptions.map(v => Number(v)).filter(v => Number.isFinite(v))
                : rule.teaserPointOptions;
        }
        if (payoutProfile !== undefined && payoutProfile && typeof payoutProfile === 'object') {
            rule.payoutProfile = payoutProfile;
        }
        if (isActive !== undefined) rule.isActive = Boolean(isActive);

        if (!Number.isFinite(rule.minLegs) || !Number.isFinite(rule.maxLegs) || rule.minLegs < 1 || rule.maxLegs < rule.minLegs) {
            return res.status(400).json({ message: 'Invalid leg limits' });
        }

        await rule.save();
        res.json({ message: 'Bet mode rule updated', rule });
    } catch (error) {
        console.error('Error updating bet mode rule:', error);
        res.status(500).json({ message: 'Server error updating bet mode rule' });
    }
};

// Feedback
exports.getFeedback = async (req, res) => {
    try {
        const { status } = req.query;
        const query = {};
        if (status && status !== 'all') query.status = status;

        const feedbacks = await Feedback.find(query)
            .populate('userId', 'username phoneNumber')
            .sort({ createdAt: -1 });

        const formatted = feedbacks.map(item => ({
            id: item._id,
            user: item.userId?.username || item.userLabel || 'Anonymous',
            message: item.message,
            rating: item.rating,
            status: item.status,
            adminReply: item.adminReply,
            repliedAt: item.repliedAt,
            date: item.createdAt
        }));

        res.json({ feedbacks: formatted });
    } catch (error) {
        console.error('Error fetching feedback:', error);
        res.status(500).json({ message: 'Server error fetching feedback' });
    }
};

exports.replyFeedback = async (req, res) => {
    try {
        const { id } = req.params;
        const { reply } = req.body;
        if (!reply) return res.status(400).json({ message: 'reply is required' });

        const feedback = await Feedback.findById(id);
        if (!feedback) return res.status(404).json({ message: 'Feedback not found' });

        feedback.adminReply = reply;
        feedback.repliedAt = new Date();
        await feedback.save();

        res.json({ message: 'Reply saved', id: feedback._id });
    } catch (error) {
        console.error('Error replying feedback:', error);
        res.status(500).json({ message: 'Server error replying feedback' });
    }
};

exports.markFeedbackReviewed = async (req, res) => {
    try {
        const { id } = req.params;
        const feedback = await Feedback.findById(id);
        if (!feedback) return res.status(404).json({ message: 'Feedback not found' });

        feedback.status = 'reviewed';
        await feedback.save();
        res.json({ message: 'Feedback reviewed', id: feedback._id });
    } catch (error) {
        console.error('Error updating feedback:', error);
        res.status(500).json({ message: 'Server error updating feedback' });
    }
};

exports.deleteFeedback = async (req, res) => {
    try {
        const { id } = req.params;
        const feedback = await Feedback.findById(id);
        if (!feedback) return res.status(404).json({ message: 'Feedback not found' });
        await feedback.deleteOne();
        res.json({ message: 'Feedback deleted', id });
    } catch (error) {
        console.error('Error deleting feedback:', error);
        res.status(500).json({ message: 'Server error deleting feedback' });
    }
};

// FAQ
exports.getFaqs = async (_req, res) => {
    try {
        const faqs = await Faq.find().sort({ order: 1, createdAt: -1 });
        res.json({ faqs });
    } catch (error) {
        console.error('Error fetching FAQs:', error);
        res.status(500).json({ message: 'Server error fetching FAQs' });
    }
};

exports.createFaq = async (req, res) => {
    try {
        const { question, answer, status, order } = req.body;
        if (!question || !answer) return res.status(400).json({ message: 'question and answer are required' });
        const faq = await Faq.create({ question, answer, status: status || 'active', order: order || 0 });
        res.status(201).json({ message: 'FAQ created', faq });
    } catch (error) {
        console.error('Error creating FAQ:', error);
        res.status(500).json({ message: 'Server error creating FAQ' });
    }
};

exports.updateFaq = async (req, res) => {
    try {
        const { id } = req.params;
        const { question, answer, status, order } = req.body;
        const faq = await Faq.findById(id);
        if (!faq) return res.status(404).json({ message: 'FAQ not found' });

        if (question) faq.question = question;
        if (answer) faq.answer = answer;
        if (status) faq.status = status;
        if (order !== undefined) faq.order = order;

        await faq.save();
        res.json({ message: 'FAQ updated', id: faq._id });
    } catch (error) {
        console.error('Error updating FAQ:', error);
        res.status(500).json({ message: 'Server error updating FAQ' });
    }
};

exports.deleteFaq = async (req, res) => {
    try {
        const { id } = req.params;
        const faq = await Faq.findById(id);
        if (!faq) return res.status(404).json({ message: 'FAQ not found' });
        await faq.deleteOne();
        res.json({ message: 'FAQ deleted', id });
    } catch (error) {
        console.error('Error deleting FAQ:', error);
        res.status(500).json({ message: 'Server error deleting FAQ' });
    }
};

// User Manual
exports.getManualSections = async (_req, res) => {
    try {
        const sections = await ManualSection.find({ status: 'active' }).sort({ order: 1, createdAt: -1 });
        res.json({ sections });
    } catch (error) {
        console.error('Error fetching manual sections:', error);
        res.status(500).json({ message: 'Server error fetching manual sections' });
    }
};

exports.createManualSection = async (req, res) => {
    try {
        const { title, content, order, status } = req.body;
        if (!title || !content) return res.status(400).json({ message: 'title and content are required' });
        const section = await ManualSection.create({
            title,
            content,
            order: order || 0,
            status: status || 'active'
        });
        res.status(201).json({ message: 'Section created', section });
    } catch (error) {
        console.error('Error creating manual section:', error);
        res.status(500).json({ message: 'Server error creating manual section' });
    }
};

exports.updateManualSection = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, content, order, status } = req.body;
        const section = await ManualSection.findById(id);
        if (!section) return res.status(404).json({ message: 'Section not found' });

        if (title) section.title = title;
        if (content) section.content = content;
        if (order !== undefined) section.order = order;
        if (status) section.status = status;

        await section.save();
        res.json({ message: 'Section updated', id: section._id });
    } catch (error) {
        console.error('Error updating manual section:', error);
        res.status(500).json({ message: 'Server error updating manual section' });
    }
};

exports.deleteManualSection = async (req, res) => {
    try {
        const { id } = req.params;
        const section = await ManualSection.findById(id);
        if (!section) return res.status(404).json({ message: 'Section not found' });
        await section.deleteOne();
        res.json({ message: 'Section deleted', id });
    } catch (error) {
        console.error('Error deleting manual section:', error);
        res.status(500).json({ message: 'Server error deleting manual section' });
    }
};

// Agent Performance
exports.getAgentPerformance = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'agentPerformance')) {
            return res.status(403).json({ message: 'Agent Performance access denied by permissions' });
        }

        const period = req.query.period || '30d';
        const startDate = getStartDateFromPeriod(period);
        const activeWindowStart = new Date(Date.now() - 7 * MS_PER_DAY);
        const scopedAgentIds = await getScopedAgentIds(req.user);

        const agentQuery = {};
        if (Array.isArray(scopedAgentIds)) {
            agentQuery._id = { $in: scopedAgentIds };
        }

        const agents = await Agent.find(agentQuery).select('username status createdAt role');
        const agentIds = agents.map(agent => agent._id);
        if (!agentIds.length) {
            return res.json({ agents: [], summary: { revenue: 0, customers: 0, avgWinRate: 0, upAgents: 0 } });
        }

        const users = await User.find({ role: 'user', agentId: { $in: agentIds } }).select('_id agentId');
        const userToAgent = new Map();
        const agentToCustomers = new Map();

        users.forEach(user => {
            const agentId = user.agentId?.toString();
            if (!agentId) return;
            userToAgent.set(user._id.toString(), agentId);
            if (!agentToCustomers.has(agentId)) agentToCustomers.set(agentId, []);
            agentToCustomers.get(agentId).push(user._id.toString());
        });

        const userIds = users.map(u => u._id);
        const [periodBets, activeWindowBets] = await Promise.all([
            Bet.find({
                userId: { $in: userIds },
                ...(startDate ? { createdAt: { $gte: startDate } } : {})
            }).select('userId amount potentialPayout status createdAt'),
            Bet.find({
                userId: { $in: userIds },
                createdAt: { $gte: activeWindowStart }
            }).select('userId')
        ]);

        const activeBetCountByUser = new Map();
        activeWindowBets.forEach((bet) => {
            const key = String(bet.userId);
            activeBetCountByUser.set(key, (activeBetCountByUser.get(key) || 0) + 1);
        });

        const activeCustomerIdsByAgent = new Map();
        users.forEach((user) => {
            const userId = String(user._id);
            const agentId = String(user.agentId || '');
            if (!agentId) return;
            if ((activeBetCountByUser.get(userId) || 0) >= 1) {
                if (!activeCustomerIdsByAgent.has(agentId)) activeCustomerIdsByAgent.set(agentId, new Set());
                activeCustomerIdsByAgent.get(agentId).add(userId);
            }
        });

        const agentStats = new Map();
        const ensure = (agentId) => {
            if (!agentStats.has(agentId)) {
                agentStats.set(agentId, {
                    revenue: 0,
                    wagered: 0,
                    payouts: 0,
                    wins: 0, // active-customer wins
                    losses: 0, // active-customer losses
                    pending: 0,
                    lastActive: null
                });
            }
            return agentStats.get(agentId);
        };

        periodBets.forEach(bet => {
            const agentId = userToAgent.get(bet.userId.toString());
            if (!agentId) return;
            const stat = ensure(agentId);
            const activeSet = activeCustomerIdsByAgent.get(agentId) || new Set();
            if (!activeSet.has(String(bet.userId))) return;

            const wager = parseAmount(bet.amount);
            const payout = bet.status === 'won' ? parseAmount(bet.potentialPayout) : 0;
            stat.wagered += wager;
            stat.payouts += payout;
            if (bet.status === 'won') stat.wins += 1;
            if (bet.status === 'lost') stat.losses += 1;
            if (bet.status === 'pending') stat.pending += 1;
            if (!stat.lastActive || new Date(bet.createdAt) > stat.lastActive) {
                stat.lastActive = new Date(bet.createdAt);
            }
        });

        let totalRevenue = 0;
        let totalCustomers = 0;
        let totalWinRate = 0;
        let upAgents = 0;

        const formattedAgents = agents.map(agent => {
            const agentId = agent._id.toString();
            const stat = ensure(agentId);
            const customerCount = activeCustomerIdsByAgent.get(agentId)?.size || 0;
            const totalCustomerCount = agentToCustomers.get(agentId)?.length || 0;
            const totalDecisions = stat.wins + stat.losses;
            const winRate = totalDecisions ? (stat.wins / totalDecisions) * 100 : 0;
            const revenue = stat.wagered - stat.payouts;

            totalRevenue += revenue;
            totalCustomers += customerCount;
            totalWinRate += winRate;

            const trend = winRate >= 52 ? 'up' : winRate <= 48 ? 'down' : 'stable';
            if (trend === 'up') upAgents += 1;

            const tier = revenue >= 15000 ? 'gold' : revenue >= 9000 ? 'silver' : 'bronze';

            return {
                id: agent._id,
                name: agent.username,
                revenue,
                customers: customerCount,
                totalCustomers: totalCustomerCount,
                settledBets: totalDecisions,
                pendingBets: stat.pending,
                winRate: Number(winRate.toFixed(1)),
                trend,
                lastActive: stat.lastActive ? stat.lastActive : agent.createdAt,
                tier
            };
        });

        const avgWinRate = formattedAgents.length ? totalWinRate / formattedAgents.length : 0;

        res.json({
            agents: formattedAgents,
            summary: {
                revenue: totalRevenue,
                customers: totalCustomers,
                avgWinRate: Number(avgWinRate.toFixed(1)),
                upAgents
            }
        });
    } catch (error) {
        console.error('Error fetching agent performance:', error);
        res.status(500).json({ message: 'Server error fetching agent performance' });
    }
};

exports.getAgentPerformanceDetails = async (req, res) => {
    try {
        if (!hasAgentViewPermission(req.user, 'agentPerformance')) {
            return res.status(403).json({ message: 'Agent Performance access denied by permissions' });
        }

        const { id } = req.params;
        const period = req.query.period || '30d';
        const startDate = getStartDateFromPeriod(period);
        const activeWindowStart = new Date(Date.now() - 7 * MS_PER_DAY);

        const scopedAgentIds = await getScopedAgentIds(req.user);
        if (Array.isArray(scopedAgentIds) && !scopedAgentIds.includes(String(id))) {
            return res.status(403).json({ message: 'Not authorized to view this agent details' });
        }

        const agent = await Agent.findById(id).select('_id username status createdAt');
        if (!agent) return res.status(404).json({ message: 'Agent not found' });

        const users = await User.find({ role: 'user', agentId: agent._id }).select('_id username createdAt');
        const userIds = users.map((u) => u._id);

        const [periodBets, activeWindowBets] = await Promise.all([
            Bet.find({
                userId: { $in: userIds },
                ...(startDate ? { createdAt: { $gte: startDate } } : {})
            }).select('userId amount potentialPayout status createdAt type selection'),
            Bet.find({
                userId: { $in: userIds },
                createdAt: { $gte: activeWindowStart }
            }).select('userId')
        ]);

        const activeUserIds = new Set(activeWindowBets.map((b) => String(b.userId)));
        const userMap = new Map(users.map((u) => [String(u._id), u]));

        let totalRisk = 0;
        let totalPayout = 0;
        let wins = 0;
        let losses = 0;
        let pending = 0;
        let lastBetAt = null;

        const topMap = new Map();
        periodBets.forEach((bet) => {
            const userId = String(bet.userId);
            if (!activeUserIds.has(userId)) return;

            const risk = parseAmount(bet.amount);
            totalRisk += risk;
            if (bet.status === 'won') {
                totalPayout += parseAmount(bet.potentialPayout);
                wins += 1;
            } else if (bet.status === 'lost') {
                losses += 1;
            } else if (bet.status === 'pending') {
                pending += 1;
            }

            if (!lastBetAt || new Date(bet.createdAt) > lastBetAt) {
                lastBetAt = new Date(bet.createdAt);
            }

            const current = topMap.get(userId) || { userId, bets: 0, risk: 0, wins: 0, losses: 0 };
            current.bets += 1;
            current.risk += risk;
            if (bet.status === 'won') current.wins += 1;
            if (bet.status === 'lost') current.losses += 1;
            topMap.set(userId, current);
        });

        const settledBets = wins + losses;
        const winRate = settledBets ? (wins / settledBets) * 100 : 0;
        const ggr = totalRisk - totalPayout;
        const holdPct = totalRisk ? (ggr / totalRisk) * 100 : 0;
        const avgRisk = periodBets.length ? totalRisk / periodBets.length : 0;
        const newCustomers = users.filter((u) => startDate && new Date(u.createdAt) >= startDate).length;

        const topCustomers = Array.from(topMap.values())
            .sort((a, b) => b.risk - a.risk)
            .slice(0, 5)
            .map((row) => {
                const customer = userMap.get(row.userId);
                const settled = row.wins + row.losses;
                return {
                    userId: row.userId,
                    username: customer?.username || 'Unknown',
                    bets: row.bets,
                    risk: row.risk,
                    winRate: settled ? Number(((row.wins / settled) * 100).toFixed(1)) : 0
                };
            });

        const recentBets = periodBets
            .slice()
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 10)
            .map((bet) => ({
                id: bet._id,
                customer: userMap.get(String(bet.userId))?.username || 'Unknown',
                type: bet.type,
                selection: bet.selection,
                risk: parseAmount(bet.amount),
                toWin: parseAmount(bet.potentialPayout),
                status: bet.status,
                accepted: bet.createdAt
            }));

        return res.json({
            agent: {
                id: agent._id,
                name: agent.username,
                status: agent.status,
                createdAt: agent.createdAt
            },
            summary: {
                period,
                totalCustomers: users.length,
                activeCustomers: activeUserIds.size, // Active = at least 1 bet in last 7 days
                newCustomers: newCustomers || 0,
                betsPlaced: periodBets.length,
                settledBets,
                pendingBets: pending,
                wins,
                losses,
                winRate: Number(winRate.toFixed(1)),
                totalRisk,
                totalPayout,
                ggr,
                holdPct: Number(holdPct.toFixed(1)),
                avgRisk: Number(avgRisk.toFixed(2)),
                lastBetAt
            },
            topCustomers,
            recentBets
        });
    } catch (error) {
        console.error('Error fetching agent performance details:', error);
        res.status(500).json({ message: 'Server error fetching agent details' });
    }
};
// Get Detailed User Statistics
exports.getUserStats = async (req, res) => {
    try {
        const { userId } = req.params;

        // Try to find in User collection first
        let foundUser = await User.findById(userId).populate('agentId');
        let role = 'user';

        // If not in User, try Agent collection
        if (!foundUser) {
            foundUser = await Agent.findById(userId);
            if (foundUser) role = foundUser.role || 'agent';
        }

        if (!foundUser) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Determine Creator Details
        let creator = null;
        if (foundUser.createdBy) {
            if (foundUser.createdByModel === 'Admin') {
                const admin = await Admin.findById(foundUser.createdBy);
                if (admin) creator = { username: admin.username, role: 'Admin' };
            } else if (foundUser.createdByModel === 'Agent') {
                const agent = await Agent.findById(foundUser.createdBy);
                if (agent) creator = { username: agent.username, role: 'Agent' };
            }
        }

        // Find Agent if assigned (for regular users)
        let agent = null;
        if (foundUser.agentId) {
            agent = { username: foundUser.agentId.username };
        }

        let referredBy = null;
        let referralStats = {
            referredCount: 0,
            referralBonusGranted: Boolean(foundUser.referralBonusGranted),
            referralBonusAmount: Number(foundUser.referralBonusAmount || 0),
            referralBonusGrantedAt: foundUser.referralBonusGrantedAt || null,
            referralQualifiedDepositAt: foundUser.referralQualifiedDepositAt || null
        };
        if (foundUser.referredByUserId) {
            const referrer = await User.findById(foundUser.referredByUserId).select('username fullName');
            if (referrer) {
                referredBy = {
                    id: referrer._id,
                    username: referrer.username,
                    fullName: referrer.fullName
                };
            }
        }
        if (role === 'user') {
            referralStats.referredCount = await User.countDocuments({
                referredByUserId: foundUser._id
            });
        }

        // Aggregate Betting Stats
        const bettingStats = await Bet.aggregate([
            { $match: { userId: foundUser._id } },
            {
                $group: {
                    _id: null,
                    totalBets: { $sum: 1 },
                    totalWagered: { $sum: '$wagerAmount' },
                    totalWon: { $sum: { $cond: [{ $eq: ['$status', 'won'] }, '$payout', 0] } },
                    wins: { $sum: { $cond: [{ $eq: ['$status', 'won'] }, 1, 0] } },
                    losses: { $sum: { $cond: [{ $eq: ['$status', 'lost'] }, 1, 0] } },
                    voids: { $sum: { $cond: [{ $eq: ['$status', 'void'] }, 1, 0] } },
                    lastBetDate: { $max: '$createdAt' }
                }
            }
        ]);

        const stats = bettingStats[0] || {
            totalBets: 0,
            totalWagered: 0,
            totalWon: 0,
            wins: 0,
            losses: 0,
            voids: 0,
            lastBetDate: null
        };

        stats.netProfit = stats.totalWon - stats.totalWagered;

        res.status(200).json({
            user: {
                _id: foundUser._id,
                username: foundUser.username,
                firstName: foundUser.firstName,
                lastName: foundUser.lastName,
                fullName: foundUser.fullName,
                rawPassword: foundUser.rawPassword || '',
                phoneNumber: foundUser.phoneNumber,
                status: foundUser.status,
                role: role,
                agentId: foundUser.agentId?._id || foundUser.agentId || null,
                agentUsername: foundUser.agentId?.username || null,
                balance: foundUser.balance,
                pendingBalance: foundUser.pendingBalance || 0,
                creditLimit: foundUser.creditLimit,
                balanceOwed: foundUser.balanceOwed,
                freeplayBalance: foundUser.freeplayBalance,
                minBet: foundUser.minBet,
                maxBet: foundUser.maxBet,
                referredByUserId: foundUser.referredByUserId || null,
                defaultMinBet: foundUser.defaultMinBet,
                defaultMaxBet: foundUser.defaultMaxBet,
                defaultCreditLimit: foundUser.defaultCreditLimit,
                defaultSettleLimit: foundUser.defaultSettleLimit,
                createdAt: foundUser.createdAt
            },
            creator,
            agent,
            referredBy,
            referralStats,
            stats
        });

    } catch (error) {
        console.error('Error fetching user stats:', error);
        res.status(500).json({ message: 'Server error fetching user stats' });
    }
};
// Impersonate a user
exports.impersonateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const user = await User.findById(id);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Only admins can impersonate (or agents for their own users)
        if (req.user.role === 'agent' && String(user.agentId) !== String(req.user._id)) {
            return res.status(403).json({ message: 'Unauthorized to impersonate this user' });
        }

        const payload = buildAuthPayload(user);
        res.json({ ...payload, message: `Logged in as ${user.username}` });
    } catch (error) {
        console.error('Impersonation error:', error.message);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get Agent Tree Hierarchy
exports.getAgentTree = async (req, res) => {
    try {
        const rootId = req.user._id;
        const rootModel = req.user.role === 'admin' ? 'Admin' : 'Agent';

        // Helper to recursively build tree
        const buildTree = async (parentId, parentModel) => {
            // Find agents created by this parent
            const subAgents = await Agent.find({ createdBy: parentId, createdByModel: parentModel }).sort({ username: 1 });

            // Find users created by this parent
            const players = await User.find({ createdBy: parentId, createdByModel: parentModel }).sort({ username: 1 });

            let nodes = [];

            // Add agents
            for (const agent of subAgents) {
                const isDead = agent.username.toUpperCase() === 'DEAD';
                nodes.push({
                    id: agent._id,
                    username: agent.username,
                    role: agent.role,
                    isDead,
                    children: await buildTree(agent._id, 'Agent')
                });
            }

            // Add players
            for (const player of players) {
                nodes.push({
                    id: player._id,
                    username: player.username,
                    role: 'player',
                    children: []
                });
            }

            return nodes;
        };

        const tree = await buildTree(rootId, rootModel);

        res.status(200).json({
            root: {
                username: req.user.username,
                role: req.user.role,
                id: req.user._id
            },
            tree
        });
    } catch (error) {
        console.error('Error fetching agent tree:', error);
        res.status(500).json({ message: 'Server error fetching agent tree' });
    }
};

// Delete User (Admin Only)
exports.deleteUser = async (req, res) => {
    try {
        const { id } = req.params;
        const user = await User.findById(id);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Only Admin can delete
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Only Admins can delete users.' });
        }

        // Check balances
        const balance = parseFloat(user.balance?.toString() || '0');
        const pending = parseFloat(user.pendingBalance?.toString() || '0');

        if (Math.abs(balance) > 0.01) {
            return res.status(400).json({ message: `Cannot delete user with non-zero balance ($${balance.toFixed(2)}). Please settle first.` });
        }

        if (pending > 0) {
            return res.status(400).json({ message: `Cannot delete user with pending bets ($${pending.toFixed(2)}).` });
        }

        // Check for recent activity/Protect against accidental deletion of active users?
        // Requirement said check balance and pending only.

        await User.findByIdAndDelete(id);

        // Log deletion?
        console.log(`User ${user.username} deleted by Admin ${req.user.username}`);

        res.json({ message: `User ${user.username} successfully deleted.` });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({ message: 'Server error deleting user' });
    }
};

// Delete Agent (Admin Only)
exports.deleteAgent = async (req, res) => {
    try {
        const { id } = req.params;
        const agent = await Agent.findById(id);

        if (!agent) {
            return res.status(404).json({ message: 'Agent not found' });
        }

        // Only Admin can delete
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Only Admins can delete agents.' });
        }

        // Check balance
        const balance = parseFloat(agent.balance?.toString() || '0');
        if (Math.abs(balance) > 0.01) {
            return res.status(400).json({ message: `Cannot delete agent with non-zero balance ($${balance.toFixed(2)}). Settle first.` });
        }

        // Check for downline users
        const activeUsers = await User.countDocuments({ agentId: id });
        if (activeUsers > 0) {
            return res.status(400).json({ message: `Cannot delete agent. They have ${activeUsers} assigned users. Reassign or delete users first.` });
        }

        // Check for sub-agents (if Master Agent)
        if (agent.role === 'master_agent') {
            const subAgents = await Agent.countDocuments({ createdBy: id, createdByModel: 'Agent' });
            if (subAgents > 0) {
                return res.status(400).json({ message: `Cannot delete Master Agent. They have ${subAgents} sub-agents. Reassign or delete sub-agents first.` });
            }
        }

        await Agent.findByIdAndDelete(id);

        console.log(`Agent ${agent.username} deleted by Admin ${req.user.username}`);
        res.json({ message: `Agent ${agent.username} successfully deleted.` });

    } catch (error) {
        console.error('Error deleting agent:', error);
        res.status(500).json({ message: 'Server error deleting agent' });
    }
};
