const DURATION_MS = 4000;
const loadingSpinner = document.getElementById('loadingSpinner');
const percentEl = document.getElementById('loadingPercent');
const playBtn = document.getElementById('playBtn');
const game = document.querySelector('#game');
const dealBtn = document.querySelector('#dealBtn');
const hitBtn = document.querySelector('#hitBtn');
const standBtn = document.querySelector('#standBtn');
const splitBtn = document.querySelector('#splitBtn');
const doubleBtn = document.querySelector('#doubleBtn');
const clearAllBtn = document.querySelector('#clearAllBtn');
const betZones = document.querySelectorAll('.betZones');
const tableZones = document.querySelectorAll('.zones');
const scoreInfo = document.querySelectorAll('.scoreInfo');
const betStatusInfo = document.querySelectorAll('.numbersInfo');
const pairs = document.querySelectorAll('.pairs');
const plus = document.querySelectorAll('.plus23');
const superSevens = document.querySelectorAll('.superSevens');
const royal = document.querySelectorAll('.royal');
const chips = document.querySelectorAll('.chips');
const cardScore = document.querySelectorAll('.cardScore');
const insuranceBtn = document.querySelector('#insuranceBtn');
const undoBtn = document.querySelector('#undoBtn');
const noInsuranceBtn = document.querySelector('#noInsuranceBtn');
const surrenderBtn = document.querySelector('#surrenderBtn');
const evenMoneyBtn = document.querySelector('#evenMoneyBtn');
const rebetBtn = document.querySelector('#rebetBtn');
const newGameBtn = document.querySelector('#newGameBtn');
const helpBtn = document.querySelector('#helpBtn');
const pausePlayBtn = document.querySelector('#pausePlay');
const settingsBtn = document.querySelector('#settingsBtn');
const closeWindow = document.querySelectorAll('.closeWindow');
const loadingScreen = document.getElementById('loadingScreen');
const settingsWindow = document.querySelector('#settingsWindow');
const rebetDealBtn = document.querySelector('#rebetDealBtn');
const declineEvenMoneyBtn = document.querySelector('#declineEvenMoneyBtn');
const notifWindow = document.querySelector('#notification');
const sfxSlider = document.querySelector('#soundFx');
const musicChangeBtn = document.querySelectorAll('.changeMusic');
const musicPauseBtn = document.querySelector('#musicPause');
const musicVol = document.querySelector('#musicVolume');
const deckQtyEl = document.querySelector('#deckQuantity');
const helpWindow = document.querySelector('#helpWindow');
const scrollArea = helpWindow.querySelector('.help__scroll');
const zoneChips = [[], [], []];
const zonePairsChips = [[], [], []];
const zoneSplitChips = [[], [], []];
const zonePlus21Chips = [[], [], []];
const zoneRoyalChips = [[], [], []];
const zoneSuperSevenChips = [[], [], []];
const zoneInsuranceChips = [[], [], []];
const zoneSurrenderChips = [[], [], [], [], [], []];
const betHistory = [];
const BASE_ZONES = ['betZone1', 'betZone2', 'betZone3'];
const chipValues = [1, 5, 10, 25, 100, 1000];
const REBET_CHECK_BY = 'amount';
const songName = [
  'Velvet Groove',
  'Midnight Mirage',
  'Night Skies',
  'Lucky 8',
  'Elegance in Blue',
  'Forgiveness',
  'Your Beauty',
  'Moonlight',
];
const upgradeRules = {
  1: { count: 5, next: 5 },
  5: { count: 2, next: 10 },
  10: { count: 10, next: 100 },
  25: { count: 4, next: 100 },
  100: { count: 10, next: 1000 },
};

const groups = [
  { arr: plus, type: 'plus' },
  { arr: pairs, type: 'pair' },
  { arr: royal, type: 'royal' },
  { arr: superSevens, type: 'super7' },
  { arr: betZones, type: 'main' },
];
const chipSelectPositions = [
  { top: 67, right: 94 },
  { top: 71.8, right: 90.7 },
  { top: 76, right: 87.2 },
  { top: 79.6, right: 83.45 },
  { top: 82.7, right: 79.6 },
  { top: 85.3, right: 75.6 },
];
const betZoneInfo = {
  betZone1: {
    insuranceChipPositions: [55, 80.9],
    top: 36,
    right: 77,
    score: 0,
    suitCards: [],
    suitCardsScore: [],
    status: false,
    bet: 0,
    pairsBet: 0,
    plus21Bet: 0,
    royalBet: 0,
    insuranceBet: 0,
    superSevenBet: 0,
    scoreZone: scoreInfo[0],
    cardScore: cardScore[0],
    scoreZoneTop: 42,
    splitRight: [85, 69],
    scoreLeft: [12.5, 27.6],
    chipPositions: [55, 77.9],
    pairChipPositions: [59.2, 75.2],
    royalChipPositions: [59.2, 80.7],
    plus21ChipPositions: [52, 75.1],
    superSevenChipPositions: [52, 80.7],
  },
  betZone2: {
    insuranceChipPositions: [69.5, 51.8],
    top: 50,
    right: 47.9,
    status: false,
    score: 0,
    suitCards: [],
    suitCardsScore: [],
    bet: 0,
    pairsBet: 0,
    plus21Bet: 0,
    royalBet: 0,
    superSevenBet: 0,
    insuranceBet: 0,
    scoreZone: scoreInfo[1],
    cardScore: cardScore[2],
    scoreZoneTop: 58.8,
    splitRight: [56, 39.78],
    scoreLeft: [40.6, 56.7],
    chipPositions: [69.5, 48.8],
    pairChipPositions: [73.6, 46.1],
    royalChipPositions: [73.6, 51.4],
    plus21ChipPositions: [66.2, 46.1],
    superSevenChipPositions: [66.2, 51.4],
  },
  betZone3: {
    insuranceChipPositions: [55, 23.9],
    top: 36,
    right: 19.9,
    status: false,
    score: 0,
    suitCards: [],
    suitCardsScore: [],
    bet: 0,
    plus21Bet: 0,
    pairsBet: 0,
    royalBet: 0,
    superSevenBet: 0,
    insuranceBet: 0,
    scoreZone: scoreInfo[2],
    cardScore: cardScore[4],
    scoreZoneTop: 42,
    splitRight: [28.26, 11.86],
    scoreLeft: [68.5, 84.6],
    chipPositions: [55, 19.92],
    pairChipPositions: [59.3, 17.2],
    royalChipPositions: [59.3, 22.5],
    plus21ChipPositions: [52, 17.1],
    superSevenChipPositions: [52, 22.65],
  },
  splitZone1: {
    top: 36,
    right: 85,
    score: 0,
    scoreZone: scoreInfo[0],
    status: false,
    bet: 0,
    cardScore: cardScore[0],
    suitCards: [],
    suitCardsScore: [],
  },

  splitZone2: {
    top: 36,
    right: 69,
    score: 0,
    scoreZone: scoreInfo[6],
    status: false,
    bet: 0,
    cardScore: cardScore[1],
    suitCards: [],
    suitCardsScore: [],
  },

  splitZone3: {
    top: 50,
    right: 56,
    score: 0,
    status: false,
    bet: 0,
    scoreZone: scoreInfo[1],
    cardScore: cardScore[2],
    suitCards: [],
    suitCardsScore: [],
  },

  splitZone4: {
    top: 50,
    right: 39.78,
    score: 0,
    status: false,
    bet: 0,
    scoreZone: scoreInfo[7],
    cardScore: cardScore[3],
    suitCards: [],
    suitCardsScore: [],
  },

  splitZone5: {
    top: 36,
    right: 28.26,
    score: 0,
    status: false,
    bet: 0,
    scoreZone: scoreInfo[2],
    cardScore: cardScore[4],
    suitCards: [],
    suitCardsScore: [],
  },

  splitZone6: {
    top: 36,
    right: 11.86,
    score: 0,
    status: false,
    bet: 0,
    scoreZone: scoreInfo[8],
    cardScore: cardScore[5],
    suitCards: [],
    suitCardsScore: [],
  },

  dealerZone: {
    top: 16,
    right: 47.6,
    score: 0,
    cardScore: cardScore[6],
    suitCards: [],
    suitCardsScore: [],
  },
};
const playerInfo = {
  balance: 0,
  bet: 1,
  totalBet: 0,
  lastWin: 0,
};

let hideTimer;
let gameStart = false;
let afterInsurance = false;
let chipIndex = 0;
let rebetSnapshot = null;
let roundNet = 0;
let splitActive = false;
let insuranceActive = false;
let lastBalance = null;
let aceSplitInProgress = false;
let currentDecks = 6;
let activeZone;
let cardSuit;
let cardSuitValue;
let cardTexture;
let dealerStatus = false;
let canBet = true;
let __chipSendSoundTimer = null;
let __chipSendBatchCount = 0;
let sfxVolume = 0.5;
let musicNumber = 0;
let musicStatus = true;
let startTs = null;
let done = false;
let musicStatusColor = 'red';
let music = new Audio(`src/sfx/music/music0.mp3`);
const blackjackBridge = window.BetterdrBlackjackBridge || null;
let settlementInFlight = false;
let roundActionLog = [];
let roundHandMeta = {};
let roundStartBetSnapshot = null;
let roundInsuranceStakes = { betZone1: 0, betZone2: 0, betZone3: 0 };
let currentRoundRequestId = null;
let emergencySettlementSent = false;
let pendingRoundPersistTimer = null;
let pendingRoundRecoveryInFlight = false;
const PENDING_ROUND_STORAGE_KEY = 'betterdr_blackjack_pending_round_v1';

const money = (value) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return 0;
  return Math.round(parsed * 100) / 100;
};

const resetLastWinDisplay = () => {
  playerInfo.lastWin = 0;
  if (betStatusInfo[2]) {
    betStatusInfo[2].textContent = '$0.00';
  }
};

const resetRoundTracking = () => {
  roundActionLog = [];
  roundHandMeta = {};
  roundStartBetSnapshot = null;
  roundInsuranceStakes = { betZone1: 0, betZone2: 0, betZone3: 0 };
};

const logRoundAction = (action, zone = null, extra = {}) => {
  roundActionLog.push({
    action: String(action || '').trim().toLowerCase(),
    zone: zone ? String(zone) : null,
    at: Date.now(),
    ...extra,
  });
  if (roundActionLog.length > 256) {
    roundActionLog = roundActionLog.slice(-256);
  }
};

const rememberRoundHandMeta = (zone, patch = {}) => {
  if (!zone) return;
  const prev = roundHandMeta[zone] || {};
  roundHandMeta[zone] = { ...prev, ...patch };
};

const cardToPayloadCode = (cardEntry) => {
  if (Array.isArray(cardEntry) && cardEntry.length >= 2) {
    const suit = String(cardEntry[0] || '').trim().toLowerCase();
    const rank = String(cardEntry[1] || '').trim().toUpperCase();
    if (!rank || !suit) return '';
    return `${rank}:${suit}`;
  }
  const raw = String(cardEntry || '').trim();
  if (!raw) return '';
  return raw;
};

const cardsToPayload = (cards) =>
  (Array.isArray(cards) ? cards : [])
    .map((card) => cardToPayloadCode(card))
    .filter(Boolean);

const captureRoundStartBetSnapshot = () => {
  const snapshot = {};
  BASE_ZONES.forEach((zoneName) => {
    const zone = betZoneInfo[zoneName] || {};
    snapshot[zoneName] = {
      main: money(zone.bet || 0),
      pairs: money(zone.pairsBet || 0),
      plus21: money(zone.plus21Bet || 0),
      royal: money(zone.royalBet || 0),
      superSeven: money(zone.superSevenBet || 0),
      insurance: 0,
    };
  });
  return snapshot;
};

const updateBalanceUi = () => {
  if (betStatusInfo[0]) {
    betStatusInfo[0].textContent = '$' + (playerInfo.balance || 0).toLocaleString('de-DE');
  }
  if (typeof checkChipAvailable === 'function') {
    checkChipAvailable();
  }
};

const setAuthoritativeBalance = (value) => {
  playerInfo.balance = Math.max(0, money(value));
  updateBalanceUi();
};

const setSettlementUiState = (isPending) => {
  settlementInFlight = isPending;
  const interactiveButtons = [
    dealBtn,
    clearAllBtn,
    hitBtn,
    standBtn,
    splitBtn,
    doubleBtn,
    insuranceBtn,
    noInsuranceBtn,
    surrenderBtn,
    evenMoneyBtn,
    declineEvenMoneyBtn,
    undoBtn,
    rebetBtn,
    rebetDealBtn,
    newGameBtn,
  ];

  interactiveButtons.forEach((btn) => {
    if (!btn) return;
    btn.style.pointerEvents = isPending ? 'none' : '';
    btn.style.opacity = isPending ? '0.65' : '';
  });

  tableZones.forEach((el) => {
    el.style.pointerEvents = isPending ? 'none' : (gameStart ? 'none' : 'all');
  });
  chips.forEach((el) => {
    el.style.pointerEvents = isPending ? 'none' : '';
  });
};

// ─── Server-round driver (rebuild C1e) ──────────────────────────────
// The server deals every card and settles every round (staged API,
// rebuild C1b-C1d). This client renders EXACTLY what the server returns:
// cards enter the table only through per-zone queues filled from server
// responses, and every button is an async round-trip. No local deck, no
// browser-storage snapshots, no emergency settlement — an interrupted round
// lives server-side and resumes via the 'state' action on next load.

let serverRound = null;
let pendingSettlement = null;
const serverCardQueue = {};
const HOLE_CARD = { suit: 'hole', rank: '?' };

const bjCodeToCard = (code) => {
  const parts = String(code || '').split(':');
  return { rank: parts[0] || '?', suit: parts[1] || 's1' };
};

const bjQueuePush = (zone, card) => {
  serverCardQueue[zone] = serverCardQueue[zone] || [];
  serverCardQueue[zone].push(card);
};

const bjResetQueues = () => {
  Object.keys(serverCardQueue).forEach((k) => delete serverCardQueue[k]);
};

const bjHandsByZone = (resp) => {
  const map = {};
  ((resp && resp.state && resp.state.hands) || []).forEach((h) => {
    map[h.zone] = h;
  });
  return map;
};

const bjLoadDealQueues = (resp) => {
  bjResetQueues();
  const hands = bjHandsByZone(resp);
  Object.keys(hands).forEach((zone) => {
    (hands[zone].cards || []).forEach((c) => bjQueuePush(zone, bjCodeToCard(c)));
  });
  const dealer = resp.state && resp.state.dealer ? resp.state.dealer : {};
  if (dealer.holeHidden) {
    bjQueuePush('dealerZone', bjCodeToCard(dealer.upCard));
    bjQueuePush('dealerZone', HOLE_CARD);
  } else {
    (dealer.cards || []).forEach((c) => bjQueuePush('dealerZone', bjCodeToCard(c)));
  }
};

const bjQueueZoneDelta = (resp, zone) => {
  const hand = bjHandsByZone(resp)[zone];
  if (!hand) return;
  const have =
    betZoneInfo[zone] && betZoneInfo[zone].suitCardsScore
      ? betZoneInfo[zone].suitCardsScore.length
      : 0;
  (hand.cards || []).slice(have).forEach((c) => bjQueuePush(zone, bjCodeToCard(c)));
};

const bjQueueSplitCards = (resp, baseZone) => {
  const mapping = {
    betZone1: ['splitZone1', 'splitZone2'],
    betZone2: ['splitZone3', 'splitZone4'],
    betZone3: ['splitZone5', 'splitZone6'],
  };
  const hands = bjHandsByZone(resp);
  (mapping[baseZone] || []).forEach((sz) => {
    const hand = hands[sz];
    if (hand && (hand.cards || []).length >= 2) {
      bjQueuePush(sz, bjCodeToCard(hand.cards[1]));
    }
  });
};

const bjDimZone = (zone) => {
  document.querySelectorAll(`.card.cardEnd.${zone}`).forEach((card) => {
    applyBaseTransform(card);
    card.style.filter = 'brightness(0.5)';
  });
};

const bjAwaitingInsurance = (resp) => {
  const a = resp && resp.state && resp.state.awaiting;
  return !!(
    a &&
    a.actions &&
    (a.actions.indexOf('insurance') !== -1 || a.actions.indexOf('even_money') !== -1)
  );
};

const bjApplyActionResponse = (resp) => {
  if (!resp) return;
  if (resp.newBalance !== undefined) setAuthoritativeBalance(resp.newBalance);
  if (String(resp.roundStatus) === 'settled') {
    pendingSettlement = resp;
    if (!dealerStatus) dealerPlay();
    return;
  }
  const awaiting = resp.state && resp.state.awaiting ? resp.state.awaiting : null;
  const nextZone = awaiting ? awaiting.zone : null;
  if (nextZone && nextZone !== activeZone) {
    if (activeZone) bjDimZone(activeZone);
    activeZone = nextZone;
  }
  if (bjAwaitingInsurance(resp)) {
    afterInsurance = false;
    checkButtons();
    return;
  }
  afterInsurance = true;
  if (activeZone) activeHand(activeZone);
};


const syncBalanceFromSite = async () => {
  if (!blackjackBridge || typeof blackjackBridge.getBalance !== 'function') {
    return;
  }

  try {
    const payload = await blackjackBridge.getBalance();
    const nextBalance = payload && payload.balance !== undefined ? payload.balance : payload.newBalance;
    setAuthoritativeBalance(nextBalance);
  } catch (err) {
    if (typeof notification === 'function') {
      notification('BALANCE SYNC FAILED');
    }
    console.error('Blackjack balance sync failed:', err);
  }
};

const bjRequest = async (bets, requestId = null) => {
  if (!blackjackBridge || typeof blackjackBridge.send !== 'function') {
    notification('SITE BRIDGE NOT AVAILABLE');
    return null;
  }
  setSettlementUiState(true);
  try {
    return await blackjackBridge.send(bets, requestId);
  } catch (err) {
    notification(err && err.message ? String(err.message) : 'SERVER ERROR');
    await syncBalanceFromSite();
    return null;
  } finally {
    setSettlementUiState(false);
  }
};

const bjDeal = async (zones) => {
  const requestId = blackjackBridge.createRequestId('blackjack_round');
  const resp = await bjRequest({ action: 'deal', zones: zones }, requestId);
  if (resp) {
    serverRound = { requestId: String(resp.requestId || requestId), lastResponse: resp };
    if (resp.newBalance !== undefined) setAuthoritativeBalance(resp.newBalance);
  }
  return resp;
};

const bjSendAction = async (action, zone, extra = {}) => {
  if (!serverRound || !serverRound.requestId) {
    notification('NO ACTIVE ROUND');
    return null;
  }
  const resp = await bjRequest(
    Object.assign(
      {
        action: action,
        zone: zone,
        actionRequestId: blackjackBridge.createRequestId('bj_act'),
        roundRequestId: serverRound.requestId,
      },
      extra
    )
  );
  if (resp) serverRound.lastResponse = resp;
  return resp;
};

const bjFetchOpenRound = async () => {
  const resp = await bjRequest({ action: 'state' });
  return resp && resp.round ? resp.round : null;
};

const bjResumeRender = (round) => {
  const state = round.state || {};
  bjResetQueues();
  (state.hands || []).forEach((h) => {
    const zone = h.zone;
    if (!betZoneInfo[zone]) return;
    betZoneInfo[zone].status = true;
    betZoneInfo[zone].bet = Number(h.bet) || 0;
    (h.cards || []).forEach((c) => bjQueuePush(zone, bjCodeToCard(c)));
  });
  const dealer = state.dealer || {};
  if (dealer.holeHidden) {
    bjQueuePush('dealerZone', bjCodeToCard(dealer.upCard));
    bjQueuePush('dealerZone', HOLE_CARD);
  }
  gameStart = true;
  let delay = 0;
  const zonesToRender = (state.hands || []).map((h) => h.zone).concat(['dealerZone']);
  zonesToRender.forEach((zone) => {
    const q = (serverCardQueue[zone] || []).slice();
    q.forEach((_, idx) => {
      setTimeout(() => {
        const info = betZoneInfo[zone];
        if (!info) return;
        const flip = !(zone === 'dealerZone' && idx === 1);
        dealCard(zone, info.top, info.right - idx, flip);
      }, delay);
      delay += 220;
    });
  });
  setTimeout(() => {
    const awaiting = state.awaiting || null;
    activeZone = awaiting ? awaiting.zone : null;
    afterInsurance = !bjAwaitingInsurance({ state: state });
    if (activeZone) activeHand(activeZone);
    checkButtons();
  }, delay + 600);
};

const bootstrapBlackjackSession = async () => {
  await syncBalanceFromSite();
  const round = await bjFetchOpenRound();
  if (!round || !round.state) return;
  serverRound = { requestId: String(round.requestId || ''), lastResponse: null };
  notification('ROUND RESUMED');
  bjResumeRender(round);
};


if (deckQtyEl) {
  // Deck count is fixed SERVER-side at 6 — the picker is display-only.
  deckQtyEl.value = '6';
  deckQtyEl.disabled = true;
  currentDecks = 6;
  const deckNumEl = document.querySelector('#deckNum');
  if (deckNumEl) deckNumEl.textContent = '6';
}

function tick(ts) {
  if (!startTs) startTs = ts;
  const elapsed = ts - startTs;
  const pct = Math.min(100, Math.floor((elapsed / DURATION_MS) * 100));
  if (percentEl.textContent !== pct) {
    percentEl.textContent = pct;
  }
  if (pct >= 100 && !done) {
    done = true;
    percentEl.style.fontSize = '4vh';
    percentEl.innerHTML = 'GOOD <br/> LUCK';
    loadingSpinner.style.animationPlayState = 'paused';
    percentEl.style.animationPlayState = 'paused';
    playBtn.style.pointerEvents = 'all';
    playBtn.style.opacity = '1';
    return;
  }
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);
setSettlementUiState(false);
bootstrapBlackjackSession();

const zoneSum = (z) =>
  [
    'bet',
    'pairsBet',
    'plus21Bet',
    'royalBet',
    'superSevenBet',
    'insuranceBet',
  ].reduce((sum, k) => sum + (betZoneInfo[z]?.[k] ?? 0), 0);

function anyBetsOnTable() {
  return BASE_ZONES.some(zoneSum);
}

const updateUndoBtnState = () =>
  undoBtn?.classList.toggle(
    'inactiveBtn',
    !anyBetsOnTable() || !betHistory.length
  );

const showStandardButtons = () =>
  [dealBtn, clearAllBtn, undoBtn].forEach(
    (el) => el && (el.style.display = 'flex')
  );
const hideStandardButtons = () =>
  [dealBtn, clearAllBtn, undoBtn].forEach(
    (el) => el && (el.style.display = 'none')
  );
const showPostRoundButtons = () =>
  [newGameBtn, rebetBtn, rebetDealBtn].forEach(
    (el) => el && (el.style.display = 'flex')
  );
const hidePostRoundButtons = () =>
  [newGameBtn, rebetBtn, rebetDealBtn].forEach(
    (el) => el && (el.style.display = 'none')
  );

function applyBaseTransform(cardOrEl) {
  if (!cardOrEl) return;
  if (cardOrEl.classList && cardOrEl.classList.contains('doubleTilt')) {
    cardOrEl.style.transform =
      'perspective(12vh) rotateX(10deg) rotateZ(90deg) scale(1)';
  } else {
    cardOrEl.style.transform = 'perspective(12vh) rotateX(10deg) scale(1)';
  }
}

function dealCard(zone, targetTop, targetRight, flip = true, isDouble = false) {
  getCardScore(zone, flip);
  document
    .querySelectorAll('.buttonAreaBtns')
    .forEach((el) => (el.style.display = 'none'));
  const game = document.getElementById('game'),
    baseCard = document.querySelector('.card'),
    card = document.createElement('div');
  card.classList.add('card', zone);
  card.innerHTML =
    '<div class="card-inner"><div class="card-back"></div><div class="card-front" style="background-image:url(src/images/' +
    cardSuit +
    '/' +
    cardTexture +
    '.png)"></div></div>';
  if (isDouble) {
    card.classList.add('doubleTilt');
    card.style.transform = 'rotateZ(90deg) scale(1.1)';
  }
  const cs = baseCard ? getComputedStyle(baseCard) : null;
  card.style.top = cs ? cs.top : '1.8%';
  card.style.right = cs ? cs.right : '67.8%';
  game.appendChild(card);
  setTimeout(() => {
    setTimeout(() => {
      playSound('sendCard');
    }, 100);
    card.style.top = '19%';
    card.style.right = '27%';
    setTimeout(() => {
      card.style.top = targetTop + '%';
      card.style.right = targetRight + '%';
      card.classList.add('cardEnd');
    }, 250);
  }, 50);
  setTimeout(() => {
    if (flip) card.classList.add('flipped');
    if (!isDouble && !splitActive && !zone.startsWith('splitZone'))
      applyBaseTransform(card);
    if (betZoneInfo[zone].cardScore && (zone !== 'dealerZone' || flip)) {
      betZoneInfo[zone].cardScore.textContent = betZoneInfo[zone].score;
      betZoneInfo[zone].cardScore.style.opacity = 1;
    }
  }, 500);
  if (zone === 'dealerZone' && !flip) card.classList.add('cardInactive');
  setTimeout(() => {
    if (gameStart && !dealerStatus) checkButtons();
  }, 1000);
  return card;
}

async function deal() {
  if (settlementInFlight) return;
  if (lastBalance === null) lastBalance = playerInfo.balance;
  const zonesPayload = {};
  ['betZone1', 'betZone2', 'betZone3'].forEach((zone) => {
    const z = betZoneInfo[zone] || {};
    const entry = {
      main: money(z.bet || 0),
      pairs: money(z.pairsBet || 0),
      plus21: money(z.plus21Bet || 0),
      royal: money(z.royalBet || 0),
    };
    if (entry.main > 0 || entry.pairs > 0 || entry.plus21 > 0 || entry.royal > 0) {
      zonesPayload[zone] = entry;
    }
  });
  if (!Object.keys(zonesPayload).length) {
    notification('NO BETS PLACED');
    return;
  }
  const resp = await bjDeal(zonesPayload);
  if (!resp) return;
  resetLastWinDisplay();
  snapshotRebet();
  bjLoadDealQueues(resp);
  dealVisual(resp);
  dealBtn.style.display = 'none';
  clearAllBtn.style.display = 'none';
  tableZones.forEach((el) => {
    el.style.pointerEvents = 'none';
  });
  chips.forEach((el) => {
    el.style.pointerEvents = 'none';
  });
  if (undoBtn) undoBtn.style.display = 'none';
}

function dealVisual(resp) {
  const activeZones = Object.keys(betZoneInfo).filter(
    (zone) => betZoneInfo[zone].status && zone !== 'dealerZone'
  );
  const dealtCount = {};
  activeZones.forEach((zone) => (dealtCount[zone] = 0));
  dealtCount['dealerZone'] = 0;
  const order = [];
  for (let round = 0; round < 2; round++) {
    activeZones.forEach((zone) => order.push(zone));
    order.push('dealerZone');
  }
  order.forEach((zone, i) => {
    setTimeout(() => {
      const { top, right } = betZoneInfo[zone];
      dealtCount[zone]++;
      const offsetRight = dealtCount[zone] > 1 ? right - 1 : right;
      const flip = !(zone === 'dealerZone' && dealtCount[zone] === 2);
      dealCard(zone, top, offsetRight, flip);
      if (i === order.length - 1) {
        setTimeout(() => {
          gameStart = true;
          activeZones.forEach((z) => {
            const bz = betZoneInfo[z];
            if (bz && bz.score === 21 && (bz.suitCards || []).length === 2) {
              createBetNotif(z, 'BLACKJACK');
            }
          });
          if (String(resp.roundStatus) === 'settled') {
            pendingSettlement = resp;
            dealerPlay();
            return;
          }
          document.querySelectorAll('.card.cardEnd').forEach((card) => {
            card.style.filter = 'brightness(0.5)';
          });
          const awaiting = resp.state && resp.state.awaiting ? resp.state.awaiting : null;
          activeZone = awaiting ? awaiting.zone : activeZones[0] || null;
          afterInsurance = !bjAwaitingInsurance(resp);
          if (activeZone) activeHand(activeZone);
          checkButtons();
        }, 800);
      }
    }, i * 500);
  });
}

function placeBet(betName, type = 'main') {
  if (settlementInFlight) return;
  if (!canBet) return;
  if (playerInfo.bet <= 0) {
    notification('NO CHIPS AVAILABLE');
    return;
  }
  if (playerInfo.bet > playerInfo.balance) {
    notification('NOT ENOUGH MONEY');
    return;
  }
  let scoreBet;
  let betType;
  if (lastBalance === null) lastBalance = playerInfo.balance;
  const index = betName === 'betZone1' ? 0 : betName === 'betZone2' ? 1 : 2;
  if (type !== 'main' && (betZoneInfo[betName].bet || 0) <= 0) {
    notification('PLACE MAIN BET FIRST');
    return;
  }
  if (type === 'super7') {
    notification('SUPER SEVENS IS NO LONGER OFFERED');
    return;
  }
  if (type === 'pair') {
    if (betZoneInfo[betName].pairsBet + playerInfo.bet > 100) {
      notification('SIDE BETS MAX 100');
      return;
    }
    betZoneInfo[betName].pairsBet += playerInfo.bet;
    scoreBet = '.pairInfo';
    betType = 'pairsBet';
  } else if (type === 'plus') {
    if (betZoneInfo[betName].plus21Bet + playerInfo.bet > 100) {
      notification('SIDE BETS MAX 100');
      return;
    }
    betZoneInfo[betName].plus21Bet += playerInfo.bet;
    scoreBet = '.plus21Info';
    betType = 'plus21Bet';
  } else if (type === 'royal') {
    if (betZoneInfo[betName].royalBet + playerInfo.bet > 100) {
      notification('SIDE BETS MAX 100');
      return;
    }
    betZoneInfo[betName].royalBet += playerInfo.bet;
    scoreBet = '.royalInfo';
    betType = 'royalBet';
  } else if (type === 'super7') {
    if (betZoneInfo[betName].superSevenBet + playerInfo.bet > 100) {
      notification('SIDE BETS MAX 100');
      return;
    }
    betZoneInfo[betName].superSevenBet += playerInfo.bet;
    scoreBet = '.superSevenInfo';
    betType = 'superSevenBet';
  } else {
    if (betZoneInfo[betName].bet + playerInfo.bet > 1000) {
      notification('MAX BET 1000');
      return;
    }
    betZoneInfo[betName].bet += playerInfo.bet;
    betZoneInfo[betName].status = betZoneInfo[betName].bet > 0;
    scoreBet = '.mainInfo';
    betType = 'bet';
  }
  const scoreElement = document.querySelectorAll(scoreBet);
  createChipWithFlight(playerInfo.bet, index, type);
  playerInfo.balance -= playerInfo.bet;
  playerInfo.totalBet += playerInfo.bet;
  betStatusInfo[1].textContent =
    '$' + playerInfo.totalBet.toLocaleString('de-DE');
  betStatusInfo[0].textContent =
    '$' + playerInfo.balance.toLocaleString('de-DE');
  scoreElement[index].textContent =
    '$' + betZoneInfo[betName][betType].toLocaleString('de-DE');
  scoreElement[index].style.opacity = 1;
  betHistory.push({
    betName,
    type,
    value: playerInfo.bet,
    timestamp: Date.now(),
  });
  dealBtn.classList.remove('inactiveBtn');
  clearAllBtn.classList.remove('inactiveBtn');
  undoBtn.classList.remove('inactiveBtn');
  updateUndoBtnState();
}

function clearBets() {
  if (settlementInFlight) return;
  try {
    const allGroups = [
      zoneChips,
      zonePairsChips,
      zoneSplitChips,
      zonePlus21Chips,
      zoneRoyalChips,
      zoneSuperSevenChips,
      zoneInsuranceChips,
      zoneSurrenderChips,
    ];
    const totalChipsOnTable = allGroups.reduce(
      (sum, group) => sum + group.reduce((s, arr) => s + (arr?.length || 0), 0),
      0
    );
    if (totalChipsOnTable === 1) {
      playSound('undoChip');
    } else if (totalChipsOnTable > 1) {
      playSound('lotChips');
    }
  } catch (_) {}

  const refund = BASE_ZONES.reduce((acc, z) => acc + zoneSum(z), 0);
  if (refund > 0) {
    playerInfo.balance += refund;
  }
  playerInfo.totalBet = 0;
  betStatusInfo[0].textContent =
    '$' + playerInfo.balance.toLocaleString('de-DE');
  betStatusInfo[1].textContent = '$0';
  BASE_ZONES.forEach((z) => {
    const bz = betZoneInfo[z];
    if (!bz) return;
    bz.bet = 0;
    bz.pairsBet = 0;
    bz.plus21Bet = 0;
    bz.royalBet = 0;
    bz.superSevenBet = 0;
    bz.insuranceBet = 0;
    bz.status = false;
    if (bz.scoreZone) {
      bz.scoreZone.textContent = '';
      bz.scoreZone.style.opacity = 0;
    }
  });
  [
    zoneChips,
    zonePairsChips,
    zoneSplitChips,
    zonePlus21Chips,
    zoneRoyalChips,
    zoneSuperSevenChips,
    zoneInsuranceChips,
    zoneSurrenderChips,
  ].forEach((group) => {
    group.forEach((arr) => {
      arr.forEach((chip) => chip && chip.remove && chip.remove());
      arr.length = 0;
    });
  });
  document
    .querySelectorAll(
      '.pairInfo, .plus21Info, .royalInfo, .superSevenInfo, .insuranceInfo'
    )
    .forEach((el) => {
      el.textContent = '';
      el.style.boxShadow = 'none';
      el.style.opacity = 0;
    });
  betHistory.length = 0;
  lastBalance = null;
  resetLastWinDisplay();
  if (dealBtn) dealBtn.classList.add('inactiveBtn');
  if (clearAllBtn) clearAllBtn.classList.add('inactiveBtn');
  if (undoBtn) undoBtn.classList.add('inactiveBtn');
  checkChipAvailable();
}

function checkChipAvailable() {
  const bal = Number(playerInfo.balance) || 0;
  let activeIdx = -1;
  for (let i = 0; i < chips.length; i++) {
    if (chips[i].classList.contains('chipActive')) {
      activeIdx = i;
      break;
    }
  }
  chips.forEach((chipEl, i) => {
    const denom = chipValues[i];
    const affordable = bal >= denom;
    if (affordable) {
      chipEl.style.pointerEvents = 'all';
      chipEl.style.opacity = '';
      chipEl.style.filter = 'grayscale(0) brightness(0.6)';
    } else {
      chipEl.style.pointerEvents = 'none';
      chipEl.style.filter = 'grayscale(1) brightness(0.6)';
      chipEl.style.opacity = '0.4';
      if (chipEl.classList.contains('chipActive')) {
        chipEl.classList.remove('chipActive');
        activeIdx = -1;
      }
    }
  });
  if (activeIdx >= 0 && chipValues[activeIdx] > bal) {
    activeIdx = -1;
  }
  if (activeIdx === -1) {
    for (let k = chipValues.length - 1; k >= 0; k--) {
      if (chipValues[k] <= bal) {
        chips.forEach((c) => c.classList.remove('chipActive'));
        chips[k].classList.add('chipActive');
        playerInfo.bet = chipValues[k];
        chipIndex = k;
        activeIdx = k;
        break;
      }
    }
  }
  if (activeIdx >= 0) {
    chips[activeIdx].style.filter = 'grayscale(0) brightness(1)';
    chips[activeIdx].style.opacity = '';
  } else {
    playerInfo.bet = 0;
    chipIndex = -1;
  }
}

function chipSelect(bet, index) {
  for (let i = 0; i < chips.length; i++) {
    const isActive = i === index;
    const affordable = Number(playerInfo.balance) >= chipValues[i];
    chips[i].classList.toggle('chipActive', isActive);
    if (affordable) {
      chips[i].style.opacity = '';
      chips[i].style.filter = isActive
        ? 'grayscale(0) brightness(1)'
        : 'grayscale(0) brightness(0.6)';
    } else {
      chips[i].style.pointerEvents = 'none';
      chips[i].style.filter = 'grayscale(1) brightness(0.6)';
      chips[i].style.opacity = '0.4';
    }
  }
  playerInfo.bet = bet;
  chipIndex = index;
}

function activeHand(zone) {
  if (!zone) return;
  document.querySelectorAll('.card.cardEnd').forEach((card) => {
    const isSplit = [...card.classList].some((cls) =>
      cls.startsWith('splitZone')
    );
    if (!isSplit) {
      applyBaseTransform(card);
    }
  });
  const cards = document.querySelectorAll(`.card.cardEnd.${zone}`);
  const cardArr = Array.from(cards).slice(0, 2);
  if (cardArr[0]) {
    cardArr[0].style.transform = 'scale(1.1)';
    cardArr[0].style.filter = 'brightness(1) ';
  }
  if (cardArr[1]) {
    cardArr[1].style.transform = 'scale(1.1)';
    cardArr[1].style.filter = 'brightness(1) ';
  }
  betZoneInfo[activeZone].cardScore.style.animation =
    'float-up-down 1s ease-in-out infinite';
  checkButtons();
  document.querySelector('#playerMenu').style.display = 'flex';
}

async function hit() {
  if (settlementInFlight || !activeZone) return;
  const zone = activeZone;
  const resp = await bjSendAction('hit', zone);
  if (!resp) return;
  bjQueueZoneDelta(resp, zone);
  const { top, right } = betZoneInfo[zone];
  const len = document.querySelectorAll(`.card.cardEnd.${zone}`).length;
  dealCard(zone, top, right - len, true);
  setTimeout(() => {
    const newCard = document.querySelector(`.card.cardEnd.${zone}:last-child`);
    if (newCard) {
      newCard.style.transform = `scale(1.1)`;
      newCard.style.filter = 'brightness(1)';
    }
    const z = betZoneInfo[zone];
    if (z && z.score > 21) createBetNotif(zone, 'BUST');
    else if (z && z.score === 21) createBetNotif(zone, '21');
    bjApplyActionResponse(resp);
  }, 700);
}


function recomputeZoneScore(zoneName) {
  const z = betZoneInfo[zoneName];
  const ranks = (z.suitCardsScore || []).map(([, r]) => r);
  let total = 0,
    aces = 0;
  const numeric = [];
  for (const r of ranks) {
    if (r === 'A') {
      total += 11;
      aces += 1;
      numeric.push(11);
    } else if (r === 'K' || r === 'Q' || r === 'J') {
      total += 10;
      numeric.push(10);
    } else {
      const v = Number(r);
      if (!Number.isFinite(v)) continue; // hole-card placeholder
      total += v;
      numeric.push(v);
    }
  }
  while (total > 21 && aces > 0) {
    total -= 10;
    aces -= 1;
  }
  z.score = total;
  z.suitCards = numeric;
}

function getCardScore(zone, flip = true) {
  // Cards come EXCLUSIVELY from the server: every deal/hit/double/split/
  // dealer draw consumes the next queued server card. No local RNG exists.
  const q = serverCardQueue[zone];
  const c = q && q.length ? q.shift() : null;
  if (!c) {
    console.error('blackjack: no server card queued for zone', zone);
    return;
  }
  cardSuit = c.suit;
  cardTexture = c.rank;
  betZoneInfo[zone].suitCardsScore.push([c.suit, c.rank]);
  recomputeZoneScore(zone);
}

async function split() {
  if (settlementInFlight || !activeZone || !activeZone.startsWith('betZone')) return;
  const resp = await bjSendAction('split', activeZone);
  if (!resp) return;
  bjQueueSplitCards(resp, activeZone);
  splitVisual(resp);
  setTimeout(() => bjApplyActionResponse(resp), 2600);
}

function splitVisual(resp) {
  if (!activeZone) return;
  document.querySelector('#playerMenu').style.display = 'none';
  splitActive = true;
  document.querySelectorAll('.cardScore').forEach((el) => {
    el.style.animation = 'none';
  });
  document.querySelectorAll('.buttonAreaBtns').forEach((el) => {
    el.style.display = 'none';
  });
  const mapping = {
    betZone1: ['splitZone1', 'splitZone2', 0, 6, 10.1, 26.2],
    betZone2: ['splitZone3', 'splitZone4', 1, 7, 39.15, 55.35],
    betZone3: ['splitZone5', 'splitZone6', 2, 8, 67.1, 83.24],
  };
  const origScores = betZoneInfo[activeZone].suitCardsScore || [];
  const isAcesSplit =
    Array.isArray(origScores) &&
    origScores.length >= 2 &&
    origScores[0][1] === 'A' &&
    origScores[1][1] === 'A';
  const pair = mapping[activeZone];
  if (!pair) return;
  logRoundAction('split', activeZone, { bet: money(betZoneInfo[activeZone].bet || 0) });
  const [splitZone1, splitZone2] = pair;
  const cards = Array.from(
    document.querySelectorAll(`.card.cardEnd.${activeZone}`)
  ).slice(0, 2);
  if (cards.length < 2) return;
  const originalSuitCards = betZoneInfo[activeZone].suitCards.slice(0, 2);
  betZoneInfo[splitZone1].suitCards = [originalSuitCards[0]];
  betZoneInfo[splitZone2].suitCards = [originalSuitCards[1]];
  betZoneInfo[splitZone1].bet = betZoneInfo[activeZone].bet;
  betZoneInfo[splitZone2].bet = betZoneInfo[activeZone].bet;
  betZoneInfo[splitZone1].score = betZoneInfo[splitZone1].suitCards.reduce(
    (a, b) => (a || 0) + b,
    0
  );
  betZoneInfo[splitZone2].score = betZoneInfo[splitZone2].suitCards.reduce(
    (a, b) => (a || 0) + b,
    0
  );
  betZoneInfo[splitZone1].suitCardsScore = origScores.slice(0, 1);
  betZoneInfo[splitZone2].suitCardsScore = origScores.slice(1, 2);
  betZoneInfo[activeZone].suitCardsScore = origScores.slice(2);
  betZoneInfo[activeZone].suitCards =
    betZoneInfo[activeZone].suitCards.slice(2) || [];
  betZoneInfo[activeZone].score = betZoneInfo[activeZone].suitCards.reduce(
    (a, b) => (a || 0) + b,
    0
  );
  const sl = betZoneInfo[activeZone].scoreLeft || [];
  if (sl.length >= 2) {
    if (betZoneInfo[splitZone1].cardScore) {
      betZoneInfo[splitZone1].cardScore.textContent =
        betZoneInfo[splitZone1].score;
      betZoneInfo[splitZone1].cardScore.style.left = sl[0] + '%';
    }
    if (betZoneInfo[splitZone2].cardScore) {
      betZoneInfo[splitZone2].cardScore.textContent =
        betZoneInfo[splitZone2].score;
      betZoneInfo[splitZone2].cardScore.style.left = sl[1] + '%';
      betZoneInfo[splitZone2].cardScore.style.opacity = 1;
    }
  }
  betZoneInfo[activeZone].status = false;
  betZoneInfo[splitZone1].status = true;
  betZoneInfo[splitZone2].status = true;
  rememberRoundHandMeta(splitZone1, { isSplit: true });
  rememberRoundHandMeta(splitZone2, { isSplit: true });
  scoreInfo[mapping[activeZone][2]].style.left = mapping[activeZone][4] + '%';
  scoreInfo[mapping[activeZone][3]].style.left = mapping[activeZone][5] + '%';
  scoreInfo[mapping[activeZone][3]].textContent =
    '$' + betZoneInfo[splitZone2].bet.toLocaleString('de-DE');
  scoreInfo[mapping[activeZone][3]].style.opacity = 1;
  cards.forEach((card) => {
    card.style.transform = 'none';
    card.classList.remove(activeZone);
  });

  const { top, splitRight } = betZoneInfo[activeZone];
  cards[0].classList.add(splitZone1);
  cards[0].style.top = top + '%';
  cards[0].style.right =
    (splitRight && splitRight[0] !== undefined
      ? splitRight[0]
      : betZoneInfo[splitZone1].right) + '%';
  cards[1].classList.add(splitZone2);
  cards[1].style.top = top + '%';
  cards[1].style.right =
    (splitRight && splitRight[1] !== undefined
      ? splitRight[1]
      : betZoneInfo[splitZone2].right) + '%';
  if (isAcesSplit) {
    aceSplitInProgress = true;
    dealCard(
      splitZone1,
      betZoneInfo[splitZone1].top,
      betZoneInfo[splitZone1].right - 1,
      true
    );
    setTimeout(() => {
      dealCard(
        splitZone2,
        betZoneInfo[splitZone2].top,
        betZoneInfo[splitZone2].right - 1,
        true
      );
      setTimeout(() => {
        aceSplitInProgress = false;
      }, 800);
    }, 300);
  } else {
    dealCard(
      splitZone1,
      betZoneInfo[splitZone1].top,
      betZoneInfo[splitZone1].right - 1,
      true
    );
    setTimeout(() => {
      dealCard(
        splitZone2,
        betZoneInfo[splitZone2].top,
        betZoneInfo[splitZone2].right - 1,
        true
      );
      setTimeout(() => {
        activeZone = splitZone1;
        activeHand(activeZone);
        const inactiveCards = document.querySelectorAll(`.card.${splitZone2}`);
        inactiveCards.forEach((card) => {
          applyBaseTransform(card);
          card.style.filter = 'brightness(0.5)';
        });
        if (activeZone === splitZone2) {
          activeHand(activeZone);
        }
      }, 1500);
    }, 400);
  }
  splitChips(activeZone);
  playerInfo.balance -= betZoneInfo[activeZone].bet;
  playerInfo.totalBet += betZoneInfo[activeZone].bet;
  betZoneInfo[activeZone].bet = 0;
  betStatusInfo[0].textContent =
    '$' + playerInfo.balance.toLocaleString('de-DE');
  betStatusInfo[1].textContent =
    '$' + playerInfo.totalBet.toLocaleString('de-DE');
}

async function stand() {
  if (settlementInFlight || !activeZone) return;
  const zone = activeZone;
  const resp = await bjSendAction('stand', zone);
  if (!resp) return;
  document.querySelectorAll('.cardScore').forEach((el) => {
    el.style.animation = 'none';
  });
  document.querySelectorAll('.buttonAreaBtns').forEach((el) => {
    el.style.display = 'none';
  });
  bjDimZone(zone);
  bjApplyActionResponse(resp);
}

function dealerPlay() {
  // Terminal render: everything comes from the settled server response.
  splitActive = false;
  dealerStatus = true;
  const resp = pendingSettlement;
  if (!resp) return;
  const dealerCards =
    (resp.betDetails && resp.betDetails.dealer && resp.betDetails.dealer.cards) ||
    resp.dealerCards || [];

  document
    .querySelectorAll('.card.dealerZone')
    .forEach((card) => (card.style.filter = 'brightness(1)'));

  const hiddenCard = document.querySelector('.card.dealerZone.cardInactive');
  if (hiddenCard && dealerCards.length >= 2) {
    const hole = bjCodeToCard(dealerCards[1]);
    const front = hiddenCard.querySelector('.card-front');
    if (front) {
      front.style.backgroundImage = `url(src/images/${hole.suit}/${hole.rank}.png)`;
    }
    hiddenCard.classList.add('flipped');
    hiddenCard.classList.remove('cardInactive');
    if ((betZoneInfo.dealerZone.suitCardsScore || []).length >= 2) {
      betZoneInfo.dealerZone.suitCardsScore[1] = [hole.suit, hole.rank];
      recomputeZoneScore('dealerZone');
    }
  }
  if (betZoneInfo.dealerZone.cardScore) {
    betZoneInfo.dealerZone.cardScore.textContent = betZoneInfo.dealerZone.score;
    betZoneInfo.dealerZone.cardScore.style.opacity = 1;
  }
  if (
    betZoneInfo.dealerZone.score === 21 &&
    (betZoneInfo.dealerZone.suitCards || []).length === 2
  ) {
    createBetNotif('dealerZone', 'BLACKJACK');
  }

  const known = (betZoneInfo.dealerZone.suitCardsScore || []).length;
  const extra = dealerCards.slice(known);
  extra.forEach((code) => bjQueuePush('dealerZone', bjCodeToCard(code)));

  const drawNext = (remaining) => {
    if (remaining <= 0) {
      setTimeout(() => bjRenderServerResults(resp), 600);
      return;
    }
    const len = document.querySelectorAll('.card.cardEnd.dealerZone').length;
    dealCard('dealerZone', betZoneInfo.dealerZone.top, betZoneInfo.dealerZone.right - len, true);
    setTimeout(() => drawNext(remaining - 1), 650);
  };
  setTimeout(() => drawNext(extra.length), 600);
}

function bjRenderServerResults(resp) {
  const handResults = (resp.betDetails && resp.betDetails.hands) || [];
  const BANNER = {
    blackjack: 'BLACKJACK',
    win: 'WIN',
    push: 'PUSH',
    lose: 'LOSE',
    dealer_blackjack: 'LOSE',
    bust: 'BUST',
    surrender: 'SURRENDER',
    even_money: 'EVEN MONEY',
  };
  handResults.forEach((hand) => {
    const zone = hand.zone;
    if (!betZoneInfo[zone]) return;
    createBetNotif(zone, BANNER[hand.resultType] || String(hand.resultType || '').toUpperCase());
    let index, chipType;
    if (zone.startsWith('betZone')) {
      index = parseInt(zone.replace('betZone', ''), 10) - 1;
      chipType = 'main';
    } else {
      const num = parseInt(zone.replace('splitZone', ''), 10);
      index = Math.floor((num - 1) / 2);
      chipType = num % 2 === 1 ? 'main' : 'split';
    }
    setTimeout(() => {
      if (Number(hand.return) > 0) {
        if (Number(hand.return) > Number(hand.bet)) {
          normalizeZone(index, chipType, Number(hand.return));
        }
        sendChips(chipType, index, 'player');
      } else {
        sendChips(chipType, index, 'dealer');
      }
    }, 2500);
  });

  const sideResults = (resp.betDetails && resp.betDetails.sideBets) || [];
  const sideWon = sideResults.filter((s) => Number(s.return) > 0);
  if (sideWon.length) {
    const total = sideWon.reduce((a, s) => a + Number(s.return), 0);
    setTimeout(() => notification('SIDE BETS PAID: $' + total.toLocaleString('de-DE')), 1200);
  }

  setTimeout(() => bjFinishRound(resp), 3400);
}

function bjFinishRound(resp) {
  gameStart = false;
  dealerStatus = false;
  afterInsurance = false;
  splitActive = false;
  insuranceActive = false;
  pendingSettlement = null;
  serverRound = null;
  bjResetQueues();
  Object.keys(betZoneInfo).forEach((zone) => {
    if (zone !== 'dealerZone') {
      betZoneInfo[zone].status = false;
      betZoneInfo[zone].bet = 0;
    }
  });
  playerInfo.totalBet = 0;
  betStatusInfo[1].textContent = '$0';
  if (resp && resp.newBalance !== undefined) {
    setAuthoritativeBalance(resp.newBalance);
  } else {
    syncBalanceFromSite();
  }
  const net = Number((resp && resp.netResult) || 0);
  playerInfo.lastWin = net;
  betStatusInfo[2].textContent =
    (net < 0 ? '- ' : '') + '$' + Math.abs(net).toLocaleString('de-DE');
  hideStandardButtons();
  document.querySelectorAll('.scoreInfo').forEach((el) => {
    el.style.boxShadow = 'none';
  });
  updateUndoBtnState();
  showPostRoundButtons();
}

function duplicateChips(index, type) {
  const array = getZoneChips(index, type);
  if (!array.length) return;
  const betName = ['betZone1', 'betZone2', 'betZone3'][index];
  array.forEach((chip, i) => {
    const value = +chip.dataset.value;
    const newChip = document.createElement('div');
    newChip.classList.add('tableChip');
    newChip.dataset.value = value;
    newChip.style.backgroundImage = `url(src/images/chips/chip${value}.png)`;
    newChip.style.top = chip.style.top;
    newChip.style.right = chip.style.right;
    newChip.style.zIndex = 2000 + i;
    game.appendChild(newChip);
    array.push(newChip);
  });
  normalizeZone(index, type);
}

function clearTable() {
  setTimeout(() => playSound('removeCards'), 600);
  const allCards = document.querySelectorAll('.card.cardEnd');
  allCards.forEach((card, i) => {
    const zone = Object.keys(betZoneInfo).find((z) =>
      card.classList.contains(z)
    );
    if (!zone) return;
    const baseRight = betZoneInfo[zone].right;
    setTimeout(() => (card.style.right = baseRight + '%'), 50);
    card.classList.remove('flipped');
    if (card.classList && card.classList.contains('doubleTilt')) {
      card.classList.remove('doubleTilt');
      card.style.transform = 'perspective(12vh) rotateX(10deg) scale(1)';
    }
    card.style.filter = 'brightness(1)';
    setTimeout(() => {
      card.style.top = '1.8%';
      card.style.right = '67.8%';
      card.style.transform =
        'rotateX(36deg) rotateZ(-34deg) rotateY(3deg) scale(0.74) skew(-2deg, 6deg)';
      card.addEventListener('transitionend', () => card.remove(), {
        once: true,
      });
    }, 600 + i * 50);
  });
}

function getZoneChips(index, type = 'main') {
  if (type === 'pair') return zonePairsChips[index];
  if (type === 'plus') return zonePlus21Chips[index];
  if (type === 'royal') return zoneRoyalChips[index];
  if (type === 'super7') return zoneSuperSevenChips[index];
  if (type === 'split') return zoneSplitChips[index];
  if (type === 'insurance') return zoneInsuranceChips[index];
  return zoneChips[index];
}

function repositionChips(zoneChips, top) {
  zoneChips.forEach((chip, i) => {
    chip.style.top = top - i * 0.5 + '%';
  });
}

function createChip(value, index, type = 'main') {
  const zone = getZoneChips(index, type);
  const chip = document.createElement('div');
  chip.classList.add('tableChip');
  chip.dataset.value = value;
  chip.style.backgroundImage = `url(src/images/chips/chip${value}.png)`;
  const betName =
    index === 0 ? 'betZone1' : index === 1 ? 'betZone2' : 'betZone3';
  const [chipTop, chipRight] =
    type === 'pair'
      ? betZoneInfo[betName].pairChipPositions
      : type === 'plus'
      ? betZoneInfo[betName].plus21ChipPositions
      : type === 'royal'
      ? betZoneInfo[betName].royalChipPositions
      : type === 'super7'
      ? betZoneInfo[betName].superSevenChipPositions
      : betZoneInfo[betName].chipPositions;
  chip.style.top = chipTop + '%';
  chip.style.right = chipRight + '%';
  game.appendChild(chip);
  zone.push(chip);
  checkMerge(value, index, type);
  normalizeZone(index, type);
  zone.forEach((c) => (c.style.animation = 'none'));
  setTimeout(() => {
    const lastChip = zone[zone.length - 1];
    if (lastChip) lastChip.style.animation = '';
  }, 0);
}

function checkMerge(value, index, type = 'main') {
  const zone = getZoneChips(index, type);
  const rule = upgradeRules[value];
  if (!rule) return;
  const same = zone.filter((chip) => +chip.dataset.value === value);
  if (same.length >= rule.count) {
    same.slice(0, rule.count).forEach((chip) => {
      chip.remove();
      zone.splice(zone.indexOf(chip), 1);
    });
    setTimeout(() => {
      createChip(rule.next, index, type);
      const betName =
        index === 0 ? 'betZone1' : index === 1 ? 'betZone2' : 'betZone3';
      const [chipTop] =
        type === 'pair'
          ? betZoneInfo[betName].pairChipPositions
          : type === 'plus'
          ? betZoneInfo[betName].plus21ChipPositions
          : type === 'royal'
          ? betZoneInfo[betName].royalChipPositions
          : type === 'super7'
          ? betZoneInfo[betName].superSevenChipPositions
          : betZoneInfo[betName].chipPositions;
      repositionChips(zone, chipTop);
    }, 0);
  }
}

function normalizeZone(index, type = 'main', customTotal = null) {
  const zone = getZoneChips(index, type);
  let total =
    customTotal !== null
      ? customTotal
      : zone.reduce((sum, chip) => sum + Number(chip.dataset.value), 0);
  zone.forEach((chip) => chip.remove());
  zone.length = 0;
  const denoms = [1000, 100, 25, 10, 5, 1];
  const betName =
    index === 0 ? 'betZone1' : index === 1 ? 'betZone2' : 'betZone3';
  let [chipTop, chipRight] =
    type === 'pair'
      ? betZoneInfo[betName].pairChipPositions
      : type === 'plus'
      ? betZoneInfo[betName].plus21ChipPositions
      : type === 'royal'
      ? betZoneInfo[betName].royalChipPositions
      : type === 'super7'
      ? betZoneInfo[betName].superSevenChipPositions
      : type === 'insurance'
      ? betZoneInfo[betName].insuranceChipPositions
      : betZoneInfo[betName].chipPositions;
  if (type === 'split') chipRight -= 2;
  try {
    if (
      type === 'main' &&
      Array.isArray(zoneSplitChips) &&
      zoneSplitChips[index] &&
      zoneSplitChips[index].length > 0
    )
      chipRight += 2;
  } catch (e) {
    /* no-op */
  }
  for (const d of denoms) {
    const count = Math.floor(total / d);
    for (let i = 0; i < count; i++) {
      const chip = document.createElement('div');
      chip.classList.add('tableChip');
      chip.dataset.value = d;
      chip.style.backgroundImage = `url(src/images/chips/chip${d}.png)`;
      chip.style.top = chipTop + '%';
      chip.style.right = chipRight + '%';
      game.appendChild(chip);
      zone.push(chip);
    }
    total -= count * d;
  }
  repositionChips(zone, chipTop);
}

function splitChips(activeZone) {
  if (!activeZone) return;
  const index =
    activeZone === 'betZone1' ? 0 : activeZone === 'betZone2' ? 1 : 2;
  const originals = zoneChips[index];
  const splitArray = zoneSplitChips[index];
  if (!originals?.length) return;
  const betName =
    index === 0 ? 'betZone1' : index === 1 ? 'betZone2' : 'betZone3';
  const [chipTop, chipRight] = betZoneInfo[betName].chipPositions;
  const createDelayBase = originals.length * 90;
  originals.forEach((chip, i) => {
    const currentRight = parseFloat(chip.style.right) || chipRight;
    chip.style.transition = 'right 220ms ease, top 220ms ease';
    chip.style.zIndex = 1000 + i;
    setTimeout(() => {
      chip.style.right = currentRight + 2 + '%';
    }, i * 80);
    const value = +chip.dataset.value;
    setTimeout(() => {
      const newChip = document.createElement('div');
      newChip.classList.add('tableChip');
      newChip.dataset.value = value;
      newChip.style.backgroundImage = `url(src/images/chips/chip${value}.png)`;
      newChip.style.top = chipTop + '%';
      newChip.style.right = chipRight - 2 + '%';
      newChip.style.zIndex = 2000 + i;
      game.appendChild(newChip);
      splitArray.push(newChip);
      setTimeout(() => (newChip.style.animation = ''), 20);
      setTimeout(() => repositionChips(splitArray, chipTop), 160);
    }, createDelayBase + i * 120);
  });
  const totalWait = createDelayBase + originals.length * 120 + 200;
  setTimeout(() => {
    repositionChips(originals, chipTop);
    repositionChips(splitArray, chipTop);
  }, totalWait);
}

async function double() {
  if (settlementInFlight || !activeZone) return;
  const zone = activeZone;
  const resp = await bjSendAction('double', zone);
  if (!resp) return;
  bjQueueZoneDelta(resp, zone);
  doubleVisual(resp);
}

function doubleVisual(resp) {
  if (!activeZone) return;
  function resolveZone(zone) {
    const splitMap = {
      splitZone1: { array: zoneChips[0], betZone: 'betZone1', offset: +2 },
      splitZone2: { array: zoneSplitChips[0], betZone: 'betZone1', offset: -2 },
      splitZone3: { array: zoneChips[1], betZone: 'betZone2', offset: +2 },
      splitZone4: { array: zoneSplitChips[1], betZone: 'betZone2', offset: -2 },
      splitZone5: { array: zoneChips[2], betZone: 'betZone3', offset: +2 },
      splitZone6: { array: zoneSplitChips[2], betZone: 'betZone3', offset: -2 },
    };
    if (zone.startsWith('betZone')) {
      const idx = parseInt(zone.replace('betZone', ''), 10) - 1;
      return { array: zoneChips[idx], betZone: zone, offset: 0 };
    }
    return splitMap[zone] || null;
  }
  const zone = resolveZone(activeZone);
  if (!zone) return;
  const { array, betZone, offset } = zone;
  const beforeBet = money((betZoneInfo[activeZone] ?? betZoneInfo[betZone])?.bet || 0);
  logRoundAction('double', activeZone, { bet: beforeBet });
  rememberRoundHandMeta(activeZone, { doubled: true });
  array.forEach((chip, i) => {
    setTimeout(() => {
      chip.style.transition = 'transform 200ms ease, opacity 200ms ease';
      chip.style.transform = 'scale(0)';
      chip.style.opacity = '0';
      setTimeout(() => chip.remove(), 220);
    }, i * 50);
  });
  array.length = 0;
  const betTarget = betZoneInfo[activeZone] ?? betZoneInfo[betZone];
  playerInfo.balance -= betTarget.bet;
  playerInfo.totalBet += betTarget.bet;
  betTarget.bet *= 2;
  let total = betTarget.bet;
  const denoms = [1000, 100, 25, 10, 5, 1];
  const newChips = denoms.flatMap((d) => {
    const count = Math.floor(total / d);
    total -= count * d;
    return Array(count).fill(d);
  });
  let [chipTop, chipRight] = betZoneInfo[betZone].chipPositions;
  chipRight += offset;
  newChips.forEach((value, i) => {
    setTimeout(() => {
      const chip = document.createElement('div');
      chip.classList.add('tableChip');
      chip.dataset.value = value;
      chip.style.backgroundImage = `url(src/images/chips/chip${value}.png)`;
      chip.style.top = chipTop + '%';
      chip.style.right = chipRight + '%';
      chip.style.transform = 'scale(0)';
      chip.style.opacity = '0';
      chip.style.zIndex = 3000 + i;
      game.appendChild(chip);
      array.push(chip);
      playSound('chipPut');
      setTimeout(() => {
        chip.style.transition = 'transform 220ms ease, opacity 220ms ease';
        chip.style.transform = 'scale(1)';
        chip.style.opacity = '1';
      }, 20);
      setTimeout(() => repositionChips(array, chipTop), 160);
    }, i * 120);
  });
  if (betTarget.scoreZone) {
    betTarget.scoreZone.textContent =
      '$' + betTarget.bet.toLocaleString('de-DE');
    betStatusInfo[1].textContent =
      '$' + playerInfo.totalBet.toLocaleString('de-DE');
    betStatusInfo[0].textContent =
      '$' + playerInfo.balance.toLocaleString('de-DE');
  }
  if (activeZone) {
    const { top, right } = betZoneInfo[activeZone];
    const existingCards = document.querySelectorAll(
      `.card.cardEnd.${activeZone}`
    );
    dealCard(activeZone, top, right - existingCards.length, true, true);
    const zoneForNotif = activeZone;
    setTimeout(() => {
      const total = betZoneInfo[zoneForNotif].score;
      if (total === 21) {
        createBetNotif(zoneForNotif, '21');
      } else if (total > 21) {
        createBetNotif(zoneForNotif, 'BUST');
      }
    }, 700);
    setTimeout(() => {
      bjApplyActionResponse(resp);
    }, 900);
  }
}

function createChipWithFlight(value, index, type = 'main') {
  canBet = false;
  const zone = getZoneChips(index, type),
    isFirst = zone.length === 0;
  const betName = ['betZone1', 'betZone2', 'betZone3'][index];
  const key =
    {
      pair: 'pairChipPositions',
      plus: 'plus21ChipPositions',
      royal: 'royalChipPositions',
      super7: 'superSevenChipPositions',
    }[type] || 'chipPositions';
  const [baseTop, baseRight] = betZoneInfo[betName][key];
  const chipTop = baseTop - zone.length * 1,
    chipRight = baseRight;
  const start = chipSelectPositions[chipValues.indexOf(value)] || {
    top: 67,
    right: 0,
  };
  const chip = document.createElement('div');
  chip.classList.add('tableChip');
  chip.dataset.value = value;
  const css = (el, o) => Object.assign(el.style, o),
    T =
      'top 300ms ease, right 300ms ease, transform 300ms ease, opacity 300ms ease';
  css(chip, {
    backgroundImage: `url(src/images/chips/chip${value}.png)`,
    top: start.top + '%',
    right: start.right + '%',
    transition: T,
    willChange: 'top, right, transform',
    zIndex: 4000,
  });
  game.appendChild(chip);
  chip.getBoundingClientRect();
  requestAnimationFrame(() => {
    css(chip, { top: chipTop + '%', right: chipRight + '%' });
    const ch = chips[chipIndex];
    css(ch, {
      transition: T + ', width 300ms ease, height 300ms ease',
      right: chipRight + '%',
      top: chipTop + '%',
      width: '4vh',
      height: '3.48vh',
      pointerEvents: 'none',
    });
  });
  let finished = false;
  const finishFlight = () => {
    if (finished) return;
    finished = true;
    const ch = chips[chipIndex];
    css(ch, {
      transition: 'transform 0.1s ease-in-out',
      right: start.right + '%',
      top: start.top + '%',
      width: '7vh',
      height: '6.1vh',
      pointerEvents: 'all',
    });
    zone.push(chip);
    checkMerge(value, index, type);
    normalizeZone(index, type);
    playSound(isFirst ? 'firstChip' : 'chipPut');
    const z = getZoneChips(index, type);
    z.forEach((c) => (c.style.animation = 'none'));
    setTimeout(() => {
      const last = z[z.length - 1];
      if (last) last.style.animation = '';
    }, 0);
    setTimeout(() => {
      canBet = true;
    }, 100);
  };
  const onEnd = (e) => {
    if (e.propertyName === 'top' || e.propertyName === 'right') {
      chip.removeEventListener('transitionend', onEnd);
      finishFlight();
    }
  };
  chip.addEventListener('transitionend', onEnd);
  setTimeout(() => {
    finishFlight();
    checkChipAvailable();
  }, 400);
}

function checkBets() {
  // Side bets settle SERVER-side with the round (C1b-C1d); their outcomes
  // render at settlement from betDetails. The legacy deal-time client
  // evaluation is gone.
}

function queueChipSendSound(n) {
  __chipSendBatchCount += n;
  if (__chipSendSoundTimer) return;
  __chipSendSoundTimer = setTimeout(() => {
    playSound(__chipSendBatchCount > 1 ? 'lotChips' : 'chipPut');
    __chipSendBatchCount = 0;
    __chipSendSoundTimer = null;
  }, 80);
}

function sendChips(type, index, direction) {
  const map = {
    main: zoneChips,
    insurance: zoneInsuranceChips,
    pairs: zonePairsChips,
    split: zoneSplitChips,
    plus21: zonePlus21Chips,
    royal: zoneRoyalChips,
    super7: zoneSuperSevenChips,
    surrender: zoneSurrenderChips,
  };
  const chipsArray = map[type]?.[index];
  if (!chipsArray || !chipsArray.length) return;
  queueChipSendSound(chipsArray.length);
  const dealer = direction === 'dealer',
    targetTop = dealer ? 0 : 92,
    targetRight = dealer ? 48 : 23.8;

  chipsArray.forEach((chip, i) => {
    chip.style.transition =
      'top 500ms ease, right 500ms ease, opacity 1000ms ease';
    chip.style.zIndex = 5000 + i;
    const delay = (chipsArray.length - 1 - i) * 100;
    setTimeout(() => {
      chip.style.top = targetTop + '%';
      chip.style.right = targetRight + '%';
      chip.style.opacity = '0';
    }, delay);
    const onEnd = (e) => {
      if (e.propertyName === 'opacity') {
        chip.remove();
        chip.removeEventListener('transitionend', onEnd);
      }
    };
    chip.addEventListener('transitionend', onEnd);
    setTimeout(() => {
      if (chip.parentNode) chip.remove();
    }, delay + 600);
  });
  chipsArray.length = 0;
}

async function surrender() {
  if (settlementInFlight || !activeZone) return;
  const resp = await bjSendAction('surrender', activeZone);
  if (!resp) return;
  surrenderVisual();
  bjApplyActionResponse(resp);
}

function surrenderVisual() {
  if (!activeZone) return;
  const bet = betZoneInfo[activeZone].bet,
    surrenderAmount = money(bet / 2);
  logRoundAction('surrender', activeZone, { bet: money(bet) });
  rememberRoundHandMeta(activeZone, {
    surrendered: true,
    originalBet: money(bet),
    cards: cardsToPayload(betZoneInfo[activeZone]?.suitCardsScore || []),
    isSplit: activeZone.startsWith('splitZone'),
  });
  let index, betName;
  if (
    activeZone === 'betZone1' ||
    activeZone === 'splitZone1' ||
    activeZone === 'splitZone2'
  ) {
    index = 0;
    betName = 'betZone1';
  } else if (
    activeZone === 'betZone2' ||
    activeZone === 'splitZone3' ||
    activeZone === 'splitZone4'
  ) {
    index = 1;
    betName = 'betZone2';
  } else if (
    activeZone === 'betZone3' ||
    activeZone === 'splitZone5' ||
    activeZone === 'splitZone6'
  ) {
    index = 2;
    betName = 'betZone3';
  } else return;

  const isSplit = activeZone.startsWith('splitZone');
  let isFirst = true;
  if (isSplit) {
    const num = parseInt(activeZone.replace('splitZone', ''));
    isFirst = num % 2 === 1;
  }

  const originals = isSplit
    ? isFirst
      ? zoneChips[index]
      : zoneSplitChips[index]
    : zoneChips[index];
  const surrenderIndexPlayer = index * 2 + (isFirst ? 0 : 1),
    surrenderIndexDealer = index * 2 + (isFirst ? 1 : 0);
  const surrenderArrayPlayer = zoneSurrenderChips[surrenderIndexPlayer],
    surrenderArrayDealer = zoneSurrenderChips[surrenderIndexDealer];
  const [chipTop, chipRight] = betZoneInfo[betName].chipPositions;

  originals.forEach((chip, i) => {
    setTimeout(() => {
      chip.style.transition = 'transform 200ms ease, opacity 200ms ease';
      chip.style.transform = 'scale(0)';
      chip.style.opacity = '0';
      setTimeout(() => chip.remove(), 220);
    }, i * 50);
  });
  originals.length = 0;

  let total = surrenderAmount;
  const denoms = [1000, 100, 25, 10, 5, 1],
    newValues = [];
  for (const d of denoms) {
    const count = Math.floor(total / d);
    for (let i = 0; i < count; i++) newValues.push(d);
    total -= count * d;
  }

  const left =
    activeZone === 'splitZone1' ||
    activeZone === 'splitZone3' ||
    activeZone === 'splitZone5';
  const right =
    activeZone === 'splitZone2' ||
    activeZone === 'splitZone4' ||
    activeZone === 'splitZone6';

  newValues.forEach((value, i) => {
    setTimeout(() => {
      const c = document.createElement('div');
      c.classList.add('tableChip');
      c.dataset.value = value;
      c.style.backgroundImage = `url(src/images/chips/chip${value}.png)`;
      c.style.top = chipTop + '%';
      c.style.right =
        (left ? chipRight + 4 : right ? chipRight - 4 : chipRight + 2) + '%';
      c.style.zIndex = 1000 + i;
      game.appendChild(c);
      surrenderArrayDealer.push(c);
      setTimeout(() => repositionChips(surrenderArrayDealer, chipTop), 160);
    }, i * 50);
  });
  newValues.forEach((value, i) => {
    setTimeout(() => {
      const c = document.createElement('div');
      c.classList.add('tableChip');
      c.dataset.value = value;
      c.style.backgroundImage = `url(src/images/chips/chip${value}.png)`;
      c.style.top = chipTop + '%';
      c.style.right =
        (left ? chipRight + 1.5 : right ? chipRight - 1.5 : chipRight - 2) +
        '%';
      c.style.zIndex = 2000 + i;
      game.appendChild(c);
      surrenderArrayPlayer.push(c);
      setTimeout(() => {
        repositionChips(surrenderArrayPlayer, chipTop);
        c.style.animation = '';
      }, 20);
    }, i * 50);
  });

  const totalWait = newValues.length * 50 + 300;
  setTimeout(() => {
    sendChips(
      'surrender',
      surrenderIndexDealer,
      'dealer',
      surrenderArrayDealer
    );
    sendChips(
      'surrender',
      surrenderIndexPlayer,
      'player',
      surrenderArrayPlayer
    );
    surrenderArrayDealer.length = 0;
    surrenderArrayPlayer.length = 0;
    createBetNotif(activeZone, 'Surrender');
    stand();
  }, totalWait);
  playerInfo.balance += surrenderAmount;
  betStatusInfo[0].textContent =
    '$' + playerInfo.balance.toLocaleString('de-DE');

  betZoneInfo[activeZone].bet = 0;
  if (betZoneInfo[activeZone].scoreZone)
    betZoneInfo[activeZone].scoreZone.textContent = '$0';
  betZoneInfo[activeZone].status = false;
}

async function insurance() {
  if (settlementInFlight || !activeZone) return;
  const betTarget = betZoneInfo[activeZone];
  const stake = Math.floor(money(betTarget.bet || 0) / 2);
  if (stake < 1) {
    notification('CANT INSURANCE 1$');
    return;
  }
  const zone = activeZone;
  const resp = await bjSendAction('insurance', zone, { insuranceStake: stake });
  if (!resp) return;
  insuranceVisual(zone, stake);
  bjApplyActionResponse(resp);
}

function insuranceVisual(betName, insuranceAmount) {
  const index = ['betZone1', 'betZone2', 'betZone3'].indexOf(betName);
  if (index === -1) return;
  const betTarget = betZoneInfo[betName];
  betTarget.insuranceBet += insuranceAmount;

  let total = insuranceAmount;
  const denoms = [1000, 100, 25, 10, 5, 1],
    newValues = [];
  for (const d of denoms) {
    const count = Math.floor(total / d);
    for (let i = 0; i < count; i++) newValues.push(d);
    total -= count * d;
  }

  const [chipTop, chipRight] = betZoneInfo[betName].insuranceChipPositions;
  newValues.forEach((value, i) => {
    setTimeout(() => {
      const c = document.createElement('div');
      c.classList.add('tableChip');
      c.dataset.value = value;
      c.style.backgroundImage = `url(src/images/chips/chip${value}.png)`;
      c.style.top = chipTop + '%';
      c.style.right = chipRight + '%';
      c.style.zIndex = 2000 + i;
      game.appendChild(c);
      zoneInsuranceChips[index].push(c);
      setTimeout(
        () => repositionChips(zoneInsuranceChips[index], chipTop),
        160
      );
    }, i * 50);
  });
}

function notification(notifText) {
  notifWindow.textContent = notifText;
  notifWindow.style.transition = 'none';
  notifWindow.style.transform = 'translate(-50%, -100%)';
  void notifWindow.offsetHeight;
  notifWindow.style.transition = '';
  notifWindow.style.transform = 'translate(-50%, 0%)';
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    notifWindow.style.transform = 'translate(-50%, -100%)';
  }, 3000);
}

function checkButtons() {
  if (dealerStatus) return;
  if (!betZoneInfo.dealerZone.suitCardsScore[0] || !activeZone) return;
  if (aceSplitInProgress) {
    hitBtn.style.display = 'none';
    standBtn.style.display = 'none';
    splitBtn.style.display = 'none';
    doubleBtn.style.display = 'none';
    surrenderBtn.style.display = 'none';
    insuranceBtn.style.display = 'none';
    noInsuranceBtn.style.display = 'none';
    evenMoneyBtn.style.display = 'none';
    declineEvenMoneyBtn.style.display = 'none';
    return;
  }
  if (betZoneInfo.dealerZone.suitCardsScore[0][1] === 'A' && !afterInsurance) {
    const playerZone = betZoneInfo[activeZone];
    const isNaturalHand = String(activeZone).startsWith('betZone');
    const playerBlackjack =
      isNaturalHand &&
      playerZone.score === 21 &&
      playerZone.suitCards.length === 2;

    if (playerBlackjack) {
      evenMoneyBtn.style.display = 'flex';
      declineEvenMoneyBtn.style.display = 'flex';
    } else {
      insuranceActive = true;
      insuranceBtn.style.display = 'flex';
      noInsuranceBtn.style.display = 'flex';
    }
    splitBtn.style.display = 'none';
    doubleBtn.style.display = 'none';
    surrenderBtn.style.display = 'none';
    hitBtn.style.display = 'none';
    standBtn.style.display = 'none';
    return;
  } else {
    insuranceBtn.style.display = 'none';
    noInsuranceBtn.style.display = 'none';
    evenMoneyBtn.style.display = 'none';
    declineEvenMoneyBtn.style.display = 'none';
  }
  hitBtn.style.display = 'flex';
  standBtn.style.display = 'flex';
  surrenderBtn.style.display = 'flex';
  doubleBtn.style.display = 'flex';
  splitBtn.style.display = 'none';
  splitBtn.classList.remove('inactiveBtn');
  if (betZoneInfo[activeZone].suitCards.length > 2) {
    splitBtn.classList.add('inactiveBtn');
    doubleBtn.classList.add('inactiveBtn');
    surrenderBtn.classList.add('inactiveBtn');
  }
  if (betZoneInfo[activeZone].score == 21) {
    const isSplitHand = String(activeZone).startsWith('splitZone');
    const isTwoCard = betZoneInfo[activeZone].suitCards.length === 2;
    if (!isTwoCard || isSplitHand) {
      createBetNotif(activeZone, '21');
    }
    stand();
    return;
  }
  if (betZoneInfo[activeZone].score > 21) {
    createBetNotif(activeZone, 'BUST');
    stand();
    return;
  }
  const isBaseZone = String(activeZone).startsWith('betZone');
  if (isBaseZone && betZoneInfo[activeZone].suitCards.length === 2) {
    const [c1, c2] = betZoneInfo[activeZone].suitCards;
    const canAfford = playerInfo.balance >= (betZoneInfo[activeZone].bet || 0);
    if (c1 === c2 && canAfford) {
      splitBtn.style.display = 'flex';
      splitBtn.classList.remove('inactiveBtn');
    }
  }
}

async function evenMoney() {
  if (settlementInFlight || !activeZone) return;
  const zone = activeZone;
  const resp = await bjSendAction('even_money', zone);
  if (!resp) return;
  evenMoneyBtn.style.display = 'none';
  declineEvenMoneyBtn.style.display = 'none';
  createBetNotif(zone, 'EVEN MONEY');
  bjApplyActionResponse(resp);
}

function createBetNotif(zone, text) {
  let n = document.querySelector(`.betNotif[data-zone="${zone}"]`);
  const pos = betZoneInfo[zone] || {},
    top = (pos.top !== undefined ? pos.top : 0) + 3,
    right = (pos.right !== undefined ? pos.right : 0) - 2.2;
  if (!n) {
    n = document.createElement('div');
    n.classList.add('betNotif');
    n.dataset.zone = zone;
    game.appendChild(n);
  }
  n.style.top = top + '%';
  n.style.right = right + '%';
  n.textContent = text;
  const up = String(text || '').toUpperCase(),
    isP = zone !== 'dealerZone';
  if (isP && up === 'BLACKJACK') {
    n.style.color = 'gold';
    n.style.textShadow = '0 0 0.5vh rgba(0,0,0,0.6)';
  } else if (isP && (up === 'BUST' || up === 'LOSE')) {
    n.style.boxShadow = 'red 0vh 0vh 1vh 0vh inset';
  } else if (isP && up === 'WIN') {
    n.style.boxShadow = 'green 0vh 0vh 1vh 0vh inset';
  } else {
    n.style.color = '';
    n.style.webkitTextStroke = '';
    n.style.textShadow = '';
  }
  const s =
    betZoneInfo[zone] && betZoneInfo[zone].scoreZone
      ? betZoneInfo[zone].scoreZone
      : null;
  if (s) {
    if (up === 'BLACKJACK' || up === 'WIN')
      s.style.boxShadow = 'green 0vh 0vh 1vh 0vh inset';
    else if (up === 'LOSE' || up === 'BUST')
      s.style.boxShadow = 'red 0vh 0vh 1vh 0vh inset';
    else if (up === 'PUSH' || up === 'SURRENDER' || up === '21')
      s.style.boxShadow = 'none';
  }
}

function replaceZoneChips(zoneId, newTotal, typeHint = null) {
  const make = (idx, t, splitN = null) => ({
    index: idx,
    type: t || 'main',
    betZoneName: `betZone${idx + 1}`,
    splitZoneName: splitN,
  });
  function resolve(id, t) {
    if (typeof id === 'number') return make(id, t, null);
    if (typeof id === 'string') {
      let m = id.match(/^betZone([1-3])$/);
      if (m) return make(Number(m[1]) - 1, t, null);
      m = id.match(/^splitZone([1-6])$/);
      if (m) {
        const n = Number(m[1]),
          idx = Math.ceil(n / 2) - 1,
          inf = n % 2 === 0 ? 'split' : 'main';
        return make(idx, t || inf, `splitZone${n}`);
      }
      if (/^[0-2]$/.test(id)) return make(Number(id), t, null);
    }
    return null;
  }
  const r = resolve(zoneId, typeHint);
  if (!r) {
    return;
  }
  const { index, type: chipType, betZoneName, splitZoneName } = r;
  const zoneArray = getZoneChips(index, chipType);
  if (!Array.isArray(zoneArray)) {
    return;
  }
  zoneArray.forEach((c) => {
    try {
      c.remove();
    } catch (e) {}
  });
  zoneArray.length = 0;
  const fieldMap = {
    main: 'bet',
    split: 'bet',
    pair: 'pairsBet',
    plus: 'plus21Bet',
    royal: 'royalBet',
    super7: 'superSevenBet',
    insurance: 'insuranceBet',
  };
  const field = fieldMap[chipType] || 'bet';
  if (betZoneInfo[betZoneName]) betZoneInfo[betZoneName][field] = newTotal;
  if (splitZoneName && betZoneInfo[splitZoneName])
    betZoneInfo[splitZoneName].bet = newTotal;
  let total = Math.max(0, Math.floor(Number(newTotal) || 0)),
    denoms = [1000, 100, 25, 10, 5, 1],
    pieces = [];
  for (const d of denoms) {
    const cnt = Math.floor(total / d);
    for (let i = 0; i < cnt; i++) pieces.push(d);
    total -= cnt * d;
  }
  pieces.forEach((v) => createChip(v, index, chipType));
  if (betZoneInfo[betZoneName] && betZoneInfo[betZoneName].scoreZone) {
    try {
      betZoneInfo[betZoneName].scoreZone.textContent =
        '$' + (betZoneInfo[betZoneName][field] || 0).toLocaleString('de-DE');
      betZoneInfo[betZoneName].scoreZone.style.opacity = 1;
    } catch (e) {}
  }
  if (typeof betStatusInfo !== 'undefined' && betStatusInfo.length >= 2) {
    betStatusInfo[1].textContent =
      '$' + (playerInfo.totalBet || 0).toLocaleString('de-DE');
    betStatusInfo[0].textContent =
      '$' + (playerInfo.balance || 0).toLocaleString('de-DE');
  }
}

function undoLastBet() {
  if (settlementInFlight) return;
  if (!betHistory.length) {
    updateUndoBtnState();
    return;
  }
  const { betName, type, value } = betHistory.pop(),
    map = {
      main: { prop: 'bet', sel: '.mainInfo' },
      pair: { prop: 'pairsBet', sel: '.pairInfo' },
      plus: { prop: 'plus21Bet', sel: '.plus21Info' },
      royal: { prop: 'royalBet', sel: '.royalInfo' },
      super7: { prop: 'superSevenBet', sel: '.superSevenInfo' },
      insurance: { prop: 'insuranceBet', sel: '.insuranceInfo' },
    }[type] || { prop: 'bet', sel: '.mainInfo' },
    idx = betName === 'betZone1' ? 0 : betName === 'betZone2' ? 1 : 2,
    current = betZoneInfo[betName][map.prop] || 0;
  let newTotal = current - value;
  if (newTotal < 0) newTotal = 0;
  betZoneInfo[betName][map.prop] = newTotal;
  if (map.prop === 'bet' && newTotal === 0) betZoneInfo[betName].status = false;
  if (typeof normalizeZone === 'function') normalizeZone(idx, type, newTotal);
  else if (typeof replaceZoneChips === 'function')
    replaceZoneChips(betName, newTotal, type);
  const el = document.querySelectorAll(map.sel)[idx];
  if (el) {
    if (newTotal > 0) {
      el.textContent = '$' + newTotal.toLocaleString('de-DE');
      el.style.opacity = 1;
    } else {
      el.textContent = '';
      el.style.opacity = 0;
    }
  }
  playSound('undoChip');
  playerInfo.balance += value;
  playerInfo.totalBet = Math.max(0, (playerInfo.totalBet || 0) - value);
  betStatusInfo[0].textContent =
    '$' + (playerInfo.balance || 0).toLocaleString('de-DE');
  betStatusInfo[1].textContent =
    '$' + (playerInfo.totalBet || 0).toLocaleString('de-DE');
  checkChipAvailable();
  const sumMain = BASE_ZONES.reduce(
    (acc, z) => acc + (betZoneInfo[z].bet || 0),
    0
  );
  if (sumMain <= 0 && dealBtn) dealBtn.classList.add('inactiveBtn');
  if (playerInfo.totalBet <= 0 && clearAllBtn)
    clearAllBtn.classList.add('inactiveBtn');
  updateUndoBtnState();
}

function snapshotRebet() {
  const Z = ['betZone1', 'betZone2', 'betZone3'];
  const hasAny = Z.some((z) => {
    const b = betZoneInfo[z] || {};
    return (
      (b.bet || 0) +
        (b.pairsBet || 0) +
        (b.plus21Bet || 0) +
        (b.royalBet || 0) +
        (b.superSevenBet || 0) >
      0
    );
  });
  if (!hasAny) {
    rebetSnapshot = null;
    return;
  }

  const denomsFrom = (arr) =>
    (arr || []).map((c) => Number(c.dataset?.value || 0)).filter(Boolean);
  const totals = Z.reduce((a, z) => {
    const b = betZoneInfo[z] || {};
    a[z] = {
      bet: b.bet || 0,
      pairsBet: b.pairsBet || 0,
      plus21Bet: b.plus21Bet || 0,
      royalBet: b.royalBet || 0,
      superSevenBet: b.superSevenBet || 0,
    };
    return a;
  }, {});
  const pick = (a) => [0, 1, 2].map((i) => denomsFrom(a[i]));
  const denoms = {
    main: pick(zoneChips),
    pair: pick(zonePairsChips),
    plus: pick(zonePlus21Chips),
    royal: pick(zoneRoyalChips),
    super7: pick(zoneSuperSevenChips),
  };
  const required =
    Object.values(totals).reduce(
      (s, t) =>
        s + t.bet + t.pairsBet + t.plus21Bet + t.royalBet + t.superSevenBet,
      0
    ) || 0;

  rebetSnapshot = {
    balanceAtDeal: playerInfo.balance,
    totals,
    denoms,
    required,
    ts: Date.now(),
  };
}

function rebet() {
  if (settlementInFlight) return;
  if (typeof gameStart !== 'undefined' && gameStart) {
    notification('FINISH THE ROUND FIRST');
    return;
  }
  if (!rebetSnapshot || rebetSnapshot.required <= 0) {
    notification('NO PREVIOUS BETS');
    return;
  }
  const need =
    REBET_CHECK_BY === 'balanceAtDeal'
      ? rebetSnapshot.balanceAtDeal
      : rebetSnapshot.required;
  if (playerInfo.balance < need) {
    notification('NOT ENOUGH MONEY');
    return;
  }

  // --- NEW: посчитаем, сколько фишек будет добавлено ---
  const countChipsToAdd = () => {
    const TYPES_TO_ADD = ['main', 'pair', 'plus', 'royal', 'super7'];
    let total = 0;
    for (let i = 0; i < 3; i++) {
      for (const t of TYPES_TO_ADD) {
        const ds = rebetSnapshot?.denoms?.[t]?.[i] || [];
        total += ds.length;
      }
    }
    return total;
  };
  const chipsWillBeAdded = countChipsToAdd();
  // ------------------------------------------------------

  const Z = ['betZone1', 'betZone2', 'betZone3'],
    TYPES = ['main', 'pair', 'plus', 'royal', 'super7', 'insurance', 'split'];

  const currentTotal = Z.reduce((acc, z) => {
    const b = betZoneInfo[z] || {};
    return (
      acc +
      (b.bet || 0) +
      (b.pairsBet || 0) +
      (b.plus21Bet || 0) +
      (b.royalBet || 0) +
      (b.superSevenBet || 0)
    );
  }, 0);

  if (currentTotal > 0) {
    playerInfo.balance += currentTotal;
    playerInfo.totalBet = Math.max(
      0,
      (playerInfo.totalBet || 0) - currentTotal
    );
  }

  for (let i = 0; i < 3; i++) {
    TYPES.forEach((t) => {
      try {
        normalizeZone(i, t, 0);
      } catch (_) {}
    });
  }

  Z.forEach((z) => {
    if (!betZoneInfo[z]) return;
    Object.assign(betZoneInfo[z], {
      bet: 0,
      pairsBet: 0,
      plus21Bet: 0,
      royalBet: 0,
      superSevenBet: 0,
      status: false,
    });
  });

  const setUIValue = (sel, idx, val) => {
    const els = document.querySelectorAll(sel);
    if (els && els[idx]) {
      els[idx].textContent = '$' + val.toLocaleString('de-DE');
      els[idx].style.opacity = val > 0 ? 1 : 0;
    }
  };

  const typeMap = {
    main: { prop: 'bet', ui: '.mainInfo' },
    pair: { prop: 'pairsBet', ui: '.pairInfo' },
    plus: { prop: 'plus21Bet', ui: '.plus21Info' },
    royal: { prop: 'royalBet', ui: '.royalInfo' },
    super7: { prop: 'superSevenBet', ui: '.superSevenInfo' },
  };

  Z.forEach((z, i) => {
    const t = rebetSnapshot.totals[z];
    if (!t) return;
    Object.entries(typeMap).forEach(([type, cfg]) => {
      const total = t[cfg.prop] || 0;
      if (total > 0) {
        betZoneInfo[z][cfg.prop] = total;
        if (type === 'main') betZoneInfo[z].status = true;
        const ds = rebetSnapshot.denoms[type]?.[i] || [];
        ds.forEach((v) => createChip(v, i, type));
        setUIValue(cfg.ui, i, total);
        ds.forEach((v) =>
          betHistory.push({ betName: z, type, value: v, timestamp: Date.now() })
        );
      } else {
        setUIValue(cfg.ui, i, 0);
      }
    });
  });

  const toCharge = rebetSnapshot.required;
  if (lastBalance === null) lastBalance = playerInfo.balance;
  playerInfo.balance -= toCharge;
  playerInfo.totalBet += toCharge;

  if (betStatusInfo && betStatusInfo.length >= 2) {
    betStatusInfo[0].textContent =
      '$' + playerInfo.balance.toLocaleString('de-DE');
    betStatusInfo[1].textContent =
      '$' + playerInfo.totalBet.toLocaleString('de-DE');
  }
  if (dealBtn) dealBtn.classList.remove('inactiveBtn');
  if (clearAllBtn) clearAllBtn.classList.remove('inactiveBtn');

  // --- NEW: звук в зависимости от количества добавленных фишек ---
  if (chipsWillBeAdded === 1) {
    playSound('chipPut');
  } else if (chipsWillBeAdded > 1) {
    playSound('addChips');
  }
  // ---------------------------------------------------------------
}

function resetForNewRoundUI() {
  clearTable();
  bjResetQueues();
  Object.keys(betZoneInfo).forEach((z) => {
    if (z === 'dealerZone') return;
    const bz = betZoneInfo[z];
    Object.assign(bz, {
      score: 0,
      suitCards: [],
      suitCardsScore: [],
      status: false,
      bet: 0,
      insuranceBet: 0,
      pairsBet: 0,
      plus21Bet: 0,
      royalBet: 0,
      superSevenBet: 0,
    });
    if (bz.cardScore) {
      const cs = bz.cardScore;
      cs.textContent = '';
      cs.style.opacity = 0;
      cs.style.animation = 'none';
      cs.style.left = '';
    }
    if (bz.scoreZone) {
      const sz = bz.scoreZone;
      sz.textContent = '';
      sz.style.opacity = 0;
      sz.style.left = '';
    }
  });
  const dz = betZoneInfo.dealerZone;
  dz.score = 0;
  dz.suitCards = [];
  dz.suitCardsScore = [];
  if (dz.cardScore) {
    dz.cardScore.textContent = '';
    dz.cardScore.style.opacity = 0;
  }

  [
    zoneChips,
    zonePairsChips,
    zoneSplitChips,
    zonePlus21Chips,
    zoneRoyalChips,
    zoneSuperSevenChips,
    zoneInsuranceChips,
    zoneSurrenderChips,
  ].forEach((g) =>
    g.forEach((a) => {
      a.forEach((c) => c && c.remove && c.remove());
      a.length = 0;
    })
  );

  document
    .querySelectorAll('.pairInfo, .plus21Info, .royalInfo, .superSevenInfo')
    .forEach((el) => {
      el.textContent = '';
      el.style.boxShadow = 'none';
      el.style.opacity = 0;
    });
  document.querySelectorAll('.betNotif').forEach((el) => el.remove());

  showStandardButtons();
  dealBtn.classList.add('inactiveBtn');
  clearAllBtn.classList.add('inactiveBtn');
  undoBtn.classList.add('inactiveBtn');
}

function enableZonesAndRefreshChips() {
  tableZones.forEach((el) => {
    el.style.pointerEvents = 'all';
  });
  chips.forEach((el) => {
    el.style.pointerEvents = 'all';
  });
  checkChipAvailable();
}

if (sfxSlider) {
  sfxVolume = Math.max(0, Math.min(1, Number(sfxSlider.value) || 0.5));
  sfxSlider.addEventListener('input', () => {
    sfxVolume = Math.max(0, Math.min(1, Number(sfxSlider.value) || 0));
  });
}
//
function playSound(soundName) {
  const audio = new Audio(`src/sfx/effects/${soundName}.mp3`);
  audio.volume = sfxVolume; // <-- ключевая строка
  audio.currentTime = 0;
  audio.play();
}

function updateTimer() {
  let duration = music.duration;
  let remainingTime = duration - music.currentTime;
  let minutes = Math.floor(remainingTime / 60);
  let seconds = Math.floor(remainingTime % 60);
  minutes = isNaN(minutes) ? '00' : minutes < 10 ? '0' + minutes : minutes;
  seconds = isNaN(seconds) ? '00' : seconds < 10 ? '0' + seconds : seconds;
  document.querySelector('#nowPlaying').textContent = songName[musicNumber];
  document.querySelector('#musicTimer').textContent = minutes + ':' + seconds;
  if (minutes == 0 && seconds == 1) musicChange('next');
}
music.addEventListener('timeupdate', updateTimer);

if (musicVol) {
  music.volume = musicVol.value;
  musicVol.addEventListener('input', () => (music.volume = musicVol.value));
}
musicPauseBtn.onmouseover = () =>
  (musicPauseBtn.style.color = musicStatusColor);
musicPauseBtn.onmouseleave = () => (musicPauseBtn.style.color = 'black');

function musicPause() {
  const isPlaying = musicStatus;
  musicStatus = !isPlaying;
  musicStatus ? music.play() : music.pause();
  document.querySelector('#vinyl').style.animationPlayState = musicStatus
    ? 'running'
    : 'paused';
  musicPauseBtn.className = musicStatus
    ? 'fa-solid fa-pause'
    : 'fa-solid fa-play';
  musicPauseBtn.style.fontSize = musicStatus ? '2vh' : '1.8vh';
  musicPauseBtn.style.color = musicStatus ? 'red' : '#08ff21';
  musicStatusColor = musicPauseBtn.style.color;
}

function musicChange(prevNext) {
  const updateMusic = (num) => {
    music.pause();
    music = new Audio(`src/sfx/music/music${num}.mp3`);
    if (musicVol) music.volume = musicVol.value;
    music.currentTime = 0;
    music.addEventListener('timeupdate', updateTimer);
    setTimeout(() => music.play(), 1000);
  };
  document.querySelector('#musicPause').className = 'fa-solid fa-pause';
  document.querySelector('#vinyl').style.animationPlayState = 'running';
  document.querySelector('#musicPause').style.fontSize = '2vh';
  musicStatusColor = 'red';
  musicStatus = true;
  musicNumber += prevNext === 'prev' ? -1 : 1;
  musicNumber = (musicNumber + 8) % 8;
  updateMusic(musicNumber);
}

dealBtn.addEventListener('click', deal);
clearAllBtn.addEventListener('click', clearBets);
hitBtn.addEventListener('click', hit);
standBtn.addEventListener('click', stand);
splitBtn.addEventListener('click', split);
doubleBtn.addEventListener('click', double);
surrenderBtn.addEventListener('click', surrender);
insuranceBtn.addEventListener('click', insurance);
noInsuranceBtn.addEventListener('click', async () => {
  if (settlementInFlight || !activeZone) return;
  const resp = await bjSendAction('decline_insurance', activeZone);
  if (!resp) return;
  insuranceBtn.style.display = 'none';
  noInsuranceBtn.style.display = 'none';
  bjApplyActionResponse(resp);
});
evenMoneyBtn.addEventListener('click', evenMoney);
undoBtn.addEventListener('click', undoLastBet);
pausePlayBtn.addEventListener('click', musicPause);

declineEvenMoneyBtn.addEventListener('click', async () => {
  if (settlementInFlight || !activeZone) return;
  const resp = await bjSendAction('decline_even_money', activeZone);
  if (!resp) return;
  evenMoneyBtn.style.display = 'none';
  declineEvenMoneyBtn.style.display = 'none';
  bjApplyActionResponse(resp);
});
chips.forEach((chip, i) => {
  chip.addEventListener('click', () => chipSelect(chipValues[i], i));
});

groups.forEach(({ arr, type }) => {
  arr.forEach((el, i) => {
    el.addEventListener('click', () => {
      placeBet(`betZone${i + 1}`, type);
    });
  });
});

newGameBtn.addEventListener('click', () => {
  if (settlementInFlight) return;
  hidePostRoundButtons();
  resetForNewRoundUI();
  resetRoundTracking();
  resetLastWinDisplay();
  enableZonesAndRefreshChips();
});

rebetBtn.addEventListener('click', () => {
  if (settlementInFlight) return;
  if (!rebetSnapshot || rebetSnapshot.required <= 0) {
    notification('NO PREVIOUS BETS');
    return;
  }
  const need =
    REBET_CHECK_BY === 'balanceAtDeal'
      ? rebetSnapshot.balanceAtDeal
      : rebetSnapshot.required;
  if (playerInfo.balance < need) {
    notification('NOT ENOUGH MONEY');
    return;
  }
  hidePostRoundButtons();
  resetForNewRoundUI();
  showStandardButtons();
  rebet();
  resetRoundTracking();
  resetLastWinDisplay();
  updateUndoBtnState();
  enableZonesAndRefreshChips();
});

rebetDealBtn.addEventListener('click', () => {
  if (settlementInFlight) return;
  if (!rebetSnapshot || rebetSnapshot.required <= 0) {
    notification('NO PREVIOUS BETS');
    return;
  }
  const need =
    REBET_CHECK_BY === 'balanceAtDeal'
      ? rebetSnapshot.balanceAtDeal
      : rebetSnapshot.required;
  if (playerInfo.balance < need) {
    notification('NOT ENOUGH MONEY');
    return;
  }
  hidePostRoundButtons();
  resetForNewRoundUI();
  rebet();
  resetRoundTracking();
  resetLastWinDisplay();
  hideStandardButtons();
  setTimeout(deal, 1000);
});

closeWindow.forEach((btn) =>
  btn.addEventListener('click', () => {
    helpWindow?.style && (helpWindow.style.display = 'none');
    settingsWindow?.style && (settingsWindow.style.display = 'none');
  })
);

settingsBtn.addEventListener('click', () => {
  settingsWindow.style.display = 'block';
  helpWindow.style.display = 'none';
});

helpBtn.addEventListener('click', () => {
  helpWindow.style.display = 'block';
  settingsWindow.style.display = 'none';
  requestAnimationFrame(() => {
    scrollArea.scrollTop = 0;
  });
});

playBtn.addEventListener('click', async () => {
  loadingScreen.remove();
  game.style.opacity = '1';
  music.play();
  await bootstrapBlackjackSession();
});

musicChangeBtn[0].addEventListener('click', () => musicChange('prev'));
musicChangeBtn[1].addEventListener('click', () => musicChange('next'));

document.addEventListener(
  'wheel',
  function (e) {
    if (e.ctrlKey) {
      e.preventDefault();
    }
  },
  { passive: false }
);

document.addEventListener('keydown', function (e) {
  if (e.ctrlKey && (e.key === '+' || e.key === '-' || e.key === '=')) {
    e.preventDefault();
  }
  if (e.ctrlKey && e.key === '0') {
    e.preventDefault();
  }
});

document.addEventListener('contextmenu', function (e) {
  e.preventDefault();
});
